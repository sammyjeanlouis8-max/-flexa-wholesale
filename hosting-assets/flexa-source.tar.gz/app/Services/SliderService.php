<?php
namespace App\Services;

use App\Models\Slider;
use Auth;
use Exception;

class SliderService
{
    public function sliders($request)
    {
        try {
            $sliders = Slider::latest()->select('*');
            return $sliders;
        } catch (Exception $e) {
            throw $e;
			exit;
        }
    }

    public function storeSlider($request)
    {
        try {
           
            Slider::create([
                'title' => $request->title,
                'status' => $request->status,
                'src' => $this->insertImage($request),
            ]);
            return true;


        } catch (Exception $e) {
            throw $e;
			exit;
        }
    }

    public function insertImage($request)
    {
        try { 
            if ($request->file('src')) {
                $file = $request->file('src');
                $name = time() . $file->getClientOriginalName();
                $file->move(public_path() . '/uploads/sliders/', $name);
                $path = 'uploads/sliders/' . $name;
               
                return $path;
            }
        } catch (Exception $e) {
            throw $e;
			exit;
        }
    }

    public function updateSlider($request, $slider)
    {
        try {
            $slider->title = $request->title;
            $slider->status = $request->status;
            $slider->src = $this->editImage($request, $slider);
            $slider->update();

            return true;

        } catch (Exception $e) {
            throw $e;
			exit;
        }
    }


    public function editImage($request, $slider)
    {
        try {
            if ($request->file('src')) {
                $file = $request->file('src');
                $name = time() . $file->getClientOriginalName();
                $file->move(public_path() . '/uploads/sliders/', $name);
                unlink(public_path($slider->src));
                $path = 'uploads/sliders/' . $name;
            } else {
                $path = $slider->src;
            }
            return $path;
        } catch (Exception $e) {
            throw $e;
			exit;
        }
    }


    public function deleteSlider($slider)
    {
        try {
            $slider->delete();
            return true;
        } catch (Exception $e) {
           throw $e;
			exit;
        }
    }

    public function activeSlider($id)
    {
        try {
            $slider = Slider::findorfail($id);
            $slider->status = "Active";
            $slider->update();
            return true;
        } catch (Exception $e) {
           throw $e;
			exit;
        }
    }


    public function declineSlider($id)
    {
        try {
            $slider = Slider::findorfail($id);
            $slider->status = "Inactive";
            $slider->update();
            return true;
        } catch (Exception $e) {
            throw $e;
			exit;
        }
    }
}