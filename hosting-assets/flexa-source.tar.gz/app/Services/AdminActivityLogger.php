<?php

namespace App\Services;

use App\Models\AdminActivityLog;
use App\Models\User;
use Illuminate\Database\Eloquent\Model;

class AdminActivityLogger
{
    /** Record only deliberate, non-sensitive audit metadata. */
    public function record(?User $actor, string $action, Model|string|null $target = null, array $metadata = []): AdminActivityLog
    {
        $metadata = $this->safeMetadata($metadata);
        return AdminActivityLog::create([
            'actor_id' => $actor?->id,
            'action' => $action,
            'target_type' => $target instanceof Model ? $target::class : $target,
            'target_id' => $target instanceof Model ? $target->getKey() : null,
            'metadata' => $metadata ?: null,
            'created_at' => now(),
        ]);
    }

    private function safeMetadata(array $metadata): array
    {
        foreach ($metadata as $key => $value) {
            if (preg_match('/(password|token|secret|api[_-]?key|private[_-]?key|card|cvc)/i', (string) $key)) {
                unset($metadata[$key]);
            } elseif (is_array($value)) {
                $metadata[$key] = $this->safeMetadata($value);
            }
        }
        return $metadata;
    }
}