<?php
namespace App\Services;

use App\Models\Category;
use App\Models\Order;
use App\Models\Subcategory;
use Auth;
use App\Services\ProductService;
use App\Services\SubcategoryService;
use Exception;
use Illuminate\Support\Facades\DB;

class CategoryService
{
	protected $product;
	protected $subCategory;
	public function __construct(ProductService $product, SubcategoryService $subCategory)
	{
		$this->product = $product;
		$this->subCategory = $subCategory;
	}
	public function categories()
	{
		try {
			$categories = Category::latest()->select('*');
			return $categories;
		} catch (Exception $e) {
			throw $e;
			exit;
		}
	}

	public function storeCategory($request)
	{
		try {
			Category::create([
				'user_id' => Auth::user()->id,
				'category_name' => $request->category_name,
				'status' => 'Inactive',
				'image' => $this->insertImage($request),
			]);

			return true;


		} catch (Exception $e) {
			throw $e;
			exit;
		}
	}

	public function insertImage($request)
	{
		try {
			if ($request->file('image')) {
				$file = $request->file('image');
				$name = time() . countCategories() . $file->getClientOriginalName();
				$file->move(public_path() . '/uploads/categories/', $name);
				$path = 'uploads/categories/' . $name;
				return $path;
			}
		} catch (Exception $e) {
			throw $e;
			exit;
		}
	}

	public function updateCategory($request, $category)
	{
		try {
			if (!$category->slug) {
				$category->category_name = $request->category_name;
				$category->status = 'Inactive';
			} else {
				$category->status = 'Active';
			}
			$category->image = $this->editImage($request, $category);
			$category->update();

			return true;

		} catch (Exception $e) {
			throw $e;
			exit;
		}
	}


	public function editImage($request, $category)
	{
		try {
			if ($request->file('image')) {
				$file = $request->file('image');
				$name = time() . countCategories() . $file->getClientOriginalName();
				$file->move(public_path() . '/uploads/categories/', $name);
				unlink(public_path($category->image));
				$path = 'uploads/categories/' . $name;
			} else {
				$path = $category->image;
			}
			return $path;
		} catch (Exception $e) {
			throw $e;
			exit;
		}
	}

public function deleteCategory($category)
{
    DB::beginTransaction();

    try {
        if ($category->slug && in_array($category->slug, Category::principalSlugs(), true)) {
            throw new Exception('Principal wholesale categories cannot be deleted.');
        }

        // Get product IDs associated with the category
        $productIds = $category->products->pluck('id')->toArray();

        // Check for ongoing orders associated with these products
        $productOrders = Order::whereIn('product_id', $productIds)
            ->whereIn('status', ['Accepted', 'Pending'])
            ->whereHas('orderdetail', function ($query) {
                $query->whereNotIn('status', ['delivered', 'canclled']);
            })
            ->count();

        if ($productOrders > 0) {
            DB::rollBack();
            throw new Exception('Cannot delete category as it is associated with an ongoing order.');
        }

        // Delete all products in the category
        $products = $category->products;
        foreach ($products as $product) {
            $this->product->deleteProduct($product);
        }

        // Delete all subcategories
        $subcategories = $category->subcategories;
        foreach ($subcategories as $subcategory) {
            $this->subCategory->deleteSubcategory($subcategory);
        }

        // Delete category image file
        if (file_exists(public_path($category->image))) {
            unlink(public_path($category->image));
        }

        // Delete category
        $category->delete();

        DB::commit();

        return true;
    } catch (Exception $e) {
        DB::rollBack();
        // Optionally log the exception here
        throw $e;
    }
}

	public function activeCategory($id)
	{
		try {
			$category = Category::findorfail($id);
			if (!$category->slug || !in_array($category->slug, Category::principalSlugs(), true)) {
				throw new Exception('Only principal wholesale categories can be activated.');
			}
			$category->status = 'Active';
			$category->update();

			return true;


		} catch (Exception $e) {
			throw $e;
			exit;
		}
	}

	public function declineCategory($id)
	{
		try {
			$category = Category::findorfail($id);
			if ($category->slug && in_array($category->slug, Category::principalSlugs(), true)) {
				throw new Exception('Principal wholesale categories cannot be deactivated.');
			}
			$category->status = 'Inactive';
			$category->update();

			return true;


		} catch (Exception $e) {
			throw $e;
			exit;
		}
	}
}