<?php

namespace App\Services;

use App\Models\CardDetail;
use App\Models\Vendor;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class CardDetailService
{
    public function addCard(Request $request)
    {
       

        try {
            CardDetail::create($request->all());
            return true;
        } catch (Exception $e) {
            throw $e;
			exit;
        }
    }

    public function deleteCard($id)
    {
        try {
            $cardDetail = CardDetail::find($id);

            if (!$cardDetail) {
                return ['status' => 404, 'message' => 'Card not found'];
            }

            $cardDetail->delete();
            return true;
        } catch (Exception $e) {
            throw $e;
			exit;
        }
    }

    public function getCardsByVendorId($vendor)
    {
        try {
            $vendor = Vendor::find($vendor);
            if (!$vendor) {
                return ['status' => 404, 'message' => 'Vendor not found'];
            }

            return $vendor->cardDetails;
        } catch (Exception $e) {
           throw $e;
			exit;
        }
    }
}
