<?php
namespace App\Services;

use App\Models\Subcategory;
use Auth;
use Exception;
use App\Models\Order;
use Illuminate\Support\Facades\DB;

class SubcategoryService
{
	protected $product;
	public function __construct(ProductService $product)
	{
		$this->product = $product;
	}
	public function subcategories()
	{
		try {
			$subcategories = Subcategory::latest()->select('*');
			return $subcategories;
		} catch (Exception $e) {
			throw $e;
			exit;
		}
	}

	public function storeSubcategory($request)
	{
		try {
			Subcategory::create([
				'user_id' => Auth::user()->id,
				'category_id' => $request->category_id,
				'subcategory_name' => $request->subcategory_name,
				'status' => $request->status,
				'image' => $this->insertImage($request),
			]);
		} catch (Exception $e) {
			throw $e;
			exit;
		}
	}

	public function insertImage($request)
	{
		try {
			if ($request->file('image')) {
				$file = $request->file('image');
				$name = time() . countSubcategories() . $file->getClientOriginalName();
				$file->move(public_path() . '/uploads/subcategories/', $name);
				$path = 'uploads/subcategories/' . $name;
				return $path;
			}
		} catch (Exception $e) {
			throw $e;
			exit;
		}
	}

	public function updateSubcategory($request, $subcategory)
	{
		try {
			$subcategory->subcategory_name = $request->subcategory_name;
			$subcategory->category_id = $request->category_id;
			$subcategory->status = $request->status;
			$subcategory->image = $this->editImage($request, $subcategory);
			$subcategory->update();

			return true;

		} catch (Exception $e) {
			throw $e;
			exit;
		}
	}


	public function editImage($request, $subcategory)
	{
		try {
			if ($request->file('image')) {
				$file = $request->file('image');
				$name = time() . countSubcategories() . $file->getClientOriginalName();
				$file->move(public_path() . '/uploads/subcategoris/', $name);
				unlink(public_path($subcategory->image));
				$path = 'uploads/subcategoris/' . $name;
			} else {
				$path = $subcategory->image;
			}
			return $path;
		} catch (Exception $e) {
			throw $e;
			exit;
		}
	}


public function deleteSubcategory($subcategory)
{
    DB::beginTransaction();

    try {
        // Get product IDs associated with the subcategory
        $productIds = $subcategory->products->pluck('id')->toArray();

        // Check for ongoing orders associated with these products
        $productOrders = Order::whereIn('product_id', $productIds)
            ->whereIn('status', ['Accepted', 'Pending'])
            ->whereHas('orderdetail', function ($query) {
                $query->whereNotIn('status', ['delivered', 'canclled']);
            })
            ->count();

        if ($productOrders > 0) {
            DB::rollBack();
            throw new Exception('Cannot delete subcategory as it is associated with an ongoing order.');
        }

        // Delete all products associated with the subcategory
        $products = $subcategory->products;
        foreach ($products as $product) {
            $this->product->deleteProduct($product);
        }

        // Delete the subcategory image file if it exists
        if (file_exists(public_path($subcategory->image))) {
            unlink(public_path($subcategory->image));
        }

        // Delete the subcategory
        $subcategory->delete();

        DB::commit();
        return true;
    } catch (Exception $e) {
        DB::rollBack();
        // Optionally log the exception or handle it as needed
        throw $e;
    }
}

	public function activeSubcategory($id)
	{
		try {
			$subcategory = Subcategory::findorfail($id);
			$subcategory->status = 'Active';
			$subcategory->update();
			return true;
		} catch (Exception $e) {
			throw $e;
			exit;
		}
	}

	public function declineSubcategory($id)
	{
		try {
			$subcategory = Subcategory::findorfail($id);
			$subcategory->status = 'Inactive';
			$subcategory->update();
		} catch (Exception $e) {
			throw $e;
			exit;
		}
	}
}