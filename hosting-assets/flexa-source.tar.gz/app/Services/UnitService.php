<?php
 namespace App\Services;
 use App\Models\Unit;
 use Auth;
 use App\Models\Order;
use Exception;
use Illuminate\Support\Facades\DB;

 class UnitService
 {	protected $product;
	public function __construct(ProductService $product)
	{
		$this->product = $product;
	}
 	 public function units($request)
 	 {
 	 	 try
 	 	 {
 	 	 	$units = Unit::latest()->select('*');
 	 	 	return $units;
 	 	 }catch (Exception $e) {
            throw $e;
            exit;
         }
 	 }

 	 public function storeUnit($request)
 	 {
 	 	try
 	 	 {
 	 	 	$unit = new Unit();
 	 	 	$unit->user_id = Auth::user()->id;
 	 	 	$unit->unit_name = $request->unit_name;
 	 	 	$unit->status = $request->status;
 	 	 	$unit->save();
 	 	 	return true;
 	 	 }catch (Exception $e) {
            throw $e;
            exit;
         }
 	 }

 	 public function updateUnit($request,$unit)
 	 {
 	 	try
 	 	 {
 	 	 	$unit->unit_name = $request->unit_name;
 	 	 	$unit->status = $request->status;
 	 	 	$unit->update();
 	 	 	return true;
 	 	 }catch (Exception $e) {
            throw $e;
            exit;
         }
 	 }


 	public function deleteUnit($unit)
{
    DB::beginTransaction();

    try {
        // Get product IDs associated with the unit
        $productIds = $unit->products->pluck('id')->toArray();

        // Check for ongoing orders associated with these products
        $productOrders = Order::whereIn('product_id', $productIds)
            ->whereIn('status', ['Accepted', 'Pending'])
            ->whereHas('orderdetail', function ($query) {
                $query->whereNotIn('status', ['delivered', 'canclled']);
            })
            ->count();

        if ($productOrders > 0) {
            DB::rollBack();
            throw new Exception('Cannot delete unit as it is associated with an ongoing order.');
        }

        // Delete all products associated with the unit
        $products = $unit->products;
        foreach ($products as $product) {
            $this->product->deleteProduct($product);
        }

        // Delete the unit
        $unit->delete();

        DB::commit();
        return true;
    } catch (Exception $e) {
        DB::rollBack();
        // Optionally log the exception or handle it as needed
        throw $e;
    }
}

 	 public function activeUnit($id)
 	 {
 	 	 try
 	 	 {
 	 	 	$unit = Unit::findorfail($id);
 	 	 	$unit->status = "Active";
 	 	 	$unit->update();
 	 	 	return true;
 	 	 }catch (Exception $e) {
           throw $e;
            exit;
         }
 	 }


 	 public function declineUnit($id)
 	 {
 	 	try
 	 	 {
 	 	 	$unit = Unit::findorfail($id);
 	 	 	$unit->status = "Decline";
 	 	 	$unit->update();
 	 	 	return true;
 	 	 }catch (Exception $e) {
            throw $e;
            exit;
         }
 	 }
 }