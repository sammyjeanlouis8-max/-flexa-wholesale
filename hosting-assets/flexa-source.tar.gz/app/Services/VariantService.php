<?php
namespace App\Services;

use App\Models\Variant;
use Auth;
use Exception;

class VariantService
{
	public function variants($request)
	{
		try {
			$variants = Variant::latest()->select('*');
			return $variants;
		} catch (Exception $e) {
			throw $e;
			exit;
		}
	}

	public function storeVariant($request)
	{
		try {
			$variant = new Variant();
			$variant->user_id = Auth::user()->id;
			$variant->category_id = $request->category_id;
			$variant->variant_name = $request->variant_name;
			$variant->variant_value = implode(',', $request->variant_value);
			$variant->save();
			return true;
		} catch (Exception $e) {
			throw $e;
			exit;
		}
	}

	public function updateVariant($request, $variant)
	{
		try {
		    $variant->category_id = $request->category_id;
			$variant->variant_name = $request->variant_name;
			$variant->variant_value = implode(',', $request->variant_value);
			$variant->update();
			return true;
		} catch (Exception $e) {
			throw $e;
			exit;
		}
	}

	public function deleteVariant($variant)
	{
		try {
			$variant->delete();
			return true;
		} catch (Exception $e) {
			throw $e;
			exit;
		}
	}
}