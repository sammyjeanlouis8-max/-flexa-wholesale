<?php

namespace App\Services;

use App\Models\User;
use App\Models\WithdrawRequestLog;
use Illuminate\Http\Request;
use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

class WithdrawRequestLogService
{
    public function makeRequest(Request $request)
    {
        try {
            DB::beginTransaction();
            $withdrawRequest = WithdrawRequestLog::create($request->all());

            $vendor = $withdrawRequest->vendor;
            $withdrawAmount = $withdrawRequest->amount;
            $newBalance = $vendor->balance - $withdrawAmount;
            $vendor->update(['balance' => $newBalance]);

            $admin = User::where('role_id', 1)->first();
            $admin->tax_collection += $withdrawRequest->amount - $withdrawRequest->actual_withDraw_amount;
            $admin->update();
            DB::commit();

            return true;
        } catch (Exception $e) {
            DB::rollback();
            throw $e;
        }
    }
    public function filterWithdrawRequests(Request $request)
    {
        try {
            $query = WithdrawRequestLog::with('card');

            if ($request->has('vendor_id')) {
                $query->where('vendor_id', $request->vendor_id);
            }

            if ($request->has('from_date') && $request->from_date != null) {
                $query->where('created_at', '>=', $request->from_date);
            }

            if ($request->has('to_date') && $request->to_date != null) {
                $query->where('created_at', '<=', $request->to_date);
            }

            if ($request->has('status') && $request->status != null) {
                $query->where('status', $request->status);
            }

            return $query->get();
        } catch (Exception $e) {
            throw $e;
			exit;
        }
    }
    public function updateStatus(Request $request, $id)
    {
        try {
            DB::beginTransaction();
            $withdrawRequest = WithdrawRequestLog::findOrFail($id);

            if ($request->status == 'Rejected') {
                $vendor = $withdrawRequest->vendor;
                $withdrawAmount = $withdrawRequest->amount;
                $newBalance = $vendor->balance + $withdrawAmount;
                $vendor->update(['balance' => $newBalance]);
                $admin = User::where('role_id', 1)->first();
                $admin->tax_collection -= $withdrawRequest->amount - $withdrawRequest->actual_withDraw_amount;
                $admin->update();
            } elseif ($request->status == 'Approved') {
                if (empty($request->transaction_id)) {
                    throw new Exception("Transaction ID is required to approve the request.");
                }
                $withdrawRequest->tnx_id = $request->transaction_id;
            }

            $withdrawRequest->status = $request->status;
            $withdrawRequest->update();

            DB::commit();
            return response()->json(['success' => true]);
        } catch (Exception $e) {
            DB::rollback();
            throw $e;
			exit;
        }
    }


}
