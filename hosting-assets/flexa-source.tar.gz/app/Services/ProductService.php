<?php
namespace App\Services;

use App\Models\Product;
use App\Models\Image;
use App\Models\Country;
use App\Models\ProductMedia;
use App\Models\ProductPriceTier;
use App\Support\MarketplaceCountry;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Str;
use App\Models\Order;

class ProductService
{
	public function products(Request $request)
	{
		try {
			$products = Product::query()->with(['images', 'media', 'priceTiers']);
		  if ($request->has('vendorId')) {
            $products->where('vendor_id', $request->vendorId)->where('status', 'Active');
            $isOwnVendor = $request->user()
                && (int) optional($request->user()->vendor)->id === (int) $request->vendorId;
            if (!$isOwnVendor) {
                $country = MarketplaceCountry::filterValue($request);
                MarketplaceCountry::availableQuery($products, $country);
            }
        } else {
            $products->where('status', 'Active');
            $country = MarketplaceCountry::filterValue($request);
            MarketplaceCountry::availableQuery($products, $country);
        }
			if ($request->has('search')) {
				$products->where('product_name', 'LIKE', '%' . $request->search . '%');
			}
            if ($request->filled('city')) {
                $products->whereRaw('LOWER(city) = ?', [strtolower(trim((string) $request->input('city')))]);
            }
			if ($request->has('type') && $request->type == 'Top Picks') {
				$products = $products->where('top_picks', 1)->get();
			} elseif ($request->has('type') && $request->type != null) {
				$products = $products->inRandomOrder()->get();
			} else {
				$products = $products->get();
			}

			$products = $products->map(function ($product) {
				$product->avg_ratings = $product->avg_ratings;
				$product->total_reviews = $product->total_reviews;
				return $product;
			});

			return $products;

			// $products = Product::select('*');
			// return $products;
		} catch (Exception $e) {
			throw new Exception('Failed to get product: ' . $e->getMessage(), $e->getCode());
		}
	}



	public function storeProduct($request)
	{
		DB::beginTransaction();
		try {
			$product = new Product();
			$product->vendor_id = $request->vendor_id??  1;
			$product->category_id = $request->category_id;
			$product->subcategory_id = $request->subcategory_id;
			$product->unit_id = $request->unit_id;
			$product->product_name = $request->product_name;
			$product->product_price = $request->product_price;
			$product->product_discount = $request->has('discount') ? $request->discount : 0;
			$product->product_stock = $request->product_stock;
			$product->product_stock_limit = $request->has('low_stock_limit') ? $request->low_stock_limit : 0;
			$product->delivery_duration = $request->has('delivery_duration') ? $request->delivery_duration : 0;
			$product->delivery_duration_unit = $this->normalizeDeliveryDurationUnit($request->input('delivery_duration_unit'));
			$product->product_short_description = $request->short_description;
			$product->country = $request->country;
			$product->city = $request->city;
			$product->region = $request->region;
			$product->postal_code = $request->postal_code;
			$product->sku = $request->sku;
			$product->minimum_order_quantity = $request->minimum_order_quantity ?? 1;
			$product->wholesale_unit_type = $request->wholesale_unit_type ?? 'box';
			$product->warehouse_name = $request->warehouse_name;
			$product->warehouse_address = $request->warehouse_address;
			$product->warehouse_city = $request->warehouse_city;
			$product->warehouse_region = $request->warehouse_region;
			$product->warehouse_postal_code = $request->warehouse_postal_code;
			$product->warehouse_country = $request->warehouse_country;
			$product->ships_internationally = (bool) $request->ships_internationally;
			$product->offers_local_delivery = (bool) $request->offers_local_delivery;
			$product->offers_warehouse_pickup = (bool) $request->offers_warehouse_pickup;
			$product->offers_seller_delivery = (bool) $request->offers_seller_delivery;
			$product->offers_marketplace_logistics = (bool) $request->offers_marketplace_logistics;

			$product->is_featured = $request->has('is_featured') ? $request->is_featured : 0;
			$product->top_picks = $request->has('top_picks') ? $request->top_picks : 0;
			$product->return_available = $request->has('return_available') ? $request->return_available : 0;
			$product->warrenty_available = $request->has('warrenty_available') ? $request->warrenty_available : 0;
			$product->delivery_charge = $request->delivery_charge ?? 0;
			$product->is_delivery_free = $request->has('is_delivery_free')
                ? (bool) $request->is_delivery_free
                : (float) ($request->delivery_charge ?? 0) === 0.0;
			$product->status = $request->status;
			//dd($product);
			$product->save();
			$this->syncAvailability($product, $request);
			$this->syncPriceTiers($product, $request);
			$images = $this->insertMultipleImages($request);
			$product->images()->sync($images);
			if ($request->hasFile('videos')) {
				$this->storeProductMedia($product, $request);
			}
			//$variants = json_decode($request->variants, true);

			// if (!empty($variants)) {
			// 	foreach ($variants as $variant) {
			// 		//$product = Product::find($variant['id']);
			// 		if ($product) {
			// 			$variantValues = implode(',', $variant['variant_value']);
			// 			$product->variants()->attach($product->id, ['variant_id' => $variant['id'], 'variant_value' => $variantValues]);
			// 		} else {
			// 			throw new Exception("Product with ID {$variant['id']} not found.", 404);
			// 		}
			// 	}
			// }

			// Handle variants
			$variants = $request->input('variants');
			$formattedVariants = [];

		if (!is_null($variants)) {
            if (is_string($variants)) {
                // If variants come as a JSON string from API
                $formattedVariants = json_decode($variants, true);
            } else {
                // If variants are in array format from web form
                $formattedVariants = [];
                foreach ($variants as $variantId => $variantData) {
                    $values = $variantData['values'] ?? [];
                    if (!empty($values)) {
                        $formattedVariants[] = [
                            'id' => $variantId,
                            'variant_name' => $variantData['name'],
                            'variant_value' => $values
                        ];
                    }
                }
            }
        } 


			if (!empty($formattedVariants)) {
				foreach ($formattedVariants as $variant) {
					$variantValues = implode(',', $variant['variant_value']);
					$product->variants()->attach($product->id, ['variant_id' => $variant['id'], 'variant_value' => $variantValues]);
				}
			}
			DB::commit();
			return true;
		} catch (Exception $e) {
			DB::rollback();
			throw $e;
		}
	}
	public function insertMultipleImages($request)
	{
		$images = [];
		if ($request->file('images')) {
			foreach ($request->file('images') as $file) {
				$name = time() . $file->getClientOriginalName();
				$file->move(public_path() . '/uploads/', $name);
				$path = 'uploads/' . $name;

				$image = Image::create(['src' => $path]);
				$images[] = $image->id;
			}
		}
		return $images;
	}

	private function normalizeDeliveryDurationUnit(?string $unit): string
	{
		$normalized = ucfirst(strtolower(trim((string) ($unit ?: 'Days'))));
		return in_array($normalized, ['Days', 'Weeks', 'Months', 'Year'], true)
			? $normalized
			: 'Days';
	}

	public function updateProduct($request, $product)
	{
		DB::beginTransaction();
		try {
			//$product = Product::findOrFail($productId);
			$product->vendor_id = $request->vendor_id?? 1;
			$product->category_id = $request->category_id;
			$product->subcategory_id = $request->subcategory_id;
			$product->unit_id = $request->unit_id;
			$product->product_name = $request->product_name;
			$product->product_price = $request->product_price;
			$product->product_discount = $request->has('discount') ? $request->discount : 0;
			$product->product_stock = $request->product_stock;
			$product->product_stock_limit = $request->has('low_stock_limit') ? $request->low_stock_limit : 0;
			$product->delivery_duration = $request->has('delivery_duration') ? $request->delivery_duration : 0;
			$product->delivery_duration_unit = $this->normalizeDeliveryDurationUnit($request->input('delivery_duration_unit'));
			$product->product_short_description = $request->short_description;
			$product->country = $request->country;
			$product->city = $request->city;
			$product->region = $request->region;
			$product->postal_code = $request->postal_code;
			$product->sku = $request->sku;
			$product->minimum_order_quantity = $request->minimum_order_quantity ?? 1;
			$product->wholesale_unit_type = $request->wholesale_unit_type ?? 'box';
			$product->warehouse_name = $request->warehouse_name;
			$product->warehouse_address = $request->warehouse_address;
			$product->warehouse_city = $request->warehouse_city;
			$product->warehouse_region = $request->warehouse_region;
			$product->warehouse_postal_code = $request->warehouse_postal_code;
			$product->warehouse_country = $request->warehouse_country;
			$product->ships_internationally = (bool) $request->ships_internationally;
			$product->offers_local_delivery = (bool) $request->offers_local_delivery;
			$product->offers_warehouse_pickup = (bool) $request->offers_warehouse_pickup;
			$product->offers_seller_delivery = (bool) $request->offers_seller_delivery;
			$product->offers_marketplace_logistics = (bool) $request->offers_marketplace_logistics;

			$product->is_featured = $request->has('is_featured') ? $request->is_featured : 0;
			$product->top_picks = $request->has('top_picks') ? $request->top_picks : 0;
			$product->return_available = $request->has('return_available') ? $request->return_available : 0;
			$product->warrenty_available = $request->has('warrenty_available') ? $request->warrenty_available : 0;
			$product->delivery_charge = $request->delivery_charge ?? 0;
			$product->is_delivery_free = $request->has('is_delivery_free')
                ? (bool) $request->is_delivery_free
                : (float) ($request->delivery_charge ?? 0) === 0.0;
        	$product->status = $request->status;

			$product->save();
			$this->syncAvailability($product, $request);
			$this->syncPriceTiers($product, $request);

			$images = $this->updateMultipleImages($request, $product);
			$product->images()->sync($images);

			$variants = $request->input('variants');
			$formattedVariants = [];
		if (!is_null($variants)) {

			if (is_string($variants)) {
				$formattedVariants = json_decode($variants, true);
			} else {
				foreach ($variants as $variantId => $variantData) {
					$values = $variantData['values'] ?? [];
					if (!empty($values)) {
						$formattedVariants[] = [
							'id' => $variantId,
							'variant_name' => $variantData['name'],
							'variant_value' => $values
						];
					}
				}
			}

			$product->variants()->detach();}

			if (!empty($formattedVariants)) {
				foreach ($formattedVariants as $variant) {
					$variantValues = implode(',', $variant['variant_value']);
					$product->variants()->attach($variant['id'], ['variant_value' => $variantValues]);
				}
			}

			DB::commit();
			return true;
		} catch (Exception $e) {
			DB::rollback();
			throw $e;
		}
	}


	public function updateMultipleImages($request, $product)
	{
		

		$images = [];
		if ($request->file('images')) {
		    foreach ($product->images as $image) {
			if (file_exists(public_path($image->src))) {
				unlink(public_path($image->src));
			}
			$image->delete();
		}
			foreach ($request->file('images') as $file) {
				$name = time() . $file->getClientOriginalName();
				$file->move(public_path() . '/uploads/', $name);
				$path = 'uploads/' . $name;

				$image = Image::create(['src' => $path]);
				$images[] = $image->id;
			}
		}
		else{
		    $images=$product->images;
		}
		return $images;
	}

	public function deleteProduct($product)
	{
	    $productOrders=Order::where('product_id',$product->id)
	    ->whereIn('status',['Accepted','Pending'])
	    ->wherehas('orderdetail',function($query){
	        $query->whereNotIn('status' , ['delivered', 'canclled']);
	    })
	        ->count();
	        
	      if ($productOrders>0) {
                throw new Exception('Cannot delete product as it is associated with an ongoing order.');
            }
		DB::beginTransaction();
		try {
			foreach ($product->images as $image) {
				if (file_exists(public_path($image->src))) {
					unlink(public_path($image->src));
				}
				$image->delete();
			}

			$product->images()->detach();
			$product->variants()->detach();
			foreach ($product->media as $media) {
				if (file_exists(public_path($media->path))) {
					unlink(public_path($media->path));
				}
				$media->delete();
			}

			$product->delete();

			DB::commit();
			return true;
		} catch (Exception $e) {
			DB::rollback();
			throw new Exception('Failed to delete product: ' . $e->getMessage(), $e->getCode());
		}
	}
	public function activeProduct($id)
	{
		try {
			$product = Product::findorfail($id);
			$product->status = 'Active';
			$product->update();

			return true;


		} catch (Exception $e) {
			throw $e;
			exit;
		}
	}

	public function declineProduct($id)
	{
		try {
			$product = Product::findorfail($id);
			$product->status = 'Inactive';
			$product->update();

			return true;


		} catch (Exception $e) {
			throw $e;
			exit;
		}
	}

public function syncAvailability(Product $product, Request $request, ?array $countryCodes = null): void
	{
$codes = collect($countryCodes ?? $request->input('country_codes', []))
			->map(fn ($code) => strtoupper(trim((string) $code)))
			->filter(fn ($code) => array_key_exists($code, config('countries.supported', [])))
			->unique()
			->values();

		$product->forceFill(['availability_type' => 'selected'])->save();
		$product->availabilityCountries()->sync(
			Country::whereIn('code', $codes)->pluck('id')->all()
		);
	}

	public function syncPriceTiers(Product $product, Request $request): void
	{
		if (! $request->has('price_tiers')) {
			return;
		}

		$product->priceTiers()->delete();
		foreach (collect($request->input('price_tiers', []))->values() as $tier) {
			if (! is_array($tier) || ($tier['min_quantity'] ?? null) === null || ($tier['unit_price'] ?? null) === null) {
				continue;
			}

			ProductPriceTier::create([
				'product_id' => $product->id,
				'min_quantity' => (int) $tier['min_quantity'],
				'max_quantity' => isset($tier['max_quantity']) && $tier['max_quantity'] !== ''
					? (int) $tier['max_quantity']
					: null,
				'unit_price' => (float) $tier['unit_price'],
				'currency_code' => $tier['currency_code'] ?? null,
			]);
		}
	}

	public function storeProductMedia(Product $product, Request $request): void
	{
		$files = collect($request->file('images', []))->map(fn ($file) => [$file, 'image'])
			->merge(collect($request->file('videos', []))->map(fn ($file) => [$file, 'video']));
		$order = ($product->media()->max('display_order') ?? -1) + 1;
		$directory = public_path('uploads/product-media');
		File::ensureDirectoryExists($directory);

		foreach ($files as [$file, $type]) {
			$name = Str::uuid() . '.' . $file->getClientOriginalExtension();
			$originalName = $file->getClientOriginalName();
			$mimeType = $file->getClientMimeType();
			$fileSize = $file->getSize();
			$file->move($directory, $name);
			$path = 'uploads/product-media/' . $name;
			$metadata = [
				'product_id' => $product->id,
				'media_type' => $type,
				'path' => $path,
				'display_order' => $order++,
				'original_name' => $originalName,
				'mime_type' => $mimeType,
				'file_size' => $fileSize,
			];

			if ($type === 'image' && function_exists('getimagesize')) {
				$dimensions = @getimagesize($directory . '/' . $name);
				if ($dimensions) {
					$metadata['width'] = $dimensions[0];
					$metadata['height'] = $dimensions[1];
				}
			}

			ProductMedia::create($metadata);
		}
	}
}
