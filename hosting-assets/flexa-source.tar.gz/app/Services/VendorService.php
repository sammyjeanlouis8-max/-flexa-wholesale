<?php

namespace App\Services;

use App\Models\Vendor;
use App\Models\User;
use App\Models\Country;
use App\Support\MarketplaceCountry;
use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\ValidationException;

class VendorService
{
	public function store($request)
	{

		DB::beginTransaction();
		try {
		

			if ($request->file('image')) {

				$file = $request->file('image');
				$name = time() . $file->getClientOriginalName();
				$file->move(public_path() . '/uploads/vendors/', $name);

				$path = 'uploads/vendors/' . $name;
			} else {
				$path = NULL;
			}


			$user = new User();
			$user->name = $request->name;
			$user->role_id = 2;
			$user->role = 'seller';
			$user->company_name = $request->company_name;
			$user->email = $request->email;
			$user->phone = $request->phone;
$user->country = $request->country;
$user->city = $request->city;
			$user->address = $request->address;
			$user->password = bcrypt($request->password);
			$user->image = $path;
			$user->save();
			$user->assignCapabilities(['buyer', 'seller']);

			$vendor = new Vendor();
			$vendor->user_id = $user->id;
			$vendor->business_type = $request->business_type;
			$vendor->trade_license = $request->trade_license;
			$vendor->tin_certificate_no = $request->tin_certificate_no;
			$vendor->region = $request->region;
			$vendor->area = $request->area;
			$vendor->address = $request->address;
			$vendor->city = $request->city;
			$vendor->postal_code = $request->postal_code;
			$vendor->save();
			$vendor->availabilityCountries()->sync(
				Country::whereIn('code', $request->input('sales_country_codes', []))->pluck('id')->all()
			);

			DB::commit();

			return response()->json(['status' => true, 'user_id' => intval($user->id), 'vendor_id' => intval($vendor->id), 'message' => 'Successfully a vendor has been added']);
		} catch (Exception $e) {
			DB::rollback();
			throw $e;
			exit;
		}
	}

	public function vendorDetails($id)
	{
		try {
			$vendor = Vendor::with('user')->findorfail($id);
			return $vendor;
		} catch (Exception $e) {
			throw $e;
			exit;
		}
	}

	public function updateVendor($request, $vendor)
	{
		DB::beginTransaction();
		try {
			$vendor = Vendor::find($vendor);
			$user = $vendor->user;
			$validator = Validator::make($request->all(), [
				'name' => 'nullable|string|max:50',
				'email' => 'nullable|email|unique:users,email,' . $user->id,
				'phone' => 'nullable|string|unique:users,phone,' . $user->id,
				'company_name' => 'nullable|string|unique:users,company_name,' . $user->id
			]);

			if ($validator->fails()) {
				return ['status' => false, 'message' => 'The given data was invalid', 'data' => $validator->errors()];
			}
			//dd($user);
			if ($request->file('image')) {
				if (file_exists(public_path($user->image))) {
					unlink(public_path($user->image));
				}
				//$image->delete();
				$file = $request->file('image');
				$name = time() . countCategories() . $file->getClientOriginalName();
				$file->move(public_path() . '/uploads/vendors/', $name);

				$path = 'uploads/vendors/' . $name;
			} else {
				$path = $user->image ?? null;
			}

			$user->name = $request->name ?? $user->name;
			$user->company_name = $request->company_name ?? $user->company_name;
			$user->email = $request->email ?? $user->email;
			$user->phone = $request->phone ?? $user->phone;
			$user->image = $path;
			$user->save();

			$vendor->business_type = $request->business_type ?? $vendor->business_type;
			$vendor->trade_license = $request->trade_license ?? $vendor->trade_license;
			$vendor->tin_certificate_no = $request->tin_certificate_no ?? $vendor->tin_certificate_no;
			$vendor->region = $request->region ?? $vendor->region;
			$vendor->area = $request->area ?? $vendor->area;
			$vendor->address = $request->address ?? $vendor->address;
			$vendor->city = $request->city ?? $vendor->city;
			$vendor->save();

			DB::commit();

			return response()->json(['status' => true, 'user_id' => intval($user->id), 'vendor_id' => intval($vendor->id), 'message' => 'Successfully a vendor has been updated']);
		} catch (Exception $e) {
			DB::rollback();
			throw $e;
			exit;
		}
	}

	public function productProfile(Vendor $vendor): array
	{
		$vendor->loadMissing(['user', 'availabilityCountries']);
		$user = $vendor->user;
		$country = MarketplaceCountry::normalize($user->country);
		$city = trim((string) ($vendor->city ?: $user->city));
		$address = trim((string) ($vendor->address ?: $user->address));
		$countryCodes = $vendor->availabilityCountries
			->pluck('code')
			->map(fn ($code) => strtoupper((string) $code))
			->filter()
			->unique()
			->values()
			->all();

		$errors = [];
		if (!$country || $city === '' || $address === '') {
			$errors['profile_location'] = __('seller.profile_location_missing');
		}
		if ($countryCodes === []) {
			$errors['sales_country_codes'] = __('seller.profile_sales_missing');
		}
		if ($errors !== []) {
			throw ValidationException::withMessages($errors);
		}

		return [
			'country' => $country,
			'city' => $city,
			'region' => $vendor->region,
			'postal_code' => $vendor->postal_code,
			'warehouse_name' => $user->company_name,
			'warehouse_address' => $address,
			'warehouse_city' => $city,
			'warehouse_region' => $vendor->region,
			'warehouse_postal_code' => $vendor->postal_code,
			'warehouse_country' => $country,
			'sales_country_codes' => $countryCodes,
			'country_codes' => $countryCodes,
			'availability_type' => 'selected',
		];
	}

	public function getVendorBalance($vendor)
	{
		$vendor = Vendor::find($vendor);
		return $vendor->balance;
	}
	public function activeVendor($id)
	{
		try {
			$vendor = Vendor::findorfail($id);
			$vendor->user->status = 'Active';
			$vendor->user->update();

			return true;

		} catch (Exception $e) {
			throw $e;
			exit;
		}
	}

	public function declineVendor($id)
	{
		try {
			$vendor = Vendor::findorfail($id);
			$vendor->user->status = 'Inactive';
			$vendor->user->update();

			return true;


		} catch (Exception $e) {
			throw $e;
			exit;
		}
	}
}
