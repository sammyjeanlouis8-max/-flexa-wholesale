<?php
use App\Models\Category;
use App\Models\Setting;
use App\Models\Subcategory;
use App\Models\Product;
use App\Models\Variant;
use App\Models\Unit;
use App\Models\Image;
use App\Models\Orderdetail;
use App\Models\Mail;
use App\Models\Vendor;
use App\Models\StatusLog;
use App\Models\Order;
use App\Models\Refund;
use App\Support\Locale;
use App\Support\MarketplaceCountry;

if (! function_exists('current_locale')) {
    /**
     * Returns the current safe application locale for Blade and PHP callers.
     */
    function current_locale()
    {
        return Locale::current();
    }
}

if (! function_exists('available_locales')) {
    /**
     * Returns the locale => display name map for language selectors.
     */
    function available_locales()
    {
        return Locale::supported();
    }
}

if (! function_exists('marketplace_country')) {
    function marketplace_country()
    {
        return MarketplaceCountry::current();
    }
}

if (! function_exists('marketplace_country_selection')) {
    function marketplace_country_selection()
    {
        return MarketplaceCountry::selection();
    }
}

if (! function_exists('marketplace_countries')) {
    function marketplace_countries()
    {
        return MarketplaceCountry::names();
    }
}

function countCategories()
{
	$count = Category::count();
	$count += 1;
	return $count;
}
function myMail()
{
	$mails = array(
		array('id' => '1', 'email' => NULL, 'mail_host' => NULL, 'mail_port' => NULL, 'mail_encryption' => NULL, 'password' => NULL, 'created_at' => NULL, 'updated_at' => NULL)
	);

	DB::table('mails')->insert($mails);
}
function mailData()
{
	$mail = Mail::find(1);
	return $mail;
}
function countProducts()
{
	$count = Product::count();
	$count += 1;
	return $count;
}
function setting()
{
	return Setting::first() ?? (new Setting())->forceFill([
'app_name' => 'Flexa Wo Seller',
'app_logo' => 'custom/flexa-wo-seller-logo.png',
		'currency' => 'USD',
		'currency_code' => 'USD',
		'currency_symbol' => '$',
	]);
}

function categories()
{
	$categories = Category::where('status', 'Active')->latest()->get();
	return $categories;
}
function vendors()
{
	$vendors = Vendor::whereHas('user', function ($query) {
		$query->where('status', 'Active');
	})->latest()->get();
	return $vendors;
}
function countSubcategories()
{
	$count = Subcategory::count();
	$count += 1;
	return $count;
}

function variantValues($variant)
{
	$values = explode(",", $variant->variant_value);
	return $values;
}


function units()
{
	$units = Unit::where('status', 'Active')->latest()->get();
	return $units;
}

function variants()
{
	$variants = Variant::latest()->get();
	return $variants;
}

function variantExplodes($id)
{
	$variant = Variant::findorfail($id);
	$explodes = explode(",", $variant->variant_value);
	return $explodes;
}

function insertMultipleImages($request)
{
	$images = [];
	if ($request->file('images')) {
		foreach ($request->file('images') as $file) {
			$name = time() . $file->getClientOriginalName();
			$file->move(public_path() . '/uploads/', $name);
			$path = 'uploads/' . $name;

			$image = Image::create(['src' => $path]);
			$images[] = $image->id;
		}
	}
	return $images;
}
function updateMultipleImages($request, $product)
{
	foreach ($product->images as $image) {
		if (file_exists(public_path($image->src))) {
			unlink(public_path($image->src));
		}
		$image->delete();
	}

	$images = [];
	if ($request->file('images')) {
		foreach ($request->file('images') as $file) {
			$name = time() . $file->getClientOriginalName();
			$file->move(public_path() . '/uploads/', $name);
			$path = 'uploads/' . $name;

			$image = Image::create(['src' => $path]);
			$images[] = $image->id;
		}
	}
	return $images;
}



function generateOrderNo()
{
	$count = Orderdetail::count();
	$count += 1;
	return "Order-" . "00" . $count;
}
function loadDB()
{
	if (env('DB_DATABASE') != '') {

		if (Schema::hasTable('settings')) {
			$countSettings = Setting::count();
			if ($countSettings == 0) {
				Setting::insert(['id' => 1]);
			}
		}
	}
}
function timezones()
{
	$timezones = \DateTimeZone::listIdentifiers();
	return $timezones;
}
function customMail(Request $request)
{
	$mail = Mail::findorfail(1);
	$mail->email = $request->email;
	$mail->mail_host = $request->mail_host;
	$mail->mail_port = $request->mail_port;
	$mail->mail_encryption = $request->mail_encryption;
	$mail->password = $request->password;
	$mail->update();

	return $mail;
}
function refund($userId, $orderId)
{
    try {
        DB::beginTransaction();

        $order = Order::with('orderdetail')->findOrFail($orderId);
        $existingRefund = Refund::where('order_id', $orderId)->first();
            if ($existingRefund) {       
                DB::rollBack();
                return true;
        }
       $taxPercentage = $order->orderDetail->tax_percentage; 
        $tax = ($order->unit_total_price * $taxPercentage) / 100;
        Refund::create([
            'user_id' => $userId,
            'order_id' => $order->id,
            'product_total_price' => $order->unit_total_price,  
            'total_amount' => $order->unit_total_price + $tax + $order->shipping_cost, 
        ]);

        DB::commit();

        return response()->json(['status' => true, 'data' => 'Amount refunded']);
    } catch (\Exception $e) {
        DB::rollBack();

        return response()->json(['status' => false, 'message' => 'Refund failed, please try again.']);
    }
}
function sendMailToUser($user){
    return true;
}

function addStatusLog($status,$orderDetailid){
    $log = new StatusLog();
            $log->orderdetail_id = $orderDetailid;
            $log->status = $status;
            $log->timestamp = time();
            $log->save();
            return true;
}

