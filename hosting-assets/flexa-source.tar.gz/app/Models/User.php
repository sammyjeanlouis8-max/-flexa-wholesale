<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Contracts\Auth\CanResetPassword as CanResetPasswordContract;
use Illuminate\Auth\Passwords\CanResetPassword as CanResetPasswordTrait;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable implements CanResetPasswordContract
{
    use HasApiTokens, HasFactory, Notifiable, CanResetPasswordTrait;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'email',
        'password',
        'is_primary_admin',
        'role',
        'account_status',
        'is_verified',
        'company_name',
        'phone',
        'address',
        'image',
        'country',
        'city',
        'locale',
        'marketplace_country',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'is_primary_admin' => 'boolean',
        'is_verified' => 'boolean',
        'last_login' => 'datetime',
    ];

    protected static function booted()
    {
        static::saving(function (self $user) {
            if ($user->is_primary_admin) {
                $user->role = 'owner';
            } elseif (!$user->role && in_array((int) $user->role_id, [1, 2, 3], true)) {
                $user->role = ((int) $user->role_id === 1 ? 'admin' : ((int) $user->role_id === 2 ? 'seller' : 'buyer'));
            }
            if (in_array($user->role, ['owner', 'admin', 'seller', 'buyer'], true)) {
                $user->role_id = ['owner' => 1, 'admin' => 1, 'seller' => 2, 'buyer' => 3][$user->role];
            }
            $user->account_status = $user->account_status ?: (strtolower($user->status ?? '') === 'inactive' ? 'inactive' : 'active');
            $user->status = $user->account_status === 'active' ? 'Active' : 'Inactive';
        });
        static::saved(function (self $user) {
            // The legacy scalar remains the compatibility/display role. Capabilities
            // are authoritative for customer and vendor access.
            if (!\Illuminate\Support\Facades\Schema::hasTable('capabilities')) {
                return;
            }
            $keys = match ($user->role) {
                'seller' => ['buyer', 'seller'],
                'buyer' => ['buyer'],
                default => [],
            };
            if ($keys) {
                $ids = Capability::whereIn('key', $keys)->pluck('id')->all();
                if ($ids) {
                    $user->capabilities()->syncWithoutDetaching($ids);
                }
            }
        });
    }

    public function vendor()
    {
        return $this->hasOne(Vendor::class);
    }

    public function ratings()
    {
        return $this->hasMany(Rating::class);
    }

    public function permissions()
    {
        return $this->belongsToMany(Permission::class);
    }

    public function capabilities()
    {
        return $this->belongsToMany(Capability::class, 'capability_user')->withTimestamps();
    }

    public function favorites()
    {
        return $this->hasMany(Favorite::class);
    }

    public function cart()
    {
        return $this->hasOne(Cart::class);
    }

    public function notifications()
    {
        return $this->hasMany(MarketplaceNotification::class);
    }

    public function sentMessages()
    {
        return $this->hasMany(Message::class, 'sender_id');
    }

    public function receivedMessages()
    {
        return $this->hasMany(Message::class, 'recipient_id');
    }

    public function reports()
    {
        return $this->hasMany(Report::class);
    }

    public function activityLogs()
    {
        return $this->hasMany(AdminActivityLog::class, 'actor_id');
    }

    public function capabilityKeys(): array
    {
        $keys = $this->relationLoaded('capabilities')
            ? $this->capabilities->pluck('key')->all()
            : $this->capabilities()->pluck('key')->all();
        if (!$keys && in_array($this->role, ['buyer', 'seller'], true)) {
            $keys = $this->role === 'seller' ? ['buyer', 'seller'] : ['buyer'];
        }
        return array_values(array_unique($keys));
    }

    public function hasCapability(string ...$capabilities): bool
    {
        $actual = $this->capabilityKeys();
        return (bool) array_intersect($actual, $capabilities);
    }

    public function canBuy(): bool
    {
        return $this->hasCapability('buyer');
    }

    public function canSell(): bool
    {
        return $this->hasCapability('seller') && $this->vendor()->exists();
    }

    public function assignCapabilities(array $capabilities): void
    {
        $allowed = array_values(array_intersect($capabilities, ['buyer', 'seller']));
        if (in_array('seller', $allowed, true) && !in_array('buyer', $allowed, true)) {
            $allowed[] = 'buyer';
        }
        $ids = Capability::whereIn('key', $allowed)->pluck('id')->all();
        $this->capabilities()->sync($ids);
        if (in_array('seller', $allowed, true)) {
            $this->vendor()->firstOrCreate([], ['balance' => 0]);
            $this->forceFill(['role' => 'seller'])->saveQuietly();
        } elseif (in_array('buyer', $allowed, true) && !in_array($this->role, ['admin', 'owner'], true)) {
            $this->forceFill(['role' => 'buyer'])->saveQuietly();
        }
    }

    public function isActive(): bool
    {
        return $this->account_status === 'active' && ($this->status ?? 'Active') !== 'Inactive';
    }

    public function hasRole(string ...$roles): bool
    {
        foreach ($roles as $role) {
            if (in_array($role, ['buyer', 'seller'], true) && $this->hasCapability($role)) {
                return true;
            }
            if ($this->role === $role) {
                return true;
            }
        }
        return false;
    }

    public function hasPermission(string $permission): bool
    {
        return $this->role === 'owner' || ($this->role === 'admin' && $this->permissions()->where('key', $permission)->exists());
    }
}
