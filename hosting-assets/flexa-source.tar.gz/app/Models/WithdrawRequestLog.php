<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class WithdrawRequestLog extends Model
{
    use HasFactory;
    protected $fillable = [
        'vendor_id',
        'amount',
        'card_id',
        'tnx_id',
        'actual_withDraw_amount',
        'status'
    ];

    public function vendor()
    {
        return $this->belongsTo(Vendor::class);
    }

    public function card()
    {
        return $this->belongsTo(CardDetail::class);
    }
}
