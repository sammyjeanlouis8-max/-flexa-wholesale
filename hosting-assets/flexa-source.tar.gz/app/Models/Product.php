<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    use HasFactory;

    protected $fillable = [
        'vendor_id',
        'category_id',
        'subcategory_id',
        'unit_id',
        'product_name',
        'product_price',
        'product_short_description',
        'product_discount',
        'product_stock',
        'product_stock_limit',
        'is_featured',
        'top_picks',
        'delivery_duration',
        'delivery_duration_unit',
        'return_available',
        'delivery_charge',
        'is_delivery_free',
        'warrenty_available',
        'status',
        'total_sold',
        'total_favourite',
        'availability_type',
        'country',
        'city',
        'region',
        'postal_code',
        'sku',
        'minimum_order_quantity',
        'wholesale_unit_type',
        'warehouse_name',
        'warehouse_address',
        'warehouse_city',
        'warehouse_region',
        'warehouse_postal_code',
        'warehouse_country',
        'ships_internationally',
        'offers_local_delivery',
        'offers_warehouse_pickup',
        'offers_seller_delivery',
        'offers_marketplace_logistics',
    ];

    protected $casts = [
        'product_price' => 'float',
        'delivery_charge' => 'float',
        'minimum_order_quantity' => 'integer',
        'ships_internationally' => 'boolean',
        'offers_local_delivery' => 'boolean',
        'offers_warehouse_pickup' => 'boolean',
        'offers_seller_delivery' => 'boolean',
        'offers_marketplace_logistics' => 'boolean',
        'is_delivery_free' => 'boolean',
        'return_available' => 'boolean',
        'warrenty_available' => 'boolean',
    ];

    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    public function subCategory()
    {
        return $this->belongsTo(Subcategory::class, 'subcategory_id');
    }
    public function unit()
    {
        return $this->belongsTo(Unit::class);
    }
    public function vendor()
    {
    	return $this->belongsTo(Vendor::class);
    }
    public function variants()
    {
        return $this->belongsToMany(Variant::class, 'product_variant', 'product_id', 'variant_id')->withPivot('variant_value');
    }
    public function images()
    {
        return $this->belongsToMany(Image::class, 'product_image');
    }
  public function ratings()
    {
        return $this->hasMany(ProductReview::class);
    }
    public function getAvgRatingsAttribute()
    {
        return $this->ratings()->avg('rating') ?? 0;
    }

    public function getTotalReviewsAttribute()
    {
        return $this->ratings()->count();
    }

    public function orders()
    {
        return $this->hasMany(Order::class);
    }

    public function favorites()
    {
        return $this->hasMany(Favorite::class);
    }

    public function availabilityCountries()
    {
        return $this->belongsToMany(Country::class, 'product_country_availability');
    }

    public function media()
    {
        return $this->hasMany(ProductMedia::class)->orderBy('display_order')->orderBy('id');
    }

    public function priceTiers()
    {
        return $this->hasMany(ProductPriceTier::class)->orderBy('min_quantity');
    }

    public function isAvailableIn(?string $country = null): bool
    {
        return \App\Support\MarketplaceCountry::productIsAvailable($this, $country);
    }

    public function priceForQuantity(int $quantity): float
    {
        $tier = $this->relationLoaded('priceTiers')
            ? $this->priceTiers->filter(function ($tier) use ($quantity) {
                return $quantity >= $tier->min_quantity
                    && ($tier->max_quantity === null || $quantity <= $tier->max_quantity);
            })->sortByDesc('min_quantity')->first()
            : $this->priceTiers()
                ->where('min_quantity', '<=', $quantity)
                ->where(function ($query) use ($quantity) {
                    $query->whereNull('max_quantity')->orWhere('max_quantity', '>=', $quantity);
                })
                ->orderByDesc('min_quantity')
                ->first();

        return (float) ($tier?->unit_price ?? $this->product_price);
    }

    public function cartItems()
    {
        return $this->hasMany(CartItem::class);
    }
}
