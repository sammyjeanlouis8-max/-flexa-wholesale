<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Image extends Model
{
  use HasFactory;
  protected $fillable = ['src'];

  public function products()
  {
    return $this->belongsToMany(Product::class, 'product_image');
  }
 public function ratings()
    {
        return $this->belongsToMany(Rating::class, 'image_rating', 'image_id', 'rating_id');
    }
}
