<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProductMedia extends Model
{
    protected $table = 'product_media';

    protected $fillable = [
        'product_id',
        'media_type',
        'path',
        'thumbnail_path',
        'display_order',
        'original_name',
        'mime_type',
        'file_size',
        'duration',
        'width',
        'height',
    ];

    protected $casts = [
        'display_order' => 'integer',
        'file_size' => 'integer',
        'duration' => 'float',
        'width' => 'integer',
        'height' => 'integer',
    ];

    public function product()
    {
        return $this->belongsTo(Product::class);
    }

    public function getUrlAttribute(): string
    {
        return asset($this->path);
    }

    public function getThumbnailUrlAttribute(): ?string
    {
        return $this->thumbnail_path ? asset($this->thumbnail_path) : null;
    }
}