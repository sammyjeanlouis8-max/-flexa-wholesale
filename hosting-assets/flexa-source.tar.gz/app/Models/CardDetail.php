<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CardDetail extends Model
{
    use HasFactory;
    protected $fillable = [
        'vendor_id',
        'bank_name',
        'account_no',
        'cvc',
        'expiry_month',
        'expiry_year',
        'holder_name'
    ];
    public function vendor()
    {
        return $this->belongsTo(Vendor::class);
    }
}
