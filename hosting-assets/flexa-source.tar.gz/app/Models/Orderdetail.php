<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Orderdetail extends Model
{
    use HasFactory;
protected $fillable = [
    'user_id',
    'payment_method',
    'order_no',
    'delivery_address',
    'delivery_country',
    'sub_total',
    'shipping_cost',
    'tax',
    'tax_percentage',
    'total_cost',
    'to_receive',
    'to_send',
    'to_pay',
    'date',
    'time',
    'month',
    'year',
    'status',
];
    public function orders()
    {
        return $this->hasMany(Order::class);
    }
    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
