<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Country extends Model
{
    protected $fillable = ['code', 'name_key', 'name', 'flag', 'currency_code', 'phone_code'];

    public function products()
    {
        return $this->belongsToMany(Product::class, 'product_country_availability');
    }

    public function getLabelAttribute(): string
    {
        return __('countries.' . $this->name_key);
    }
}