<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Vendor extends Model
{
    use HasFactory;
    protected $fillable = [
        'user_id',
        'business_type',
        'trade_license',
        'tin_certificate_no',
        'region',
        'city',
        'area',
        'address',
        'postal_code',
        'balance'
    ];
    public function user()
    {
        return $this->belongsTo(User::class);
    }
    public function ratings()
    {
        return $this->morphMany(Rating::class, 'rateable');
    }
    public function products()
    {
        return $this->hasMany(Product::class);
    }
    public function availabilityCountries()
    {
        return $this->belongsToMany(Country::class, 'vendor_country_availability')->withTimestamps();
    }
    public function cardDetails()
    {
        return $this->hasMany(CardDetail::class);
    }
}
