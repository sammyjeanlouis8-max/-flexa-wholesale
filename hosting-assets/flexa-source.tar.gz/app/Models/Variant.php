<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Variant extends Model
{
    use HasFactory;
    
    public function products()
    {
        return $this->belongsToMany(Product::class, 'product_variant', 'variant_id', 'product_id')->withPivot('variant_value');
    }
    public function category()
{
    return $this->belongsTo(Category::class, 'category_id');
}
}
