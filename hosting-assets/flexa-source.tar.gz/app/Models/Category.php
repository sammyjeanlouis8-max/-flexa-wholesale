<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class Category extends Model
{
    use HasFactory;

    public const PRINCIPAL_SLUGS = [
        'food-beverages',
        'beauty-perfume-personal-care',
        'fashion-clothing',
        'electronics-phones',
        'home-kitchen',
        'home-appliances',
        'automotive-parts',
        'construction-hardware',
        'agriculture-livestock',
        'baby-children',
        'health-wellness',
        'jewelry-accessories',
        'sports-leisure',
        'professional-industrial-supplies',
        'used-products',
        'other-products',
    ];

    protected $fillable = [
    	'user_id',
        'category_name',
        'slug',
        'search_terms',
        'status',
        'image',
    ];

    public function scopeActive($query)
    {
        return $query->where('status', 'Active')->whereIn('slug', self::PRINCIPAL_SLUGS);
    }

    public static function principalSlugs(): array
    {
        return self::PRINCIPAL_SLUGS;
    }

    public function scopeMatching($query, string $term)
    {
        $term = trim($term);
        $normalized = Str::lower(Str::ascii($term));

        return $query->where(function ($match) use ($term, $normalized) {
            $match->where('category_name', 'like', '%' . $term . '%')
                ->orWhere('slug', 'like', '%' . Str::slug($normalized) . '%')
                ->orWhere('search_terms', 'like', '%' . $normalized . '%');
        });
    }

    public function getDisplayNameAttribute(): string
    {
        if (!$this->slug) {
            return $this->category_name;
        }

        $key = 'categories.' . $this->slug;
        $translation = __($key);

        return $translation === $key ? $this->category_name : $translation;
    }

    public function getSearchableLabelAttribute(): string
    {
        return trim($this->display_name . ' ' . $this->category_name . ' ' . $this->search_terms);
    }
    
    public function subcategories()
    {
    	return $this->hasMany(Subcategory::class);
    }
    public function variants()
    {
    	return $this->hasMany(Variant::class);
    }
    public function products()
    {
        return $this->hasMany(Product::class);
    }
    
}
