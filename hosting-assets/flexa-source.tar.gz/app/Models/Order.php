<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    use HasFactory;
 protected $fillable = [
        'orderdetail_id',
        'vendor_id',
        'product_id',
        'to_review',
        'product_price',
        'product_quantity',
        'unit_total_price',
        'variants',
        'return_available',
        'warranty_available',
        'shipping_cost',
        'status',
    ];
    public function orderdetail()
    {
        return $this->belongsTo(Orderdetail::class);
    }

    public function getVariantsAttribute($value)
    {
        return json_decode($value, true);
    }
    public function vendor()
    {
        return $this->belongsTo(Vendor::class);
    }
    public function getVendorIdAttribute($value)
    {
        return $value ?? "";
    }

    public function product()
    {
        return $this->belongsTo(Product::class);
    }
      public function refund()
    {
        return $this->hasOne(Refund::class);
    }
}
