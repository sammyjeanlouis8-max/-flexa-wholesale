<?php

namespace App\Support;

class Locale
{
    public static function supported(): array
    {
        return config('localization.supported', []);
    }

    public static function fallback(): string
    {
        return config('localization.fallback', 'en');
    }

    /**
     * Normalize a locale or language tag and reject unsupported values.
     */
    public static function normalize(?string $locale): ?string
    {
        if (! is_string($locale) || $locale === '') {
            return null;
        }

        $locale = strtolower(str_replace('_', '-', trim($locale)));
        $language = explode('-', $locale, 2)[0];

        return array_key_exists($language, self::supported()) ? $language : null;
    }

    public static function current(): string
    {
        return self::normalize(app()->getLocale()) ?? self::fallback();
    }
}