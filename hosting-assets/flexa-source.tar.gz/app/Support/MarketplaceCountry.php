<?php

namespace App\Support;

use App\Models\Country;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Schema;

class MarketplaceCountry
{
    public static function supported(): array
    {
        return config('countries.supported', []);
    }

    public static function metadata(): array
    {
        return self::supported();
    }

    public static function normalize(?string $country): ?string
    {
        if (!is_string($country) || trim($country) === '') {
            return null;
        }

        $country = strtoupper(trim($country));
        return array_key_exists($country, self::supported()) ? $country : null;
    }

    public static function current(?Request $request = null): string
    {
        $request ??= request();
        return self::selection($request);
    }

    public static function accountCountry(?Request $request = null): ?string
    {
        $request ??= request();
        return $request->user()
            ? self::normalize($request->user()->getAttribute('country'))
            : null;
    }

    public static function purchaseCountry(?Request $request = null): string
    {
        $request ??= request();
        return self::accountCountry($request)
            ?? self::normalize(config('countries.default'))
            ?? 'US';
    }

    /**
     * Return the visible marketplace country.
     *
     * Guests may browse a selected country or all countries. Once a user has
     * registered, the account country is the only valid marketplace country.
     */
    public static function selection(?Request $request = null): string
    {
        $request ??= request();
        $sessionKey = config('countries.session_key', 'marketplace_country');

        if ($accountCountry = self::accountCountry($request)) {
            return $accountCountry;
        }

        if ($request->query->has('country')) {
            $requested = strtolower(trim((string) $request->query('country')));
            if ($requested === 'all') {
                return 'all';
            }

            return self::normalize($requested) ?? self::defaultCountry();
        }

        if ($request->hasSession() && $request->session()->has($sessionKey)) {
            $stored = strtolower(trim((string) $request->session()->get($sessionKey)));
            if ($stored === 'all') {
                return 'all';
            }

            return self::normalize($stored) ?? self::defaultCountry();
        }

        return self::accountCountry($request) ?? self::defaultCountry();
    }

    public static function filterCountry(?Request $request = null): ?string
    {
        return self::selection($request) === 'all' ? null : self::selection($request);
    }

    public static function filterValue(?Request $request = null): string
    {
        return self::selection($request);
    }

    private static function defaultCountry(): string
    {
        return self::normalize(config('countries.default')) ?? 'US';
    }

    public static function set(Request $request, string $country): string
    {
        if ($request->user()) {
            $lockedCountry = self::accountCountry($request) ?? self::defaultCountry();
            $request->session()->put(config('countries.session_key', 'marketplace_country'), $lockedCountry);
            if (Schema::hasColumn('users', 'marketplace_country')) {
                $request->user()->forceFill(['marketplace_country' => $lockedCountry])->save();
            }

            return $lockedCountry;
        }

        if (strtolower(trim($country)) === 'all') {
            $request->session()->put(config('countries.session_key', 'marketplace_country'), 'all');
            return 'all';
        }

        $normalized = self::normalize($country);
        abort_if($normalized === null, 404);

        $request->session()->put(config('countries.session_key', 'marketplace_country'), $normalized);

        return $normalized;
    }

    public static function names(): array
    {
        $names = [];
        foreach (self::metadata() as $code => $country) {
            $name = $country[0] ?? $code;
            $translated = __('countries.' . \Illuminate\Support\Str::snake($name));
            $names[$code] = $translated === 'countries.' . \Illuminate\Support\Str::snake($name)
                ? $name
                : $translated;
        }

        return $names;
    }

    public static function details(?string $country): ?array
    {
        $code = self::normalize($country);
        if ($code === null) {
            return null;
        }

        $data = self::metadata()[$code] ?? [];
        return [
            'code' => $code,
            'name' => $data[0] ?? $code,
            'flag' => $data[1] ?? '',
            'currency_code' => $data[2] ?? null,
            'phone_code' => $data[3] ?? null,
        ];
    }

    public static function availableQuery($query, ?string $country = null)
    {
        if (strtolower((string) $country) === 'all') {
            return $query->whereHas('availabilityCountries');
        }

        $country = self::normalize($country) ?? self::current();

        return $query->whereHas('availabilityCountries', function ($countries) use ($country) {
            $countries->where('code', $country);
        });
    }

    public static function productIsAvailable($product, ?string $country = null): bool
    {
        if (strtolower((string) $country) !== 'all') {
            $country = self::normalize($country) ?? self::current();
        }

        if (strtolower((string) $country) === 'all') {
            return $product->relationLoaded('availabilityCountries')
                ? $product->availabilityCountries->isNotEmpty()
                : $product->availabilityCountries()->exists();
        }

        $country = self::normalize($country) ?? self::current();
        if ($product->relationLoaded('availabilityCountries')) {
            return $product->availabilityCountries->contains('code', $country);
        }

        return $product->availabilityCountries()->where('code', $country)->exists();
    }
}