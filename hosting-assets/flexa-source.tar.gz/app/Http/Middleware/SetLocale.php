<?php

namespace App\Http\Middleware;

use App\Support\Locale;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Schema;

class SetLocale
{
    /**
     * Inherit Flexa Market language when present, then fall back to session / profile / Accept-Language.
     *
     * Priority:
     * 1. Explicit ?lang= / ?locale= (Market handoff)
     * 2. flexamarket_lang cookie (shared Market preference)
     * 3. Wholesale session locale
     * 4. Authenticated user locale column
     * 5. Accept-Language
     * 6. Config fallback (en)
     */
    public function handle(Request $request, Closure $next)
    {
        $sessionKey = config('localization.session_key', 'locale');

        $locale = Locale::normalize($request->query('lang'))
            ?? Locale::normalize($request->query('locale'))
            ?? Locale::normalize($request->cookie('flexamarket_lang'))
            ?? Locale::normalize($request->session()->get($sessionKey));

        if ($locale === null) {
            $user = $request->user();

            if ($user !== null && Schema::hasTable('users') && Schema::hasColumn('users', 'locale')) {
                $locale = Locale::normalize($user->getAttribute('locale'));
            }
        }

        if ($locale === null) {
            foreach ($request->getLanguages() as $language) {
                $locale = Locale::normalize($language);

                if ($locale !== null) {
                    break;
                }
            }
        }

        $locale = $locale ?? Locale::fallback();
        app()->setLocale($locale);
        $request->session()->put($sessionKey, $locale);

        $response = $next($request);

        // Persist for subsequent Wholesale visits (and keep Market cookie in sync when set via ?lang=).
        if (method_exists($response, 'cookie')) {
            $response->cookie('flexamarket_lang', $locale, 60 * 24 * 365, '/', null, false, false, false, 'lax');
        }

        return $response;
    }
}
