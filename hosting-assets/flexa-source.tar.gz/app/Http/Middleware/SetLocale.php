<?php

namespace App\Http\Middleware;

use App\Support\Locale;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Schema;

class SetLocale
{
    public function handle(Request $request, Closure $next)
    {
        $sessionKey = config('localization.session_key', 'locale');
        $locale = Locale::normalize($request->session()->get($sessionKey));

        if ($locale === null) {
            $user = $request->user();

            if ($user !== null && Schema::hasTable('users') && Schema::hasColumn('users', 'locale')) {
                $locale = Locale::normalize($user->getAttribute('locale'));
            }
        }

        if ($locale === null) {
            foreach ($request->getLanguages() as $language) {
                $locale = Locale::normalize($language);

                if ($locale !== null) {
                    break;
                }
            }
        }

        $locale = $locale ?? Locale::fallback();
        app()->setLocale($locale);
        $request->session()->put($sessionKey, $locale);

        return $next($request);
    }
}