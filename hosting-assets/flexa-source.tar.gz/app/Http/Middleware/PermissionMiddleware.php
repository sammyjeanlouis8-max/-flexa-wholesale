<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class PermissionMiddleware
{
    public function handle(Request $request, Closure $next, $permission)
    {
        $user = $request->user();
        abort_unless($user && $user->hasPermission($permission), 403);
        return $next($request);
    }
}