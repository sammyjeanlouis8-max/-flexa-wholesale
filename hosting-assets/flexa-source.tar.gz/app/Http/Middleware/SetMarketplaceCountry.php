<?php

namespace App\Http\Middleware;

use App\Support\MarketplaceCountry;
use Closure;
use Illuminate\Http\Request;

class SetMarketplaceCountry
{
    public function handle(Request $request, Closure $next)
    {
        $key = config('countries.session_key', 'marketplace_country');
        if (MarketplaceCountry::normalize($request->session()->get($key)) === null) {
            $request->session()->put($key, MarketplaceCountry::current($request));
        }

        return $next($request);
    }
}