<?php

namespace App\Http\Controllers;

use App\Services\ProductService;
use App\Services\VendorService;
use Exception;
use Illuminate\Http\Request;
use App\Models\Category;
use App\Models\Subcategory;
use App\Services\CategoryService;
use App\Services\SubcategoryService;
use App\Services\UnitService;
use App\Services\WithdrawRequestLogService;
use Illuminate\Support\Facades\Log;
use App\Services\SliderService;

class AjaxRequestController extends Controller
{

    protected $category;
    protected $subcategory;
    protected $unit;
    protected $product;
    protected $withdrawRequestService;
    protected $vendor;
    protected $slider;

    public function __construct(
        CategoryService $category,
        SubcategoryService $subcategory,
        UnitService $unit,
        ProductService $product,
        WithdrawRequestLogService $withdrawRequestService,
        VendorService $vendor,
        SliderService $slider

    ) {
        $this->category = $category;
        $this->subcategory = $subcategory;
        $this->unit = $unit;
        $this->product = $product;
        $this->withdrawRequestService = $withdrawRequestService;
        $this->vendor = $vendor;
        $this->slider = $slider;

    }
    public function activeSlider($id)
    {
        try {
            $this->slider->activeSlider($id);

            return response()->json([
                'status' => true,
                'message' => 'Successfully the slider has been activated'
            ]);
        } catch (Exception $e) {
            $message = $e->getMessage();
            $code = $e->getCode();
            $string = $e->__toString();
            return response()->json([
                'message' => $message,
                'execption_code' => $code,
                'execption_string' => $string
            ]);
            exit;
        }
    }


    public function declineSlider($id)
    {
        try {
            $this->slider->declineSlider($id);

            return response()->json([
                'status' => true,
                'message' => 'Successfully the slider has been inactived'
            ]);
        } catch (Exception $e) {
            $message = $e->getMessage();
            $code = $e->getCode();
            $string = $e->__toString();
            return response()->json([
                'message' => $message,
                'execption_code' => $code,
                'execption_string' => $string
            ]);
            exit;
        }
    }
    public function activeCategory($id)
    {
        try {
            $this->category->activeCategory($id);

            return response()->json(['status' => true, 'message' => 'Successfully the category has been activated']);
        } catch (Exception $e) {
            $message = $e->getMessage();
            $code = $e->getCode();
            $string = $e->__toString();
            return response()->json(['message' => $message, 'execption_code' => $code, 'execption_string' => $string]);
            exit;
        }
    }


    public function declineCategory($id)
    {
        try {
            $this->category->declineCategory($id);

            return response()->json(['status' => true, 'message' => 'Successfully the category has been inactived']);
        } catch (Exception $e) {
            $message = $e->getMessage();
            $code = $e->getCode();
            $string = $e->__toString();
            return response()->json(['message' => $message, 'execption_code' => $code, 'execption_string' => $string]);
            exit;
        }
    }


    public function activeSubcategory($id)
    {
        try {
            $this->subcategory->activeSubcategory($id);


            return response()->json(['status' => true, 'message' => 'Successfully the subcategory has been activated']);
        } catch (Exception $e) {
            $message = $e->getMessage();
            $code = $e->getCode();
            $string = $e->__toString();
            return response()->json(['message' => $message, 'execption_code' => $code, 'execption_string' => $string]);
            exit;
        }
    }


    public function declineSubcategory($id)
    {
        try {
            $this->subcategory->declineSubcategory($id);

            return response()->json(['status' => true, 'message' => 'Successfully the subcategory has been inactived']);
        } catch (Exception $e) {
            $message = $e->getMessage();
            $code = $e->getCode();
            $string = $e->__toString();
            return response()->json(['message' => $message, 'execption_code' => $code, 'execption_string' => $string]);
            exit;
        }
    }

    public function activeUnit($id)
    {
        try {
            $this->unit->activeUnit($id);

            return response()->json(['status' => true, 'message' => 'Successfully the unit has been activated']);
        } catch (Exception $e) {
            $message = $e->getMessage();
            $code = $e->getCode();
            $string = $e->__toString();
            return response()->json(['message' => $message, 'execption_code' => $code, 'execption_string' => $string]);
            exit;
        }
    }

    public function declineUnit($id)
    {
        try {
            $this->unit->declineUnit($id);

            return response()->json(['status' => true, 'message' => 'Successfully the unit has been inactived']);
        } catch (Exception $e) {
            $message = $e->getMessage();
            $code = $e->getCode();
            $string = $e->__toString();
            return response()->json(['message' => $message, 'execption_code' => $code, 'execption_string' => $string]);
            exit;
        }
    }

    public function getSubcategories($id)
    {
        try {
            $subcategories = $this->subcategory->subcategories()->where(['category_id' => $id, 'status' => 'Active'])->get();
            if (count($subcategories) > 0) {
                return response()->json(['status' => true, 'message' => 'Data found', 'data' => $subcategories]);
            }
            return response()->json(['status' => false, 'message' => 'No data found', 'data' => $subcategories]);
        } catch (Exception $e) {
            $message = $e->getMessage();
            $code = $e->getCode();
            $string = $e->__toString();
            return response()->json(['message' => $message, 'execption_code' => $code, 'execption_string' => $string]);
            exit;
        }
    }

    public function activeProduct($id)
    {
        try {
            $product = \App\Models\Product::findOrFail($id);
            $oldStatus = $product->status;
            $this->product->activeProduct($id);
            app(\App\Services\AdminActivityLogger::class)->record(auth()->user(), 'product.status_updated', $product, [
                'old_status' => $oldStatus, 'new_status' => 'Active',
            ]);

            return response()->json([
                'status' => true,
                'message' => 'Successfully the product has been activated'
            ]);
        } catch (Exception $e) {
            $message = $e->getMessage();
            $code = $e->getCode();
            $string = $e->__toString();
            return response()->json([
                'message' => $message,
                'execption_code' => $code,
                'execption_string' => $string
            ]);
            exit;
        }
    }


    public function declineProduct($id)
    {
        try {
            $product = \App\Models\Product::findOrFail($id);
            $oldStatus = $product->status;
            $this->product->declineProduct($id);
            app(\App\Services\AdminActivityLogger::class)->record(auth()->user(), 'product.status_updated', $product, [
                'old_status' => $oldStatus, 'new_status' => 'Inactive',
            ]);

            return response()->json([
                'status' => true,
                'message' => 'Successfully the product has been inactived'
            ]);
        } catch (Exception $e) {
            $message = $e->getMessage();
            $code = $e->getCode();
            $string = $e->__toString();
            Log::error('prodyct decline: ' . $e->getMessage());

            return response()->json([
                'message' => $message,
                'execption_code' => $code,
                'execption_string' => $string
            ]);
            exit;
        }
    }

    public function activeVendor($id)
    {
        try {
            $this->vendor->activeVendor($id);

            return response()->json([
                'status' => true,
                'message' => 'Successfully the vendor has been activated'
            ]);
        } catch (Exception $e) {
            $message = $e->getMessage();
            $code = $e->getCode();
            $string = $e->__toString();
            return response()->json([
                'message' => $message,
                'execption_code' => $code,
                'execption_string' => $string
            ]);
            exit;
        }
    }


    public function declineVendor($id)
    {
        try {
            $this->vendor->declineVendor($id);

            return response()->json([
                'status' => true,
                'message' => 'Successfully the vendor has been inactived'
            ]);
        } catch (Exception $e) {
            $message = $e->getMessage();
            $code = $e->getCode();
            $string = $e->__toString();

            return response()->json([
                'message' => $message,
                'execption_code' => $code,
                'execption_string' => $string
            ]);
            exit;
        }
    }


}
