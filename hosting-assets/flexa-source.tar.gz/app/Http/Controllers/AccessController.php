<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use App\Models\Vendor;
use App\Models\Country;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use App\Support\Locale;
use App\Support\MarketplaceCountry;

class AccessController extends Controller
{
    public function show()
    {
        return view('auth.login', ['countries' => MarketplaceCountry::names()]);
    }

    public function adminLogin(Request $request)
    {
        return $this->login($request);
    }

    public function login(Request $request)
    {
        $data = $request->validate([
            'email' => ['required', 'email'],
            'password' => ['required', 'string'],
        ]);

        $user = User::where('email', $data['email'])->first();
        if ($user && $user->isActive() && Auth::attempt(['email' => $data['email'], 'password' => $data['password']])) {
            $request->session()->regenerate();
            $user->forceFill(['last_login' => now()])->save();
            return redirect()->route('dashboard')->with([
                'messege' => __('auth.login_success'),
                'alert-type' => 'success',
            ]);
        }

        return redirect()->back()->with([
            'messege' => __('auth.invalid_credentials'),
            'alert-type' => 'error',
        ]);
    }

    public function register(Request $request)
    {
        $sellerRegistration = in_array($request->input('role'), ['seller', 'buyer_seller'], true);
        $data = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'email', 'unique:users,email'],
            'password' => ['required', 'string', 'min:6', 'confirmed'],
            'role' => ['required', 'in:buyer,seller,buyer_seller'],
            'company_name' => ['nullable', 'string', 'max:255'],
            'phone' => ['nullable', 'string', 'max:255', 'unique:users,phone'],
            'country' => ['required', 'string', 'size:2', Rule::in(array_keys(MarketplaceCountry::supported()))],
            'city' => [Rule::requiredIf($sellerRegistration), 'nullable', 'string', 'max:255'],
            'region' => ['nullable', 'string', 'max:255'],
            'postal_code' => ['nullable', 'string', 'max:32'],
            'address' => [Rule::requiredIf($sellerRegistration), 'nullable', 'string', 'max:1000'],
            'sales_country_codes' => [Rule::requiredIf($sellerRegistration), 'nullable', 'array', 'min:1'],
            'sales_country_codes.*' => ['string', 'size:2', Rule::in(array_keys(MarketplaceCountry::supported()))],
        ], [
            'email.unique' => __('auth.email_already_registered'),
        ]);
        DB::transaction(function () use (&$user, $data, $sellerRegistration) {
            $user = User::create([
                'name' => $data['name'], 'email' => $data['email'],
                'password' => Hash::make($data['password']), 'role' => $data['role'] === 'buyer' ? 'buyer' : 'seller',
                'company_name' => $data['company_name'] ?? null,
                'phone' => $data['phone'] ?? null,
                'country' => MarketplaceCountry::normalize($data['country']),
                'city' => $data['city'] ?? null,
                'address' => $data['address'] ?? null,
                'locale' => Locale::current(),
                'account_status' => 'active',
            ]);
            $user->assignCapabilities($data['role'] === 'buyer' ? ['buyer'] : ['buyer', 'seller']);

            if ($sellerRegistration) {
                $vendor = $user->vendor()->firstOrCreate([], ['balance' => 0]);
                $vendor->update([
                    'city' => $data['city'],
                    'region' => $data['region'] ?? null,
                    'postal_code' => $data['postal_code'] ?? null,
                    'address' => $data['address'],
                ]);
                $vendor->availabilityCountries()->sync(
                    Country::whereIn('code', $data['sales_country_codes'])->pluck('id')->all()
                );
            }
        });
        Auth::login($user);
        $request->session()->regenerate();
        return redirect()->route('dashboard');
    }

    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        return redirect()->route('auth.show');
    }

    public function redirectToDashboard()
    {
        $user = Auth::user();
        if ($user->hasRole('owner', 'admin')) {
            return redirect()->route('admin.dashboard');
        }
        if ($user->hasRole('seller')) {
            return redirect()->route('seller.dashboard');
        }
        return redirect()->route('buyer.dashboard');
    }
}
