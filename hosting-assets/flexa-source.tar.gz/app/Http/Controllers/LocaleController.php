<?php

namespace App\Http\Controllers;

use App\Support\Locale;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Schema;

class LocaleController extends Controller
{
    public function update(Request $request, string $locale): RedirectResponse
    {
        $locale = Locale::normalize($locale);
        abort_if($locale === null, 404);

        $request->session()->put(config('localization.session_key', 'locale'), $locale);
        app()->setLocale($locale);

        $user = $request->user();
        if ($user && Schema::hasColumn('users', 'locale')) {
            $user->forceFill(['locale' => $locale])->save();
        }

        return back();
    }
}