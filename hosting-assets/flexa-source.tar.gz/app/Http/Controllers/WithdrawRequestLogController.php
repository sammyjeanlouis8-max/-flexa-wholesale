<?php

namespace App\Http\Controllers;

use App\Models\CardDetail;
use App\Models\Vendor;
use App\Models\WithdrawRequestLog;
use App\Services\WithdrawRequestLogService;
use App\Services\AdminActivityLogger;
use Exception;
use Illuminate\Http\Request;
use DataTables;
use Carbon\Carbon;
use Termwind\Components\Span;

class WithdrawRequestLogController extends Controller
{
    public function __construct(
        protected WithdrawRequestLogService $withdrawRequestLogService
    ) {
    }

    public function getWithdrawStatement(Request $request)
    {

        try {
            if ($request->ajax()) {
                $withdrawRequests = $this->withdrawRequestLogService->filterWithdrawRequests($request);
                return Datatables::of($withdrawRequests)
                    ->addIndexColumn()
                    ->addColumn('vendor', function ($row) {
                        $vendor = $row->vendor->user->name;
                        return $vendor;
                    })
                     ->addColumn('tnx_id', function ($row) {
                        $tnx_id = $row->tnx_id;
                        return $tnx_id;
                    })
                    ->addColumn('status', function ($row) {
                        if ($row->status == 'Rejected') {
                            $statusDropdown ='<span class="badge bg-success text-white">"'. $row->status.'"</span>';
                        } else {
                            $statusDropdown = '<select class="form-control status-dropdown" data-id="' . $row->id . '">
                            <option value="Pending"' . ($row->status == 'Pending' ? 'selected' : '') . '>Pending</option>
                            <option value="Approved"' . ($row->status == 'Approved' ? 'selected' : '') . '>Approved</option>
                            <option value="Rejected"' . ($row->status == 'Rejected' ? 'selected' : '') . '>Rejected</option>
                       
                        </select>';
                        }
                        return $statusDropdown;
                    })
                    ->addColumn('date', function ($row) {
                        return Carbon::parse($row->created_at)->format('d M Y, h:i A');
                    })
                    ->addColumn('action', function ($row) {
                        $btn = "";
                        $btn .= '&nbsp;';
                        $btn .= ' <a href="#" class="btn btn-info btn-sm show-card-details action-button" data-id="' . $row->id . '" data-toggle="modal" data-target="#cardModal"><i class="fa fa-eye"></i></a>';
                        return $btn;
                    })
                    ->rawColumns(['action', 'date', 'vendor', 'status'])
                    ->make(true);
            }
            $vendors = Vendor::get();
            return view('withdraw_statement', compact('vendors'));
        } catch (Exception $e) {
            $message = $e->getMessage();
            $code = $e->getCode();
            $string = $e->__toString();
            return response()->json(['message' => $message, 'execption_code' => $code, 'execption_string' => $string]);
            exit;
        }
    }
    public function getCardDetails($id)
    {
        try {
            $card = CardDetail::findOrFail($id);

            return response()->json($card);
        } catch (Exception $e) {
            return response()->json(['error' => 'Failed to load card details.'], 500);
        }
    }
    public function updateWithdrawStatus(Request $request, $id)
    {
        try {
            $withdraw = WithdrawRequestLog::findOrFail($id);
            $oldStatus = $withdraw->status;
            $this->withdrawRequestLogService->updateStatus($request, $id);
            app(AdminActivityLogger::class)->record(auth()->user(), 'withdrawal.status_updated', $withdraw, [
                'old_status' => $oldStatus, 'new_status' => $withdraw->fresh()->status,
            ]);

            return response()->json(['success' => 'Withdraw status updated successfully.']);
        } catch (Exception $e) {
            return response()->json(['error' => 'Failed to update Withdraw status.'], 500);
        }
    }
}
