<?php

namespace App\Http\Controllers;

use App\Models\Subcategory;
use Illuminate\Http\Request;
use App\Services\SubcategoryService;
use App\Http\Requests\StoreSubcategoryRequest;
use App\Http\Requests\UpdateSubcategoryRequest;
use DataTables;
class SubcategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    protected $subcategory;

    public function __construct(SubcategoryService $subcategory) 
    {
        $this->subcategory = $subcategory;
        $this->middleware('auth_check'); 
    }

    public function index(Request $request)
    {
        try {
            if ($request->ajax()) {
                $subcategories = $this->subcategory->subcategories();
                return Datatables::of($subcategories)
                    ->addIndexColumn()
                    ->addColumn('image', function ($row) {
                        return '<img class="img-fluid list-image" src="' . url('/') . "/" . $row->image . '">';
                    })

                    ->addColumn('category', function ($row) {
                        return $row->category->category_name;
                    })

                    ->addColumn('status', function ($row) {
                        $statusBadge = ($row->status == 'Active') ? "<span class='badge badge-success status'>Active</span>" : "<span class='badge badge-danger status'>Inactive</span>";
                        return $statusBadge;
                    })
                    ->addColumn('action', function ($row) {
                        $btn = "";
                        $btn .= '&nbsp;';
                        $btn .= $row->status == 'Active' ?
                            ' <a href="#" class="btn btn-danger btn-sm decline-subcategory action-button" data-id="' . $row->id . '"><i class="fa fa-ban"></i></a>' :
                            ' <a href="#" class="btn btn-primary btn-sm active-subcategory action-button" data-id="' . $row->id . '"><i class="fa fa-check" aria-hidden="true"></i></a>';
                        $btn .= '&nbsp;';
                        $btn .= ' <a href="' . route('subcategories.show', $row->id) . '" class="btn btn-primary btn-sm action-button"><i class="fa fa-edit"></i></a>';
                        $btn .= '&nbsp;';
                        $btn .= ' <a href="#" class="btn btn-danger btn-sm delete-subcategory action-button" data-id="' . $row->id . '"><i class="fa fa-trash"></i></a>';
                        return $btn;
                    })
                    ->filter(function ($instance) use ($request) {
                        if ($request->get('search') != "") {
                            $instance->where(function ($w) use ($request) {
                                $search = $request->get('search');
                                $w->orWhere('subcategories.subcategory_name', 'LIKE', "%$search%");
                            });
                        }
                        if ($request->get('category_id') != "") {
                            $instance->where(function ($w) use ($request) {
                                $category_id = $request->get('category_id');
                                $w->orWhere('subcategories.category_id', $category_id);
                            });
                        }
                        if ($request->get('status') == 'Active' || $request->get('status') == 'Inactive') {
                            $instance->where('subcategories.status', $request->get('status'));
                        }
                    }) 
                    ->rawColumns(['action', 'category', 'image', 'status']) 
                    ->make(true);
            }
            return view('subcategories.index');
        }catch (Exception $e) {
            $message = $e->getMessage();
            $code = $e->getCode();
            $string = $e->__toString();
            return response()->json(['message' => $message, 'execption_code' => $code, 'execption_string' => $string]);
            exit;
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('subcategories.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreSubcategoryRequest $request)
    {
        try
        {
            $this->subcategory->storeSubcategory($request);
            $notification = array(
                'messege' => "Successfully subcategory has been added",
                'alert-type' => 'success'
            );
            return redirect()->back()->with($notification);
        }catch (Exception $e) {
            $message = $e->getMessage();
            $code = $e->getCode();
            $string = $e->__toString();
            return response()->json(['message' => $message, 'execption_code' => $code, 'execption_string' => $string]);
            exit;
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Subcategory  $subcategory
     * @return \Illuminate\Http\Response
     */
    public function show(Subcategory $subcategory)
    {
        return view('subcategories.edit', compact('subcategory'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Subcategory  $subcategory
     * @return \Illuminate\Http\Response
     */
    public function edit(Subcategory $subcategory)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Subcategory  $subcategory
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateSubcategoryRequest $request, Subcategory $subcategory)
    {
        try
        {
            $this->subcategory->updateSubcategory($request,$subcategory);
            $notification = array(
                'messege' => "Successfully the subcategory has been updated",
                'alert-type' => 'success'
            );
            return redirect('/subcategories')->with($notification);
        }catch (Exception $e) {
            $message = $e->getMessage();
            $code = $e->getCode();
            $string = $e->__toString();
            return response()->json(['message' => $message, 'execption_code' => $code, 'execption_string' => $string]);
            exit;
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Subcategory  $subcategory
     * @return \Illuminate\Http\Response
     */
    public function destroy(Subcategory $subcategory)
    {
        try
        {
            $this->subcategory->deleteSubcategory($subcategory);
            return response()->json(['status'=>true, 'message'=>'Successfully the subcategory has been deleted']);
        }catch (Exception $e) {
          throw $e;
            exit;
        }
    }
}
