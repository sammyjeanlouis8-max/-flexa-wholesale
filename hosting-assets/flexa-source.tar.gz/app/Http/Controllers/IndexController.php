<?php

namespace App\Http\Controllers;

use App\Models\Setting;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Schema;

class IndexController extends Controller
{
    public function loginPage()
    {
        $connection = config('database.default');
        $database = config("database.connections.$connection.database");

        if (empty($database)) {
            return redirect('/install');
        }

        try {
            $isInstalled = Schema::hasTable('settings')
                && Setting::query()->exists()
                && User::where('role_id', 1)->exists();
        } catch (\Throwable $exception) {
            $isInstalled = false;
        }

        return $isInstalled
            ? view('admin_login')
            : redirect('/install');
    }
}
