<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Auth\Events\PasswordReset;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Password;
use Illuminate\Support\Str;
use Throwable;

class PasswordResetController extends Controller
{
    public function showRequest()
    {
        return view('auth.forgot-password');
    }

    public function sendResetLink(Request $request)
    {
        $data = $request->validate([
            'email' => ['required', 'email'],
        ]);

        $resetUrl = null;

        try {
            $status = Password::broker()->sendResetLink(
                ['email' => $data['email']],
                function (User $user, string $token) use (&$resetUrl): void {
                    $resetUrl = route('password.reset', [
                        'token' => $token,
                        'email' => $user->getEmailForPasswordReset(),
                    ]);

                    $user->sendPasswordResetNotification($token);
                }
            );
        } catch (Throwable $exception) {
            report($exception);
            $status = $resetUrl ? Password::RESET_LINK_SENT : Password::INVALID_USER;
        }

        if ($status === Password::RESET_THROTTLED) {
            return back()
                ->withInput()
                ->withErrors(['email' => __('auth.reset_link_throttled')]);
        }

        $response = back()->with('status', __('auth.reset_link_sent'));

        if (app()->environment('local') && $resetUrl) {
            $response->with('dev_reset_url', $resetUrl);
        }

        return $response;
    }

    public function showResetForm(Request $request, string $token)
    {
        return view('auth.reset-password', [
            'token' => $token,
            'email' => $request->query('email', ''),
        ]);
    }

    public function reset(Request $request)
    {
        $data = $request->validate([
            'token' => ['required', 'string'],
            'email' => ['required', 'email'],
            'password' => ['required', 'string', 'min:6', 'confirmed'],
        ]);

        $status = Password::broker()->reset(
            [
                'email' => $data['email'],
                'password' => $data['password'],
                'password_confirmation' => $request->input('password_confirmation'),
                'token' => $data['token'],
            ],
            function (User $user, string $password): void {
                $user->forceFill([
                    'password' => Hash::make($password),
                    'remember_token' => Str::random(60),
                ])->save();

                event(new PasswordReset($user));
            }
        );

        if ($status === Password::PASSWORD_RESET) {
            return redirect()->route('auth.show')->with([
                'messege' => __('auth.password_reset_success'),
                'alert-type' => 'success',
            ]);
        }

        return back()
            ->withInput($request->only('email'))
            ->withErrors(['email' => __('auth.password_reset_invalid')]);
    }
}