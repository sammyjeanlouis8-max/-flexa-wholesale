<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Kreait\Firebase\Factory;
use App\Models\Data;

class ChatController extends Controller
{
    public function realCrud()
    {
        return view('chat.inbox');
    }
}
