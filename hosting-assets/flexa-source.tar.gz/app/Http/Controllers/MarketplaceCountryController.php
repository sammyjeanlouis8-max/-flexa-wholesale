<?php

namespace App\Http\Controllers;

use App\Support\MarketplaceCountry;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class MarketplaceCountryController extends Controller
{
    public function update(Request $request, string $country): RedirectResponse
    {
        MarketplaceCountry::set($request, $country);
        return back()->with('messege', $request->user()
            ? __('marketplace.account_country_locked')
            : __('marketplace.country_changed'));
    }
}