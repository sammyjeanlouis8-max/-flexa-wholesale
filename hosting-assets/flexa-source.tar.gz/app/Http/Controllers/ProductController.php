<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\Category;
use Exception;
use Illuminate\Http\Request;
use App\Services\ProductService;
use App\Services\AdminActivityLogger;
use DataTables;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use App\Support\MarketplaceCountry;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */


    protected $product;

    public function __construct(ProductService $product)
    {
        $this->product = $product;
        $this->middleware('auth_check');
    }

    public function index(Request $request)
    {
        try {
            if ($request->ajax()) {
                $products = Product::latest()->get();
                return Datatables::of($products)
                    ->addIndexColumn()
                    ->addColumn('status', function ($row) {
                        $statusBadge = ($row->status == 'Active') ? "<span class='badge badge-success status'>Active</span>" : "<span class='badge badge-danger status'>Inactive</span>";
                        return $statusBadge;
                    })
                    ->addColumn('category', function ($row) {
                        return $row->category->category_name;
                    })
                    ->addColumn('image', function ($row) {
                        $image = $row->images->first() ? $row->images->first()->src : '';
                        if ($image) {
                            return "<img src='" . asset($image) . "' alt='Product Image' width='80' height='80'>";
                        } else {
                            return "<span class='badge badge-warning'>No Image</span>";
                        }
                    })
                    ->addColumn('unit', function ($row) {
                        return $row->unit->unit_name;
                    })
                    ->addColumn('action', function ($row) {
                        $btn = "";
                        $btn .= '&nbsp;';
                        $btn .= $row->status == 'Active' ?
                            ' <a href="#" class="btn btn-danger btn-sm decline-product action-button" data-id="' . $row->id . '"><i class="fa fa-ban"></i></a>' :
                            ' <a href="#" class="btn btn-primary btn-sm active-product action-button" data-id="' . $row->id . '"><i class="fa fa-check" aria-hidden="true"></i></a>';
                        $btn .= '&nbsp;';
                        $btn .= ' <a href="' . route('products.show', $row->id) . '" class="btn btn-primary btn-sm action-button"><i class="fa fa-edit"></i></a>';
                        $btn .= '&nbsp;';
                        $btn .= ' <a href="#" class="btn btn-danger btn-sm delete-product action-button" data-id="' . $row->id . '"><i class="fa fa-trash"></i></a>';
                        return $btn;
                    })
                    ->rawColumns(['action', 'image', 'category', 'status', 'unit'])
                    ->make(true);
            }
            return view('products.index');
        } catch (Exception $e) {
            $message = $e->getMessage();
            $code = $e->getCode();
            $string = $e->__toString();
            return response()->json(['message' => $message, 'execption_code' => $code, 'execption_string' => $string]);
        }
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('products.create', ['countries' => MarketplaceCountry::names()]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'vendor_id' => 'required|exists:vendors,id',
            'category_id' => [
                'required',
                Rule::exists('categories', 'id')->where(
                    fn ($query) => $query->where('status', 'Active')->whereIn('slug', Category::principalSlugs())
                ),
            ],
            'subcategory_id' => 'required|exists:subcategories,id',
            'unit_id' => 'required|exists:units,id',
            'product_name' => 'required|string|max:255|unique:products,product_name',
            'product_price' => 'required',
            'product_discount' => 'nullable',
            'product_stock' => 'required',
            'is_featured' => 'required',
            'top_picks' => 'required',
            'status' => 'required',
            'country' => ['required', 'string', 'size:2', Rule::in(array_keys(MarketplaceCountry::supported()))],
            'city' => 'required|string|max:255',
            'region' => 'nullable|string|max:255',
    'images' => 'required',  // Ensure the images array is required
    'images.*' => 'image|mimes:jpeg,png,jpg|max:2048'  // Validate each image in the array

        ]);

        if ($validator->fails()) {
            $notification = array(
                'messege' => 'Please check the feild again.',
                'alert-type' => 'error'
            );

            return redirect()->back()
                ->withErrors($validator)
                ->withInput()
                ->with($notification);
        }
        try {

            $this->product->storeProduct($request);
            $product = Product::where('product_name', $request->input('product_name'))->first();
            app(AdminActivityLogger::class)->record(auth()->user(), 'product.created', $product, [
                'vendor_id' => (int) $request->input('vendor_id'),
                'status' => $request->input('status'),
            ]);
            $notification = array(
                'messege' => 'Product Added Successfully',
                'alert-type' => 'success'
            );

            return redirect()->back()->with($notification);
        } catch (Exception $e) {
            Log::error('message', [
                'message' => $e->getMessage(),
                'exception_code' => $e->getCode(),
                'exception_string' => $e->__toString(),
            ]);
            $notification = array(
                'messege' => 'Something Went Wrong',
                'alert-type' => 'error'
            );

            return redirect()->back()->withErrors()
                ->withInput()->with($notification);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Product  $product
     * @return \Illuminate\View\View
     */
    public function show(Product $product)
    {
        return view('products.edit', compact('product'), ['countries' => MarketplaceCountry::names()]);

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function edit(Product $product)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Product  $product
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(Request $request, Product $product)
    {
        $validator = Validator::make($request->all(), [
            'vendor_id' => 'required|exists:vendors,id',
            'category_id' => [
                'required',
                Rule::exists('categories', 'id')->where(
                    fn ($query) => $query->where('status', 'Active')->whereIn('slug', Category::principalSlugs())
                ),
            ],
            'subcategory_id' => 'required|exists:subcategories,id',
            'unit_id' => 'required|exists:units,id',
            'product_name' => 'required|string|max:255|unique:products,product_name,' . $product->id,
            'product_price' => 'required',
            'product_discount' => 'nullable',
            'product_stock' => 'required',
            'is_featured' => 'required',
            'top_picks' => 'required',
            'status' => 'required',
            'country' => ['required', 'string', 'size:2', Rule::in(array_keys(MarketplaceCountry::supported()))],
            'city' => 'required|string|max:255',
            'region' => 'nullable|string|max:255',
    'images' => 'required',  // Ensure the images array is required
    'images.*' => 'image|mimes:jpeg,png,jpg|max:2048'  // Validate each image in the array
        ]);

        if ($validator->fails()) {
            $notification = array(
                'messege' => 'Please check the feild again.',
                'alert-type' => 'error'
            );

            return redirect()->back()
                ->withErrors($validator)
                ->withInput()
                ->with($notification);
        }
        try {

            $oldStatus = $product->status;
            $this->product->updateProduct($request, $product);
            app(AdminActivityLogger::class)->record(auth()->user(), 'product.updated', $product, [
                'old_status' => $oldStatus, 'new_status' => $product->fresh()->status,
            ]);
            $notification = array(
                'messege' => 'Product Updated Successfully',
                'alert-type' => 'success'
            );

            return redirect('/products')->with($notification);
        } catch (Exception $e) {
            Log::error('message', [
                'message' => $e->getMessage(),
                'exception_code' => $e->getCode(),
                'exception_string' => $e->__toString(),
            ]);
            $notification = array(
                'messege' => 'Something Went Wrong',
                'alert-type' => 'error'
            );

            return redirect()->back()->withErrors()
                ->withInput()->with($notification);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function destroy($product)
    {
        try {
            $product = Product::findOrFail($product);

            if (!$product) {
                return response()->json(['status' => false, 'message' => 'Product not found'], 404);
            }

            app(AdminActivityLogger::class)->record(auth()->user(), 'product.deleted', $product, [
                'vendor_id' => $product->vendor_id, 'status' => $product->status,
            ]);
            $this->product->deleteProduct($product);

            return response()->json(['status' => true, 'message' => 'Product deleted successfully'], 200);
        } catch (Exception $e) {
            throw $e;
            exit;
        }
    }
}
