<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Cart;
use App\Models\CartItem;
use App\Models\Favorite;
use App\Models\MarketplaceNotification;
use App\Models\Message;
use App\Models\Order;
use App\Models\Orderdetail;
use App\Models\Product;
use App\Models\Vendor;
use App\Support\MarketplaceCountry;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;

class MarketplaceController extends Controller
{
    private function products(Request $request)
    {
        $country = MarketplaceCountry::filterValue($request);
        $query = Product::with(['category', 'vendor.user', 'images', 'media', 'priceTiers'])->where('status', 'Active');
        MarketplaceCountry::availableQuery($query, $country);
        if ($request->filled('q')) {
            $term = mb_substr(trim((string) $request->input('q')), 0, 80);
            $categoryIds = Category::active()->matching($term)->pluck('id');
            $query->where(function ($search) use ($term, $categoryIds) {
                $search->where('product_name', 'like', '%' . $term . '%')
                    ->orWhere('product_short_description', 'like', '%' . $term . '%');
                if ($categoryIds->isNotEmpty()) {
                    $search->orWhereIn('category_id', $categoryIds);
                }
            });
        }
        if ($request->filled('city')) {
            $query->whereRaw('LOWER(city) = ?', [strtolower(trim((string) $request->input('city')))]);
        }
        if ($request->filled('category')) {
            $query->where('category_id', $request->integer('category'));
        }
        return $query->latest();
    }

    public function home(Request $request)
    {
        return view('marketplace.home', [
            'products' => $this->products($request)->paginate(12)->withQueryString(),
            'categories' => Category::active()->orderBy('category_name')->get()->sortBy('display_name', SORT_NATURAL | SORT_FLAG_CASE)->values(),
            'featured' => $this->products($request)->where('is_featured', 1)->latest()->take(4)->get(),
            'marketplaceCountry' => MarketplaceCountry::current($request),
            'marketplaceCountrySelection' => MarketplaceCountry::filterValue($request),
            'countries' => MarketplaceCountry::names(),
        ]);
    }

    public function search(Request $request) { return $this->home($request); }

    public function searchSuggestions(Request $request)
    {
        $term = trim((string) $request->input('q', ''));
        if (mb_strlen($term) < 2) {
            return response()->json(['groups' => []]);
        }

        $term = mb_substr($term, 0, 80);
        $country = MarketplaceCountry::filterValue($request);
        $matchingCategoryQuery = Category::active()->matching($term);
        $matchingCategoryIds = (clone $matchingCategoryQuery)->pluck('id');
        $matchingCategories = (clone $matchingCategoryQuery)
            ->orderBy('category_name')
            ->limit(5)
            ->get();

        $products = Product::with('vendor.user')
            ->where('status', 'Active')
            ->where(function ($query) use ($term, $matchingCategoryIds) {
                $query->where('product_name', 'like', '%' . $term . '%')
                    ->orWhere('product_short_description', 'like', '%' . $term . '%');
                if ($matchingCategoryIds->isNotEmpty()) {
                    $query->orWhereIn('category_id', $matchingCategoryIds);
                }
            });
        MarketplaceCountry::availableQuery($products, $country);
        $productResults = $products->latest()->limit(5)->get()->map(fn ($product) => [
            'title' => $product->product_name,
            'subtitle' => __('marketplace.wholesale_only'),
            'url' => route('marketplace.product', $product),
        ])->values()->all();

        $sellers = Vendor::with('user')
            ->where(function ($query) use ($term, $matchingCategoryIds, $country) {
                $query->whereHas('user', function ($users) use ($term) {
                    $users->where('name', 'like', '%' . $term . '%')
                        ->orWhere('company_name', 'like', '%' . $term . '%');
                })->orWhereHas('products', function ($products) use ($term, $matchingCategoryIds, $country) {
                    $products->where('status', 'Active')
                        ->where(function ($match) use ($term, $matchingCategoryIds) {
                            $match->where('product_name', 'like', '%' . $term . '%')
                                ->orWhere('product_short_description', 'like', '%' . $term . '%');
                            if ($matchingCategoryIds->isNotEmpty()) {
                                $match->orWhereIn('category_id', $matchingCategoryIds);
                            }
                        });
                    MarketplaceCountry::availableQuery($products, $country);
                });
            })
            ->whereHas('products', function ($query) use ($country) {
                $query->where('status', 'Active');
                MarketplaceCountry::availableQuery($query, $country);
            })
            ->latest()
            ->limit(5)
            ->get()
            ->map(fn ($vendor) => [
                'title' => $vendor->user->company_name ?: $vendor->user->name,
                'subtitle' => __('marketplace.store'),
                'url' => route('marketplace.store', $vendor),
            ])->values()->all();

        $categories = $matchingCategories
            ->sortBy('display_name', SORT_NATURAL | SORT_FLAG_CASE)
            ->map(fn ($category) => [
                'title' => $category->display_name,
                'subtitle' => __('marketplace.category'),
                'url' => route('marketplace.search', array_filter([
                    'category' => $category->id,
                    'country' => $request->input('country'),
                    'city' => $request->input('city'),
                ])),
            ])->values()->all();

        $countries = collect(MarketplaceCountry::names())
            ->filter(fn ($name, $code) => str_contains(mb_strtolower($name . ' ' . $code), mb_strtolower($term)))
            ->take(5)
            ->map(fn ($name, $code) => [
                'title' => $name,
                'subtitle' => $code,
                'url' => route('marketplace.home', ['country' => $code]),
            ])->values()->all();

        $groups = array_values(array_filter([
            ['key' => 'categories', 'label' => __('marketplace.categories'), 'items' => $categories],
            ['key' => 'products', 'label' => __('marketplace.products'), 'items' => $productResults],
            ['key' => 'sellers', 'label' => __('marketplace.sellers'), 'items' => $sellers],
            ['key' => 'countries', 'label' => __('marketplace.countries'), 'items' => $countries],
        ], fn ($group) => $group['items'] !== []));

        return response()->json(['groups' => $groups]);
    }

    public function product(Product $product)
    {
        abort_unless($product->status === 'Active', 404);
        $product->load(['category', 'unit', 'vendor.user', 'images', 'media', 'variants', 'availabilityCountries', 'priceTiers']);
        $marketplaceSelection = MarketplaceCountry::selection();
        $availableInCountry = $product->isAvailableIn($marketplaceSelection);
        $availableForPurchase = !Auth::check() || $product->isAvailableIn(MarketplaceCountry::purchaseCountry());
        abort_if(Auth::check() && !$availableInCountry, 404);
        return view('marketplace.product', compact('product', 'availableInCountry', 'availableForPurchase'));
    }

    public function store(Vendor $vendor)
    {
        $vendor->load('user');
        $products = $vendor->products()->where('status', 'Active')->with(['images', 'media', 'category', 'priceTiers']);
        $country = MarketplaceCountry::filterValue();
        MarketplaceCountry::availableQuery($products, $country);
        return view('marketplace.store', ['store' => $vendor, 'products' => $products->paginate(12)]);
    }

    /*
     * Route contract for main route wiring:
     * marketplace.favorite.add/remove, marketplace.cart.add/update/remove,
     * marketplace.checkout.place, marketplace.profile.update, marketplace.settings.update.
     */
    private function cartForUser(): Cart
    {
        abort_unless(Auth::check(), 403);
        return Cart::firstOrCreate(['user_id' => Auth::id()]);
    }

    public function cart()
    {
        $cart = null;
        if (Auth::check()) {
            $cart = $this->cartForUser()->load('items.product.images', 'items.product.media', 'items.product.availabilityCountries', 'items.product.priceTiers');
            $cart->setRelation('items', $cart->items->filter(fn ($item) => $item->product
                && $item->product->status === 'Active'
                && $item->product->isAvailableIn(MarketplaceCountry::purchaseCountry()))->values());
        }
        return view('marketplace.cart', ['cart' => $cart,
            'marketplaceCountry' => MarketplaceCountry::purchaseCountry()]);
    }

    public function addToCart(Request $request, Product $product)
    {
        abort_unless(Auth::check(), 403);
        abort_unless($product->status === 'Active' && $product->product_stock > 0 && $product->isAvailableIn(MarketplaceCountry::purchaseCountry()), 422, __('marketplace.not_available_country'));
        $data = $request->validate(['quantity' => ['required', 'integer', 'min:'.$product->minimum_order_quantity, 'max:1000']]);
        abort_if($data['quantity'] > $product->product_stock, 422, 'Requested quantity is not available.');
        $cart = $this->cartForUser();
        $item = CartItem::firstOrNew(['cart_id' => $cart->id, 'product_id' => $product->id]);
        $item->quantity = min($product->product_stock, ($item->exists ? $item->quantity : 0) + $data['quantity']);
        $item->save();
        return back()->with('messege', 'Item added to your cart.');
    }

    public function updateCart(Request $request, CartItem $item)
    {
        abort_unless(Auth::check() && (int) $item->cart->user_id === (int) Auth::id(), 403);
        $data = $request->validate(['quantity' => ['required', 'integer', 'min:'.$item->product->minimum_order_quantity, 'max:1000']]);
        $product = $item->product;
        abort_unless($product && $product->status === 'Active' && $product->product_stock >= $data['quantity'] && $data['quantity'] >= $product->minimum_order_quantity && $product->isAvailableIn(MarketplaceCountry::purchaseCountry()), 422, __('marketplace.not_available_country'));
        $item->update(['quantity' => $data['quantity']]);
        return back()->with('messege', 'Cart updated.');
    }

    public function removeFromCart(CartItem $item)
    {
        abort_unless(Auth::check() && (int) $item->cart->user_id === (int) Auth::id(), 403);
        $item->delete();
        return back()->with('messege', 'Item removed from your cart.');
    }

    public function checkout()
    {
        $cart = null;
        if (Auth::check()) {
            $cart = $this->cartForUser()->load('items.product', 'items.product.availabilityCountries');
            $cart->setRelation('items', $cart->items->filter(fn ($item) => $item->product
                && $item->product->status === 'Active'
                && $item->product->isAvailableIn(MarketplaceCountry::purchaseCountry()))->values());
        }
        return view('marketplace.checkout', ['cart' => $cart,
            'countries' => MarketplaceCountry::names(),
            'marketplaceCountry' => MarketplaceCountry::purchaseCountry()]);
    }

    public function placeOrder(Request $request)
    {
        abort_unless(Auth::check(), 403);
        $data = $request->validate([
            'delivery_address' => ['required', 'string', 'max:2000'],
            'delivery_country' => ['nullable', 'string', 'size:2', Rule::in(array_keys(MarketplaceCountry::supported()))],
        ]);
        $destinationCountry = MarketplaceCountry::purchaseCountry($request);
        $requestedDeliveryCountry = MarketplaceCountry::normalize($data['delivery_country'] ?? null);
        abort_if($requestedDeliveryCountry !== null && $requestedDeliveryCountry !== $destinationCountry, 422, __('marketplace.country_checkout_unavailable'));
        DB::transaction(function () use ($data, $destinationCountry) {
            $cart = Cart::where('user_id', Auth::id())->lockForUpdate()->first();
            $items = $cart ? $cart->items()->lockForUpdate()->get() : collect();
            abort_if($items->isEmpty(), 422, 'Your cart is empty.');
            $productIds = $items->pluck('product_id')->unique()->sort()->values();
            $products = Product::whereIn('id', $productIds)->orderBy('id')->lockForUpdate()->get()->keyBy('id');
            $subTotal = 0; $shipping = 0;
            foreach ($items as $item) {
                $product = $products->get($item->product_id);
                abort_unless($product && $product->status === 'Active' && $product->product_stock >= $item->quantity && $item->quantity >= $product->minimum_order_quantity, 422, __('marketplace.minimum_order_unavailable'));
                abort_unless($product->isAvailableIn($destinationCountry), 422, __('marketplace.country_checkout_unavailable'));
                $subTotal += $product->priceForQuantity($item->quantity) * $item->quantity;
                $shipping += $product->is_delivery_free ? 0 : $product->delivery_charge;
            }
            do { $number = 'FX-' . now()->format('Ymd') . '-' . Str::upper(Str::random(8)); } while (Orderdetail::where('order_no', $number)->exists());
            $order = Orderdetail::create([
                'user_id' => Auth::id(), 'payment_method' => 'Direct with seller', 'order_no' => $number,
                'delivery_address' => $data['delivery_address'], 'delivery_country' => $destinationCountry, 'sub_total' => $subTotal, 'shipping_cost' => $shipping,
                'tax' => 0, 'tax_percentage' => 0, 'total_cost' => $subTotal + $shipping, 'to_receive' => $subTotal + $shipping,
                'to_send' => 0, 'to_pay' => $subTotal + $shipping, 'date' => now()->toDateString(), 'time' => now()->format('H:i:s'),
                'month' => now()->format('F'), 'year' => now()->format('Y'), 'status' => 'Pending',
            ]);
            foreach ($items as $item) {
                $product = $products->get($item->product_id);
                Order::create(['orderdetail_id' => $order->id, 'vendor_id' => $product->vendor_id, 'product_id' => $product->id,
                    'product_price' => $product->priceForQuantity($item->quantity), 'product_quantity' => $item->quantity,
                    'unit_total_price' => $product->priceForQuantity($item->quantity) * $item->quantity, 'variants' => json_encode($item->variants),
                    'return_available' => $product->return_available, 'shipping_cost' => $product->is_delivery_free ? 0 : $product->delivery_charge, 'status' => 'Pending']);
                $product->decrement('product_stock', $item->quantity);
            }
            $cart->items()->delete();
        });
        return redirect()->route('marketplace.orders')->with('messege', __('marketplace.purchase_request_sent'));
    }

    public function favorites()
    {
        $favorites = collect();
        if (Auth::check()) {
            $favorites = Favorite::with('product.images', 'product.availabilityCountries')
                ->where('user_id', Auth::id())->latest()->get()
                ->filter(fn ($favorite) => $favorite->product
                    && $favorite->product->status === 'Active'
                    && $favorite->product->isAvailableIn(MarketplaceCountry::purchaseCountry()))
                ->values();
        }
        return view('marketplace.favorites', ['favorites' => $favorites]);
    }

    public function addFavorite(Product $product)
    {
        abort_unless(Auth::check() && $product->status === 'Active' && $product->isAvailableIn(MarketplaceCountry::purchaseCountry()), 422, __('marketplace.not_available_country'));
        Favorite::firstOrCreate(['user_id' => Auth::id(), 'product_id' => $product->id]);
        return back()->with('messege', 'Item saved to favorites.');
    }

    public function removeFavorite(Favorite $favorite)
    {
        abort_unless(Auth::check() && (int) $favorite->user_id === (int) Auth::id(), 403);
        $favorite->delete();
        return back()->with('messege', 'Item removed from favorites.');
    }

    public function orders()
    {
        return view('marketplace.orders', ['orders' => Auth::check()
            ? Orderdetail::with('orders.product')->where('user_id', Auth::id())->latest()->paginate(12)
            : collect()]);
    }

    public function order(Orderdetail $order)
    {
        abort_unless(Auth::check() && (int) $order->user_id === (int) Auth::id(), 403);
        $order->load('orders.product', 'orders.vendor.user');
        return view('marketplace.order', compact('order'));
    }

    public function profile() { return view('marketplace.profile', ['user' => Auth::user(), 'countries' => MarketplaceCountry::names()]); }
    public function updateProfile(Request $request)
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'phone' => ['nullable', 'string', 'max:50'],
            'address' => ['nullable', 'string', 'max:1000'],
            'city' => ['nullable', 'string', 'max:255'],
        ]);
        Auth::user()->update($data);
        return back()->with('messege', 'Profile updated.');
    }
    public function settings() { return view('marketplace.settings', ['user' => Auth::user(), 'countries' => MarketplaceCountry::names()]); }
    public function updateSettings(Request $request)
    {
        $data = $request->validate([
            'city' => ['nullable', 'string', 'max:255'],
        ]);
        Auth::user()->update($data);
        return back()->with('messege', __('marketplace.account_country_locked'));
    }
    public function messages() { return view('marketplace.messages', ['messages' => Auth::check() ? Message::with('sender')->where('recipient_id', Auth::id())->latest()->paginate(20) : collect()]); }
    public function notifications() { return view('marketplace.notifications', ['notifications' => Auth::check() ? MarketplaceNotification::where('user_id', Auth::id())->latest()->paginate(20) : collect()]); }
}