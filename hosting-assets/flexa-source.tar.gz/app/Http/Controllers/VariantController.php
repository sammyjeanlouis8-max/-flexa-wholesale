<?php

namespace App\Http\Controllers;

use App\Models\Variant;
use Illuminate\Http\Request;
use App\Services\VariantService;
use App\Http\Requests\StoreVariantRequest;
use App\Http\Requests\UpdateVariantRequest;
use DataTables;
class VariantController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    protected $variant;

    public function __construct(VariantService $variant)
    {
        $this->variant = $variant; 
        $this->middleware('auth_check'); 
    }

    public function index(Request $request)
    {
        try {
            if ($request->ajax()) {
                $variants = $this->variant->variants($request);
                return Datatables::of($variants)
                    ->addIndexColumn()
                    ->addColumn('category', function ($row) {
                        return $row->category->category_name;
                    })
                    ->addColumn('action', function ($row) {
                        $btn = "";
                        $btn .= '&nbsp;';

                        $btn .= ' <a href="' . route('variants.show', $row->id) . '" class="btn btn-primary btn-sm action-button"><i class="fa fa-edit"></i></a>';
                        $btn .= '&nbsp;';
                        $btn .= ' <a href="#" class="btn btn-danger btn-sm delete-variant action-button" data-id="' . $row->id . '"><i class="fa fa-trash"></i></a>';
                        return $btn;
                    })
                    
                    ->rawColumns(['action','category']) 
                    ->make(true);
            }
            return view('variants.index');
        }catch (Exception $e) {
            $message = $e->getMessage();
            $code = $e->getCode();
            $string = $e->__toString();
            return response()->json(['message' => $message, 'execption_code' => $code, 'execption_string' => $string]);
            exit;
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('variants.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreVariantRequest $request)
    {
        try
        {
            $this->variant->storeVariant($request);
            $notification = array(
                'messege' => "Successfully variant has been added",
                'alert-type' => 'success'
            );
            return redirect()->back()->with($notification);
        }catch (Exception $e) {
            $message = $e->getMessage();
            $code = $e->getCode();
            $string = $e->__toString();
            return response()->json(['message' => $message, 'execption_code' => $code, 'execption_string' => $string]);
            exit;
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Variant  $variant
     * @return \Illuminate\Http\Response
     */
    public function show(Variant $variant)
    {   
        return view('variants.edit', compact('variant'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Variant  $variant
     * @return \Illuminate\Http\Response
     */
    public function edit(Variant $variant)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Variant  $variant
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateVariantRequest $request, Variant $variant)
    {
        try
        {
            $this->variant->updateVariant($request,$variant);
             $notification = array(
                'messege' => "Successfully the variant has been updated",
                'alert-type' => 'success'
            );
            return redirect('/variants')->with($notification);
        }catch (Exception $e) {
            $message = $e->getMessage();
            $code = $e->getCode();
            $string = $e->__toString();
            return response()->json(['message' => $message, 'execption_code' => $code, 'execption_string' => $string]);
            exit;
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Variant  $variant
     * @return \Illuminate\Http\Response
     */
    public function destroy(Variant $variant)
    {
        try
        {
            $this->variant->deleteVariant($variant);
            return response()->json(['status'=>true, 'message'=>'Successfully the variant has been deleted']);
        }catch (Exception $e) {
         throw $e;
            exit;
        }
    }
    public function getVariantsCategoryWise($categoryId){
        $variants = Variant::select([
            'id',
            'variant_name',
            'variant_value'
        ])->where('category_id',$categoryId)
            ->latest()
            ->get();
        $variants->transform(function ($variant) {
            $variant->variant_value = explode(',', $variant->variant_value);
            return $variant;
        });


        return response()->json(['status' => true, 'data' => $variants]);
    }
    public function getVariantValues($variantId){
            $values = variantExplodes($variantId);
    return response()->json($values);
    }
}
