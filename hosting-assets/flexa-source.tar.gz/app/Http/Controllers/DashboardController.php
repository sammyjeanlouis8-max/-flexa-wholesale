<?php

namespace App\Http\Controllers;

use App\Models\Orderdetail;
use App\Models\Product;
use App\Models\User;
use App\Models\WithdrawRequestLog;
use App\Models\Vendor;
use Illuminate\Http\Request;
use Auth;
use Exception;

class DashboardController extends Controller
{
    public function Dashboard()
    {
        try {
            // Count users with role_id 3
            $totalUser = User::where('role_id', 3)->count();

            // Count vendors with role_id 2
            $totalVendor = User::where('role_id', 2)->count();

            // Count pending withdrawal requests
            $newWithdrawRequest = WithdrawRequestLog::where('status', 'Pending')->count();

            // Count total products
            $totalProduct = Product::count();

            // Count today's orders
            $todaysOrder = Orderdetail::whereDate('created_at', today())->count();

            // Count total pending orders
            $totalPendingOrder = Orderdetail::whereNotIn('status', ['Canceled', 'Delivered'])->count();

            // Count total completed orders
            $totalCompletedOrder = Orderdetail::where('status', 'Delivered')->count();

            // Count total orders
            $totalOrder = Orderdetail::count();

            // Pass the data to the view
            return view('layouts.app', compact(
                'totalUser',
                'totalVendor',
                'newWithdrawRequest',
                'totalProduct',
                'todaysOrder',
                'totalPendingOrder',
                'totalCompletedOrder',
                'totalOrder'
            )
            );
        } catch (Exception $e) {
            report($e);
            abort(500, 'Unable to load dashboard.');
        }
    }

    public function buyer()
    {
        $user = Auth::user();
        return view('dashboard.simple', ['title' => 'Buyer Dashboard', 'stats' => [
            'Orders' => Orderdetail::where('user_id', $user->id)->count(),
            'Pending orders' => Orderdetail::where('user_id', $user->id)->whereNotIn('status', ['Canceled', 'Delivered'])->count(),
        ]]);
    }

    public function seller()
    {
        $vendor = Auth::user()->vendor;
        abort_unless($vendor, 403);
        return view('dashboard.simple', ['title' => 'Seller Dashboard', 'stats' => [
            'Products' => Product::where('vendor_id', $vendor->id)->count(),
            'Orders' => Orderdetail::whereHas('orders', fn ($q) => $q->where('vendor_id', $vendor->id))->count(),
        ]]);
    }
}

