<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Models\Permission;
use App\Services\AdminActivityLogger;

class AdminController extends Controller
{
    public function index()
    {
        $admins = User::whereIn('role', ['admin', 'owner'])
            ->with('permissions')
            ->orderByDesc('is_primary_admin')
            ->orderBy('name')
            ->get();
        $eligibleUsers = User::whereNotIn('role', ['admin', 'owner'])
            ->with('capabilities', 'vendor')->orderBy('name')->get();
        $permissions = Permission::orderBy('key')->get();
        $activityLogs = \App\Models\AdminActivityLog::with(['actor', 'target'])
            ->latest('created_at')->limit(50)->get();
        return view('admins.index', compact('admins', 'eligibleUsers', 'permissions', 'activityLogs'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'email', 'max:255', 'unique:users,email'],
            'password' => ['required', 'string', 'min:6', 'confirmed'],
            'permissions' => ['array'],
            'permissions.*' => ['integer', 'exists:permissions,id'],
        ]);

        $admin = new User();
        $admin->name = $data['name'];
        $admin->email = $data['email'];
        $admin->password = Hash::make($data['password']);
        $admin->role = 'admin';
        $admin->is_primary_admin = false;
        $admin->image = 'uploads/users/user.png';
        $admin->status = 'Active';
        $admin->save();
        $admin->permissions()->sync($data['permissions'] ?? []);
        app(AdminActivityLogger::class)->record(Auth::user(), 'admin.created', $admin, ['permission_ids' => $data['permissions'] ?? []]);

        return redirect()->route('admin-management.index')->with([
            'messege' => __('admin.account_added'),
            'alert-type' => 'success',
        ]);
    }

    public function promote(Request $request)
    {
        $data = $request->validate(['user_id' => ['required', 'exists:users,id'], 'permissions' => ['array'], 'permissions.*' => ['integer', 'exists:permissions,id']]);
        $user = User::findOrFail($data['user_id']);
        abort_if($user->is_primary_admin || $user->id === Auth::id(), 403);
        $user->role = 'admin';
        $user->save();
        $user->permissions()->sync($data['permissions'] ?? []);
        app(AdminActivityLogger::class)->record(Auth::user(), 'admin.promoted', $user, ['permission_ids' => $data['permissions'] ?? []]);
        return redirect()->route('admin-management.index')->with('messege', __('admin.user_promoted'));
    }

    public function update(Request $request, User $admin)
    {
        abort_if($admin->is_primary_admin || $admin->id === Auth::id(), 403);
        $data = $request->validate(['account_status' => ['required', 'in:active,inactive'], 'permissions' => ['array'], 'permissions.*' => ['integer', 'exists:permissions,id']]);
        abort_unless($admin->role === 'admin', 404);
        $beforeStatus = $admin->account_status;
        $beforePermissions = $admin->permissions()->pluck('id')->all();
        $admin->account_status = $data['account_status'];
        $admin->save();
        $admin->permissions()->sync($data['permissions'] ?? []);
        if ($beforeStatus !== $admin->account_status) {
            app(AdminActivityLogger::class)->record(Auth::user(), $admin->isActive() ? 'admin.restored' : 'admin.suspended', $admin);
        }
        $requestedPermissions = $this->normalizedPermissions($data['permissions'] ?? []);
        if ($this->normalizedPermissions($beforePermissions) !== $requestedPermissions) {
            app(AdminActivityLogger::class)->record(Auth::user(), 'admin.permissions_changed', $admin, ['permission_ids' => $requestedPermissions]);
        }
        return redirect()->route('admin-management.index')->with('messege', __('admin.updated'));
    }

    public function destroy(User $admin)
    {
        if ($admin->role !== 'admin' || $admin->is_primary_admin || $admin->role === 'owner' || $admin->id == Auth::id()) {
            return redirect()->route('admin-management.index')->with([
                'messege' => __('admin.primary_protected'),
                'alert-type' => 'error',
            ]);
        }

        $this->removeAdminRole($admin, 'admin.removed');

        return redirect()->route('admin-management.index')->with([
            'messege' => __('admin.account_removed'),
            'alert-type' => 'success',
        ]);
    }

    /** Demotion intentionally restores a customer-facing compatibility role. */
    public function demote(User $admin)
    {
        if ($admin->role !== 'admin' || $admin->is_primary_admin || $admin->id === Auth::id()) {
            return redirect()->route('admin-management.index')->withErrors(['admin' => __('admin.cannot_demote')]);
        }
        $this->removeAdminRole($admin, 'admin.demoted');
        return redirect()->route('admin-management.index')->with('messege', __('admin.access_removed'));
    }

    public function suspend(User $admin)
    {
        return $this->setStatus($admin, 'inactive');
    }

    public function restore(User $admin)
    {
        return $this->setStatus($admin, 'active');
    }

    private function setStatus(User $admin, string $status)
    {
        if ($admin->role !== 'admin' || $admin->is_primary_admin || $admin->id === Auth::id()) {
            return redirect()->route('admin-management.index')->withErrors(['admin' => __('admin.cannot_change')]);
        }
        $admin->account_status = $status;
        $admin->save();
        app(AdminActivityLogger::class)->record(Auth::user(), $status === 'active' ? 'admin.restored' : 'admin.suspended', $admin);
        return redirect()->route('admin-management.index')->with('messege', __('admin.status_updated'));
    }

    private function removeAdminRole(User $admin, string $action): void
    {
        $wasAdmin = $admin->role === 'admin' || $admin->permissions()->exists();
        $isSeller = $admin->vendor()->exists() || $admin->hasCapability('seller');
        $admin->permissions()->detach();
        $admin->role = $isSeller ? 'seller' : 'buyer';
        $admin->save();
        $admin->assignCapabilities($isSeller ? ['buyer', 'seller'] : ['buyer']);
        if ($wasAdmin) {
            app(AdminActivityLogger::class)->record(Auth::user(), $action, $admin, ['role' => $admin->role]);
        }
    }

    private function normalizedPermissions(array $permissionIds): array
    {
        $permissionIds = array_values(array_unique(array_map('intval', $permissionIds)));
        sort($permissionIds);
        return $permissionIds;
    }

}