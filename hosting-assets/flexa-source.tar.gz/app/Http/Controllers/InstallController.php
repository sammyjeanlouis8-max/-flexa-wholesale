<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Artisan;
use App\Models\User;
use App\Http\Requests\NewUserRequest;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Validator;

class InstallController extends Controller
{
    public function install()
    {
        if ($this->adminExists()) {
            return $this->installationClosedResponse();
        }

        return view('install.create_project');
    }

    public function storeInfo(Request $request)
    {
        if ($this->adminExists()) {
            return $this->installationClosedResponse();
        }

        try {

            $db_name = env('DB_DATABASE');

            $app_url = env('APP_URL');

            $db_username = env('DB_USERNAME');

            $db_password = env('DB_PASSWORD');

            $timezone = env('SELECT_TIMEZONE');

            $path = base_path('.env');
            $test = file_get_contents($path);

            if (file_exists($path)) {
                $replacements = [

                    "DB_DATABASE=$db_name" => "DB_DATABASE=$request->db_name",
                    "APP_URL=$app_url" => "APP_URL=$request->domain_url",
                    "DB_USERNAME=$db_username" => "DB_USERNAME=$request->db_user",
                    "DB_PASSWORD=$db_password" => "DB_PASSWORD=$request->db_password",
                    "SELECT_TIMEZONE=$timezone" => "SELECT_TIMEZONE=$request->timezone",
                ];

                foreach ($replacements as $search => $replace) {
                    $test = str_replace($search, $replace, $test);
                }

                file_put_contents($path, $test);
            }

            return redirect('/admin-register');
        } catch (Exception $e) {

            $message = $e->getMessage();

            $code = $e->getCode();

            $string = $e->__toString();
            return response()->json(['message' => $message, 'execption_code' => $code, 'execption_string' => $string]);
            exit;
        }
    }


    public function register()
    {
        try {
            if ($this->adminExists()) {
                return $this->installationClosedResponse();
            }

            Artisan::call("migrate");
            loadDB();
            return view('admin_register');
        } catch (Exception $e) {

            $message = $e->getMessage();

            $code = $e->getCode();

            $string = $e->__toString();
            return response()->json(['message' => $message, 'execption_code' => $code, 'execption_string' => $string]);
            exit;
        }
    }


    public function registerAdmin(Request $request)
    {
        if ($this->adminExists()) {
            return $this->installationClosedResponse();
        }

        $validator = Validator::make($request->all(), [
            'name' => 'required|string',
            'email' => 'required|email|unique:users',
            'password' => 'required_with:confirm_password|same:confirm_password',
            'confirm_password' => 'required|string'
        ]);

        if ($validator->fails()) {
            $messages = $validator->errors()->all(); // Collect all error messages
            $notification = array(
                'messege' => 'Validation Error: ' . implode(' ', $messages), // Concatenate messages
                'alert-type' => 'error'
            );
    
            return redirect()->back()->with($notification);
        }
        try {
            $user = new User();
            $user->name = $request->name;
            $user->company_name = null;
            $user->role_id = 1;
            $user->is_primary_admin = true;
            $user->email = $request->email;
            $user->password = bcrypt($request->password);
            $user->image = "uploads/users/user.png";
            $user->save();
            loadDB();
            return redirect('/');

        } catch (Exception $e) {

            $message = $e->getMessage();

            $code = $e->getCode();

            $string = $e->__toString();
            return response()->json(['message' => $message, 'execption_code' => $code, 'execption_string' => $string]);
            exit;
        }
    }

    private function adminExists()
    {
        return Schema::hasTable('users') && User::where('role_id', 1)->exists();
    }

    private function installationClosedResponse()
    {
        return redirect('/')->with([
            'messege' => 'The primary admin is already configured.',
            'alert-type' => 'error',
        ]);
    }
}
