<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\Orderdetail;
use App\Models\PaymentMethod;
use App\Models\Setting;
use App\Models\Refund;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use DataTables;
use Illuminate\Support\Facades\Hash;
use App\Services\AdminActivityLogger;
class SettingController extends Controller
{
    public function getSettings()
    {
        $settings = Setting::first() ?? new Setting([
            'app_name' => 'Flexa Wo Seller',
            'app_logo' => 'custom/flexa-wo-seller-logo.png',
            'currency' => 'USD',
            'currency_code' => 'USD',
            'currency_symbol' => '$',
        ]);
        $paymentMethods = PaymentMethod::first() ?? new PaymentMethod();
        return view('settings', compact('settings', 'paymentMethods'));
    }
    public function updateSettings(Request $request)
    {

        DB::beginTransaction();

        try {
           

            // Update settings
            $settings = Setting::first(); // Assuming there's only one settings record
            $settings->app_name = $request->input('app_name');
            $settings->currency = $request->input('currency');
            $settings->currency_code = $request->input('currecny_code');
            $settings->currency_symbol = $request->input('currency_symbol');
            $settings->tax = $request->input('tax');
            $settings->withdraw_charge = $request->input('withdraw_charge');
            $settings->contact_email = $request->input('contact_email');
            $settings->contact_phone_first = $request->input('contact_phone_first');
            $settings->contact_phone_second = $request->input('contact_phone_second');

            if ($request->hasFile('app_logo')) {
                // Delete old image if exists
                if ($settings->app_logo && file_exists(public_path($settings->app_logo))) {
                    unlink(public_path($settings->app_logo));
                }

                // Store new image
                $image = $request->file('app_logo');
                $imageName = time() . '_' . $image->getClientOriginalName();
                $image->move(public_path('uploads'), $imageName);
                $settings->app_logo = 'uploads/' . $imageName;
            }

            $settings->save();

            // Update payment methods
            $paymentMethods = PaymentMethod::firstOrNew(); // Assuming there's only one payment methods record
            $paymentMethods->razor_key = $request->input('razor_key');
            $paymentMethods->stripe_publish_key = $request->input('stripe_publish_key');
            $paymentMethods->stripe_secret_key = $request->input('stripe_secret_key');
            $paymentMethods->save();

            // Commit transaction
            DB::commit();
            app(AdminActivityLogger::class)->record(Auth::user(), 'settings.updated', $settings, [
                'currency_code' => $settings->currency_code,
                'tax_changed' => true,
                'payment_configuration_changed' => true,
            ]);



            $notification = array(
                'messege' => 'Settings Updated Successfully',
                'alert-type' => 'success'
            );

            return redirect()->back()->with($notification);
        } catch (Exception $e) {
            DB::rollBack();
            Log::error('message', [
                'message' => $e->getMessage(),
                'exception_code' => $e->getCode(),
                'exception_string' => $e->__toString(),
            ]);
            $notification = array(
                'messege' => 'Something Went Wrong',
                'alert-type' => 'error'
            );

            return redirect()->back()->with($notification)->withInput();
        }
    }
 public function showSettingsPage()
    {
        $user = Auth::user();
        return view('admin_settings', [
            'user' => $user,
        ]);
    }

    public function updateProfile(Request $request)
    {
       // Define validation rules
    $rules = [
        'name' => 'required|string|max:255',
        'email' => 'required|string|email|max:255',
        'image' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
    ];

    // Validate the request
    $validator = \Validator::make($request->all(), $rules);

    if ($validator->fails()) {
        // Collect validation errors
        $errors = $validator->errors()->all();

        // Format errors into a single message string
        $errorMessages = implode(', ', $errors);

        // Prepare notification array with errors
        $notification = [
            'messege' => $errorMessages,
            'alert-type' => 'error'
        ];

        return redirect()->route('admin.settings')->with($notification);
    }

        try {
            $user = Auth::user();
            $user->name = $request->input('name');

            if ($request->hasFile('image')) {
                // Delete old image if exists
                if ($user->image && file_exists(public_path($user->image))) {
                    unlink(public_path($user->image));
                }

                // Store new image
                $image = $request->file('image');
                $imagePath = $image->store('images/profile', 'public');
                $user->image = $imagePath;
            }
            $user->save();

 $notification = array(
                'messege' => 'Profile updated successfully',
                'alert-type' => 'success'
            );
            return redirect()->route('admin.settings')->with($notification);
        } catch (Exception $e) {
                $notification = array(
                'messege' => 'Something Went Wrong',
                'alert-type' => 'error'
            );
            return redirect()->route('admin.settings')->with($notification);
        }
    }

    public function updatePassword(Request $request)
    {
          $validator = \Validator::make($request->all(), [
        'current_password' => 'required|string',
        'new_password' => 'required|string|min:6|confirmed',
    ]);

    if ($validator->fails()) {
        // Collect validation errors
        $errors = $validator->errors()->all();

        // Format errors into a single message string
        $errorMessages = implode(', ', $errors);

        // Prepare notification array with errors
        $notification = [
            'messege' => $errorMessages,
            'alert-type' => 'error'
        ];

        return redirect()->route('admin.settings')->with($notification);
    }

        try {
            $user = Auth::user();

            // Check if the current password is correct
            if (!Hash::check($request->input('current_password'), $user->password)) {
                  $notification = [
            'messege' => 'Current password is incorrect.',
            'alert-type' => 'error'
        ];
                
                return redirect()->route('admin.settings')->with($notification);
            }

            // Update password
            $user->password = Hash::make($request->input('new_password'));
            $user->save();
   $notification = array(
                'messege' => 'Password updated successfully',
                'alert-type' => 'success'
            );
            return redirect()->route('admin.settings')->with($notification);
        } catch (Exception $e) {
               $notification = array(
                'messege' => 'Something Went Wrong',
                'alert-type' => 'error'
            );
            return redirect()->route('admin.settings')->with($notification);
        }
    }
    public function orders(Request $request)
    {
        try {
            Log::info('Orders method called');
            if ($request->ajax()) {
                Log::info('AJAX request detected');
                $orders = Orderdetail::with('user')->latest();
                // Apply search filter
                if ($request->get('search')) {
                    $search = $request->get('search');
                    $orders->where(function ($query) use ($search) {
                        $query->where('order_no', 'LIKE', "%{$search}%")
                            ->orWhereHas('user', function ($query) use ($search) {
                                $query->where('name', 'LIKE', "%{$search}%");
                            });
                    });
                }
                // Apply status filter
                if ($request->get('status')) {
                    $status = $request->get('status');
                    $orders->where('status', $status);
                }

                // Apply date filters
                if ($request->get('fromDate')) {
                    $fromDate = $request->get('fromDate');
                    $orders->whereDate('created_at', '>=', $fromDate);
                }
                if ($request->get('toDate')) {
                    $toDate = $request->get('toDate');
                    $orders->whereDate('created_at', '<=', $toDate);
                }

                return Datatables::of($orders)
                    ->addIndexColumn()
                    ->addColumn('user_name', function ($row) {
                        return $row->user->name ?? 'n/a';
                    })
                    ->addColumn('status', function ($row) {
                        if ($row->status == 'Cancelled') {
                            return '<span class="badge bg-danger text-white">Canceled</span>';
                        }  elseif ($row->status == 'Delivered') {
                            return '<span class="badge bg-success text-white">Delivered</span>';
                        } else {
                            $statusDropdown = '<select class="form-control order-status-dropdown" data-id="' . $row->id . '">
                            <option value="Order Placed"' . ($row->status == 'Order Placed' ? 'selected' : '') . '>Order Placed</option>
                            <option value="Cancelled"' . ($row->status == 'Cancelled' ? 'selected ' : '') . '>Cancelled</option>
                            <option value="Shipped"' . ($row->status == 'Shipped' ? 'selected' : '') . ' disabled>Shipped</option>
                             <option value="Out of Delivery"' . ($row->status == 'Out of Delivery' ? 'selected' : '') . '>Out of Delivery</option>
                            <option value="Delivered"' . ($row->status == 'Delivered' ? 'selected' : '') . '>Delivered</option>
                        </select>';
                            return $statusDropdown;
                        }
                    })
                    ->addColumn('action', function ($row) {
                        $btn = "";
                        $btn .= '&nbsp;';
                        $btn .= ' <a href="#" class="btn btn-primary btn-sm action-button show-details" data-id="' . $row->id . '"><i class="fa fa-eye"></i></a>';
                        $btn .= '&nbsp;';
                        $btn .= ' <a href="#" class="btn btn-danger btn-sm delete-order action-button" data-id="' . $row->id . '"><i class="fa fa-trash"></i></a>';
                        return $btn;
                    })
                    ->rawColumns(['action', 'user_name', 'status'])
                    ->make(true);
            }
            return view('orders');
        } catch (Exception $e) {
            Log::error('message', [
                'message' => $e->getMessage(),
                'exception_code' => $e->getCode(),
                'exception_string' => $e->__toString(),
            ]);
            $message = $e->getMessage();
            $code = $e->getCode();
            $string = $e->__toString();
            return response()->json(['message' => $message, 'execption_code' => $code, 'execption_string' => $string]);
            exit;
        }
    }
    public function showOrderDetails($id)
    {
        try {
            $order = Orderdetail::with('user', 'orders')->findOrFail($id);
            $orderDetails = view('order_details_partial', compact('order'))->render();
            return response()->json($orderDetails);
        } catch (Exception $e) {
            Log::error('Error fetching order details', [
                'message' => $e->getMessage(),
                'exception_code' => $e->getCode(),
                'exception_string' => $e->__toString(),
            ]);
            return response()->json(['message' => 'Error fetching order details.'], 500);
        }
    }
     public function updateOrderStatus(Request $request, $id)
    {
        try {
            DB::beginTransaction();

            // Find the order detail
            $orderDetail = Orderdetail::findOrFail($id);
            $oldStatus = $orderDetail->status;
            $orderDetailsOrder = Order::where('orderdetail_id', $orderDetail->id);
            if ($request->status == "Shipped") {

            }
            // If the order status is delivered, update the vendor's balance
            if ($request->input('status') == 'Delivered') {
                if (
                    $orderDetail->orders()
                        ->where('status', 'Pending')
                        ->count() > 0
                ) {
                    return response()->json([
                        'error' => "There is still some order remaining to be accepted by vendor."
                    ], 500);
                } elseif ($orderDetail->status != 'Out of Delivery') {

                    return response()->json([
                        'error' => "The order is not ready to be delivered."
                    ], 500);
                }
                $orderDetail->to_send = 0;
                $orderDetail->to_receive = 0;
                $orderDetail->to_pay = 0;
                $orders = $orderDetail->orders;

                foreach ($orders as $order) {
                    if ($order->status == 'Accepted') {
                        $vendor = $order->vendor;
                        $vendor->balance += $order->unit_total_price;
                        $vendor->save();
                    }
                }
            }

            if ($request->input('status') == 'Out of Delivery') {
                if (
                    $orderDetail->orders()
                        ->where('status', 'Pending')
                        ->count() > 0
                ) {
                    return response()->json([
                        'error' => "There is still some order remaining to be accepted by vendor."
                    ], 500);
                }
                $orderDetail->to_send = 0;
                $orderDetail->to_receive = 1;
            }
            if ($request->input('status') == 'Cancelled' && $orderDetail->payment_method == 'cod') {
                refund($orderDetail->user, $orderDetailsOrder->id);
                app(AdminActivityLogger::class)->record(Auth::user(), 'refund.initiated', $orderDetail, [
                    'reason' => 'order_cancelled', 'payment_method' => 'cod',
                ]);
            }
            if ($request->input('status') == 'Cancelled') {

                $orderDetail->to_send = 0;
                $orderDetail->to_receive = 0;

                $orderDetailsOrder->update(['status' => 'Declined']);

            }
                        $orderDetail->status = $request->input('status');

            $orderDetail->save();
            addStatusLog($request->input('status'), $orderDetail->id);

            DB::commit();
            app(AdminActivityLogger::class)->record(Auth::user(), 'order.status_updated', $orderDetail, [
                'old_status' => $oldStatus, 'new_status' => $orderDetail->status,
            ]);

            return response()->json([
                'success' => 'Order status updated successfully.'
            ]);
        } catch (Exception $e) {
            DB::rollBack();
            $message = $e->getMessage();
            $code = $e->getCode();
            $string = $e->__toString();
            return response()->json([
                'error' => $message,
                'execption_code' => $code,
                'execption_string' => $string
            ], 500);

        }
    }
    public function mailSettings()
    {
        return view('mail_settings');
    }


    public function settingsMail(Request $request)
    {
        try {

            customMail($request);


            $host = env('MAIL_HOST');

            $port = env('MAIL_PORT');

            $email = env('MAIL_USERNAME');

            $password = env('MAIL_PASSWORD');

            $encryption = env('MAIL_ENCRYPTION');

            $from_address = env('MAIL_FROM_ADDRESS');


            $path = base_path('.env');
            $test = file_get_contents($path);

            if (file_exists($path)) {
                $replacements = [

                    "MAIL_HOST=$host" => "MAIL_HOST=$request->mail_host",
                    "MAIL_PORT=$port" => "MAIL_PORT=$request->mail_port",
                    "MAIL_USERNAME=$email" => "MAIL_USERNAME=$request->email",
                    "MAIL_PASSWORD=$password" => "MAIL_PASSWORD=$request->password",
                    "MAIL_ENCRYPTION=$encryption" => "MAIL_ENCRYPTION=$request->mail_encryption",

                    "MAIL_FROM_ADDRESS=$from_address" => "MAIL_FROM_ADDRESS=$request->email",

                    // Add more key-value pairs for other replacements if needed
                ];

                foreach ($replacements as $search => $replace) {
                    $test = str_replace($search, $replace, $test);
                }

                file_put_contents($path, $test);
            }
            app(AdminActivityLogger::class)->record(Auth::user(), 'mail.settings_updated', Setting::class, [
                'host_changed' => $request->filled('mail_host'),
                'port_changed' => $request->filled('mail_port'),
            ]);


            $notification = array(
                'messege' => "Successfully mail information has been added",
                'alert-type' => 'success'
            );

            return redirect()->back()->with($notification);
        } catch (Exception $e) {

            $message = $e->getMessage();

            $code = $e->getCode();

            $string = $e->__toString();
            return response()->json(['message' => $message, 'execption_code' => $code, 'execption_string' => $string]);
            exit;
        }
    }
    
        public function refundLogs(Request $request)
    {
        try {

            if ($request->ajax()) {
                $orderDetailIds = Refund::with('order.orderdetail')
                    ->get()
                    ->pluck('order.orderdetail.id')
                    ->unique()
                    ->toArray();
               $orderDetails = Orderdetail::whereIn('id', $orderDetailIds)
                            ->with(['orders.refund', 'user'])  // Eager load orders, refunds, and user
                            ->get();


                return Datatables::of($orderDetails)
                    ->addIndexColumn()
                    ->addColumn('user_name', function ($row) {
                        return $row->user->name ?? 'n/a';
                    })
                    ->addColumn('total_amount', function ($row) {
                        return $row->orders->sum(function($order) {
                            return $order->refund->total_amount ?? 0.00;
                        });
                    })
                    ->addColumn('action', function ($row) {
                        $btn = "";
                        $btn .= '&nbsp;';
                        $btn .= ' <a href="#" class="btn btn-info btn-sm show-refund-details action-button" data-id="' . $row->id . '" data-toggle="modal" data-target="#cardModal"><i class="fa fa-eye"></i></a>';

                        return $btn;
                    })
                    ->rawColumns(['action', 'user_name', 'total_amount'])
                    ->make(true);
            }
            return view('refunds');
        } catch (Exception $e) {

            $message = $e->getMessage();
            $code = $e->getCode();
            $string = $e->__toString();
            return response()->json(['message' => $message, 'execption_code' => $code, 'execption_string' => $string]);
            exit;
        }
    }
    public function getRefundDetails($id)
    {
        try {
$orders=Order::with('refund','vendor.user','product','orderdetail')
               ->where('orderdetail_id', $id)
               ->get();
            return response()->json($orders);
        } catch (Exception $e) {
            return response()->json(['error' => 'Failed to load refund details.'], 500);
        }
    }
}
