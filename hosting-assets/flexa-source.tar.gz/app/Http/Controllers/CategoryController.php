<?php

namespace App\Http\Controllers;

use App\Models\Category;
use Illuminate\Http\Request;
use App\Services\CategoryService;
use App\Http\Requests\StoreCategoryRequest;
use App\Http\Requests\UpdateCategoryRequest;
use DataTables;
class CategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    protected $category;

    public function __construct(CategoryService $category)
    {
        $this->category = $category;
        $this->middleware('auth_check');
    }

    public function index(Request $request)
    {
        try {
            if ($request->ajax()) {
                $categories = $this->category->categories();
                return Datatables::of($categories)
                    ->addIndexColumn()
                    ->addColumn('image', function ($row) {
                        return '<img class="img-fluid list-image" src="' . url('/') . "/" . $row->image . '">';
                    })
                    ->addColumn('status', function ($row) {
                        $statusBadge = ($row->status == 'Active') ? "<span class='badge badge-success status'>Active</span>" : "<span class='badge badge-danger status'>Inactive</span>";
                        return $statusBadge;
                    })
                    ->addColumn('action', function ($row) {
                        $btn = "";
                        $btn .= '&nbsp;';
                        $btn .= $row->status == 'Active' ?
                            ' <a href="#" class="btn btn-danger btn-sm decline-category action-button" data-id="' . $row->id . '"><i class="fa fa-ban"></i></a>' :
                            ' <a href="#" class="btn btn-primary btn-sm active-category action-button" data-id="' . $row->id . '"><i class="fa fa-check" aria-hidden="true"></i></a>';
                        $btn .= '&nbsp;';
                        $btn .= ' <a href="' . route('categories.show', $row->id) . '" class="btn btn-primary btn-sm action-button"><i class="fa fa-edit"></i></a>';
                        $btn .= '&nbsp;';
                        $btn .= ' <a href="#" class="btn btn-danger btn-sm delete-category action-button" data-id="' . $row->id . '"><i class="fa fa-trash"></i></a>';
                        return $btn;
                    })
                    ->rawColumns(['action', 'image', 'status'])
                    ->make(true);
            }
            return view('categories.index');
        }catch (Exception $e) {
            $message = $e->getMessage();
            $code = $e->getCode();
            $string = $e->__toString();
            return response()->json(['message' => $message, 'execption_code' => $code, 'execption_string' => $string]);
            exit;
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('categories.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreCategoryRequest $request)
    {
        try
        {
            $this->category->storeCategory($request);
            $notification = array(
                'messege' => "Successfully category has been added",
                'alert-type' => 'success'
            );
            return redirect()->back()->with($notification);
        }catch (Exception $e) {
            $message = $e->getMessage();
            $code = $e->getCode();
            $string = $e->__toString();
            return response()->json(['message' => $message, 'execption_code' => $code, 'execption_string' => $string]);
            exit;
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Category  $category
     * @return \Illuminate\Http\Response
     */
    public function show(Category $category)
    {
        return view('categories.edit', compact('category'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Category  $category
     * @return \Illuminate\Http\Response
     */
    public function edit(Category $category)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Category  $category
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateCategoryRequest $request, Category $category)
    {
        try
        {
            $this->category->updateCategory($request,$category);
            $notification = array(
                'messege' => "Successfully the category has been updated",
                'alert-type' => 'success'
            );
            return redirect('/categories')->with($notification);
        }catch (Exception $e) {
            $message = $e->getMessage();
            $code = $e->getCode();
            $string = $e->__toString();
            return response()->json(['message' => $message, 'execption_code' => $code, 'execption_string' => $string]);
            exit;
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Category  $category
     * @return \Illuminate\Http\Response
     */
    public function destroy(Category $category)
    {
        try
        {
            $this->category->deleteCategory($category);
            return response()->json(['status'=>true, 'message'=>'Successfully the category has been deleted']);
        }catch (Exception $e) {
          throw $e;
            exit;
        }
    }
}
