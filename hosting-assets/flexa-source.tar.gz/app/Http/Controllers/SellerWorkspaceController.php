<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Order;
use App\Models\Product;
use App\Models\ProductMedia;
use App\Support\MarketplaceCountry;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\UploadedFile;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;

class SellerWorkspaceController extends Controller
{
    private function vendor()
    {
        $vendor = Auth::user()?->vendor;
        abort_unless($vendor, 403, 'A seller store is required to access this workspace.');
        return $vendor;
    }

    public function dashboard()
    {
        $vendor = $this->vendor();
        $orders = Order::where('vendor_id', $vendor->id);
        return view('seller.dashboard', compact('vendor'), [
            'productCount' => $vendor->products()->count(),
            'activeCount' => $vendor->products()->where('status', 'Active')->count(),
            'orderCount' => (clone $orders)->count(),
            'sales' => (clone $orders)->sum('unit_total_price'),
            'recentOrders' => $orders->with(['product', 'orderdetail.user'])->latest()->take(6)->get(),
        ]);
    }

    public function products()
    {
        $vendor = $this->vendor();
        return view('seller.products', compact('vendor'), [
            'products' => $vendor->products()->with(['category', 'images', 'media', 'availabilityCountries'])->latest()->paginate(15),
        ]);
    }

    public function createProduct()
    {
        $vendor = $this->sellerProfileVendor();
        return view('seller.product-form', [
            'vendor' => $vendor,
            'categories' => Category::active()->orderBy('category_name')->get(),
            'countries' => MarketplaceCountry::names(),
            'product' => null,
        ]);
    }

    /*
     * Route contract for main route wiring: seller.product-store, seller.settings.update.
     * Vendor and user identity are always derived from the authenticated seller.
     */
    public function storeProduct(Request $request)
    {
        $vendor = $this->sellerProfileVendor();
        $data = $request->validate($this->productRules());
        $profile = $this->sellerProfileData($vendor);
        $data = array_merge($data, $profile);
        $this->validateProductImages($request);
        $this->validatePriceTiers($request);
        DB::transaction(function () use ($data, $request, $vendor, $profile) {
            $product = Product::create(array_merge($this->productAttributes($data), [
                'vendor_id' => $vendor->id,
                'status' => 'Inactive',
                'product_discount' => 0,
                'is_featured' => 0,
                'top_picks' => 0,
                'total_sold' => 0,
                'total_favourite' => 0,
            ]));
            app(\App\Services\ProductService::class)->syncAvailability($product, $request, $profile['sales_country_codes']);
            app(\App\Services\ProductService::class)->syncPriceTiers($product, $request);
            app(\App\Services\ProductService::class)->storeProductMedia($product, $request);
        });
        return redirect()->route('seller.products')->with('messege', 'Listing submitted for review.');
    }

    public function editProduct(Product $product)
    {
        $vendor = $this->sellerProfileVendor();
        abort_unless((int) $product->vendor_id === (int) $vendor->id, 403);
        $product->load(['availabilityCountries', 'media', 'priceTiers']);
        return view('seller.product-form', [
            'vendor' => $vendor,
            'categories' => Category::active()->orderBy('category_name')->get(),
            'countries' => MarketplaceCountry::names(),
            'product' => $product,
        ]);
    }

    public function updateProduct(Request $request, Product $product)
    {
        $vendor = $this->sellerProfileVendor();
        abort_unless((int) $product->vendor_id === (int) $vendor->id, 403);
        $data = $request->validate($this->productRules($product));
        $profile = $this->sellerProfileData($vendor);
        $data = array_merge($data, $profile);
        $this->validateProductImages($request, $product);
        $this->validatePriceTiers($request);
        DB::transaction(function () use ($data, $request, $product, $profile) {
            $product->update($this->productAttributes($data, $product));
            app(\App\Services\ProductService::class)->syncAvailability($product, $request, $profile['sales_country_codes']);
            app(\App\Services\ProductService::class)->syncPriceTiers($product, $request);
            $this->removeProductMedia($product, $request->input('remove_media', []));
            $this->reorderProductMedia($product, $request->input('media_order', []));
            app(\App\Services\ProductService::class)->storeProductMedia($product, $request);
        });
        return redirect()->route('seller.products')->with('messege', 'Listing updated.');
    }

    private function productRules(?Product $product = null): array
    {
        return [
            'product_name' => ['required', 'string', 'max:255', Rule::unique('products', 'product_name')->ignore($product?->id)],
            'category_id' => [
                'required',
                'integer',
                \Illuminate\Validation\Rule::exists('categories', 'id')->where(
                    fn ($query) => $query->where('status', 'Active')->whereIn('slug', Category::principalSlugs())
                ),
            ],
            'unit_id' => ['required', 'integer', 'exists:units,id'],
            'product_price' => ['required', 'numeric', 'min:0'],
            'product_stock' => ['required', 'integer', 'min:0'],
            'sku' => ['nullable', 'string', 'max:100', Rule::unique('products', 'sku')->ignore($product?->id)],
            'minimum_order_quantity' => ['nullable', 'integer', 'min:1'],
            'wholesale_unit_type' => ['nullable', 'string', 'max:32', Rule::in(['box', 'case', 'carton', 'pallet', 'bundle', 'lot'])],
            'product_stock_limit' => ['nullable', 'integer', 'min:0'],
            'product_short_description' => ['nullable', 'string', 'max:5000'],
            'delivery_duration' => ['required', 'integer', 'min:1'],
            'delivery_duration_unit' => ['required', 'in:Days,Weeks,Months,Year'],
            'delivery_charge' => ['required', 'numeric', 'min:0'],
            'is_delivery_free' => ['nullable', 'boolean'],
            'ships_internationally' => ['nullable', 'boolean'],
            'offers_local_delivery' => ['nullable', 'boolean'],
            'offers_warehouse_pickup' => ['nullable', 'boolean'],
            'offers_seller_delivery' => ['nullable', 'boolean'],
            'offers_marketplace_logistics' => ['nullable', 'boolean'],
            'return_available' => ['nullable', 'boolean'],
            'warrenty_available' => ['nullable', 'boolean'],
            'price_tiers' => ['sometimes', 'array'],
            'price_tiers.*.min_quantity' => ['nullable', 'integer', 'min:1'],
            'price_tiers.*.max_quantity' => ['nullable', 'integer', 'min:1'],
            'price_tiers.*.unit_price' => ['nullable', 'numeric', 'min:0'],
            'images' => $product
                ? ['nullable', 'array', 'max:5']
                : ['required', 'array', 'min:2', 'max:5'],
            'images.*' => ['file', 'image', 'mimes:jpeg,jpg,png,webp', 'max:8192'],
            'videos' => ['nullable', 'array'],
            'videos.*' => ['file', 'mimetypes:video/mp4,video/webm,video/quicktime', 'max:51200'],
            'remove_media' => ['nullable', 'array'],
            'remove_media.*' => ['integer'],
            'media_order' => ['nullable', 'array'],
            'media_order.*' => ['integer', 'min:0'],
        ];
    }

    private function sellerProfileVendor()
    {
        return $this->vendor()->loadMissing(['user', 'availabilityCountries']);
    }

    private function sellerProfileData($vendor): array
    {
        return app(\App\Services\VendorService::class)->productProfile($vendor);
    }

    private function validateProductImages(Request $request, ?Product $product = null): void
    {
        $newPhotoCount = collect($request->file('images', []))
            ->filter(fn ($file) => $file instanceof UploadedFile && $file->isValid())
            ->count();

        $existingPhotoCount = 0;
        if ($product) {
            $removedIds = collect($request->input('remove_media', []))
                ->filter(fn ($id) => is_numeric($id))
                ->map(fn ($id) => (int) $id)
                ->values()
                ->all();

            $existingPhotos = $product->media()->where('media_type', 'image');
            if ($removedIds !== []) {
                $existingPhotos->whereNotIn('id', $removedIds);
            }
            $existingPhotoCount = $existingPhotos->count();
        }

        $totalPhotoCount = $existingPhotoCount + $newPhotoCount;
        if ($totalPhotoCount < 2) {
            throw ValidationException::withMessages([
                'images' => __('seller.photo_minimum_error'),
            ]);
        }

        if ($totalPhotoCount > 5) {
            throw ValidationException::withMessages([
                'images' => __('seller.photo_limit_error'),
            ]);
        }
    }

    private function productAttributes(array $data, ?Product $product = null): array
    {
        return [
            'category_id' => $data['category_id'],
            'subcategory_id' => $data['subcategory_id'] ?? null,
            'unit_id' => $data['unit_id'],
            'product_name' => trim($data['product_name']),
            'product_price' => $data['product_price'],
            'product_stock' => $data['product_stock'],
            'product_stock_limit' => $data['product_stock_limit'] ?? 0,
            'product_short_description' => $data['product_short_description'] ?? null,
            'delivery_duration_unit' => $data['delivery_duration_unit'] ?? 'Days',
            'delivery_duration' => $data['delivery_duration'],
            'delivery_charge' => $data['delivery_charge'] ?? 0,
            'is_delivery_free' => (bool) ($data['is_delivery_free'] ?? false),
            'return_available' => (bool) ($data['return_available'] ?? false),
            'warrenty_available' => (bool) ($data['warrenty_available'] ?? false),
            'country' => $data['country'],
            'city' => trim($data['city']),
            'region' => isset($data['region']) ? trim($data['region']) : null,
            'postal_code' => isset($data['postal_code']) ? trim($data['postal_code']) : null,
            'sku' => isset($data['sku']) && trim($data['sku']) !== '' ? trim($data['sku']) : null,
            'minimum_order_quantity' => (int) ($data['minimum_order_quantity'] ?? $product?->minimum_order_quantity ?? 1),
            'wholesale_unit_type' => $data['wholesale_unit_type'] ?? $product?->wholesale_unit_type ?? 'box',
            'warehouse_name' => $this->nullableTrim($data['warehouse_name'] ?? null),
            'warehouse_address' => $this->nullableTrim($data['warehouse_address'] ?? null),
            'warehouse_city' => $this->nullableTrim($data['warehouse_city'] ?? null),
            'warehouse_region' => $this->nullableTrim($data['warehouse_region'] ?? null),
            'warehouse_postal_code' => $this->nullableTrim($data['warehouse_postal_code'] ?? null),
            'warehouse_country' => isset($data['warehouse_country'])
                ? MarketplaceCountry::normalize($data['warehouse_country'])
                : null,
            'ships_internationally' => (bool) ($data['ships_internationally'] ?? $product?->ships_internationally ?? false),
            'offers_local_delivery' => (bool) ($data['offers_local_delivery'] ?? $product?->offers_local_delivery ?? false),
            'offers_warehouse_pickup' => (bool) ($data['offers_warehouse_pickup'] ?? $product?->offers_warehouse_pickup ?? false),
            'offers_seller_delivery' => (bool) ($data['offers_seller_delivery'] ?? $product?->offers_seller_delivery ?? false),
            'offers_marketplace_logistics' => (bool) ($data['offers_marketplace_logistics'] ?? $product?->offers_marketplace_logistics ?? false),
        ];
    }

    private function nullableTrim(?string $value): ?string
    {
        $value = $value === null ? null : trim($value);
        return $value === '' ? null : $value;
    }

    private function validatePriceTiers(Request $request): void
    {
        $tiers = collect($request->input('price_tiers', []))
            ->filter(fn ($tier) => is_array($tier) && (($tier['min_quantity'] ?? '') !== '' || ($tier['unit_price'] ?? '') !== ''))
            ->map(fn ($tier) => [
                'min_quantity' => (int) ($tier['min_quantity'] ?? 0),
                'max_quantity' => ($tier['max_quantity'] ?? '') === '' ? null : (int) $tier['max_quantity'],
                'unit_price' => (float) ($tier['unit_price'] ?? -1),
            ])
            ->values()
            ->all();

        usort($tiers, fn (array $left, array $right) => $left['min_quantity'] <=> $right['min_quantity']);
        $errors = [];
        $previous = null;
        foreach ($tiers as $index => $tier) {
            if ($tier['min_quantity'] < 1 || $tier['unit_price'] < 0) {
                $errors["price_tiers.$index"] = __('validation.custom.price_tier_values');
            }
            if ($tier['max_quantity'] !== null && $tier['max_quantity'] < $tier['min_quantity']) {
                $errors["price_tiers.$index.max_quantity"] = __('validation.custom.price_tier_range');
            }
            if ($previous !== null && ($previous['max_quantity'] === null || $tier['min_quantity'] <= $previous['max_quantity'])) {
                $errors["price_tiers.$index.min_quantity"] = __('validation.custom.price_tier_overlap');
            }
            $previous = $tier;
        }

        if ($errors) {
            throw ValidationException::withMessages($errors);
        }
    }

    private function removeProductMedia(Product $product, array $ids): void
    {
        if (!$ids) {
            return;
        }
        $media = $product->media()->whereIn('id', $ids)->get();
        foreach ($media as $item) {
            if (file_exists(public_path($item->path))) {
                unlink(public_path($item->path));
            }
            $item->delete();
        }
    }

    private function reorderProductMedia(Product $product, array $orders): void
    {
        foreach ($orders as $id => $order) {
            $product->media()->whereKey($id)->update(['display_order' => (int) $order]);
        }
    }

    public function orders()
    {
        $vendor = $this->vendor();
        return view('seller.orders', compact('vendor'), ['orders' => Order::with(['product', 'orderdetail.user'])->where('vendor_id', $vendor->id)->latest()->paginate(15)]);
    }

    public function customers()
    {
        $vendor = $this->vendor();
        return view('seller.customers', compact('vendor'), ['customers' => Order::with('orderdetail.user')->where('vendor_id', $vendor->id)->latest()->get()->pluck('orderdetail.user')->filter()->unique('id')]);
    }

    public function earnings()
    {
        $vendor = $this->vendor();
        return view('seller.earnings', compact('vendor'), ['sales' => Order::where('vendor_id', $vendor->id)->sum('unit_total_price')]);
    }

    public function plans()
    {
        return view('seller.plans', [
            'trialDays' => config('seller_plans.trial_days', 30),
            'plans' => config('seller_plans.plans', []),
        ]);
    }

    public function settings() { return view('seller.settings', ['vendor' => $this->vendor()->load('user')]); }

    public function updateSettings(Request $request)
    {
        $vendor = $this->vendor();
        $data = $request->validate([
            'company_name' => ['nullable', 'string', 'max:255'],
            'phone' => ['nullable', 'string', 'max:50'],
            'address' => ['nullable', 'string', 'max:1000'],
            'business_type' => ['nullable', 'string', 'max:255'],
            'region' => ['nullable', 'string', 'max:255'],
            'city' => ['nullable', 'string', 'max:255'],
            'area' => ['nullable', 'string', 'max:255'],
        ]);
        $vendor->user->update(array_intersect_key($data, array_flip(['company_name', 'phone', 'address'])));
        $vendor->update(array_intersect_key($data, array_flip(['business_type', 'region', 'city', 'area', 'address'])));
        return back()->with('messege', 'Store settings updated.');
    }
}