<?php
namespace App\Http\Controllers;

use App\Models\Vendor;
use App\Services\VendorService;
use Illuminate\Http\Request;
use DataTables;
use Illuminate\Support\Facades\Validator;

class VendorController extends Controller
{
    protected $vendorService;

    public function __construct(VendorService $vendorService)
    {
        $this->vendorService = $vendorService;
    }

    public function index(Request $request)
    {
        try {
            if ($request->ajax()) {
                $vendors = Vendor::with('user')->select('vendors.*');
                return DataTables::of($vendors)
                    ->addIndexColumn()
                    ->addColumn('status', function ($row) {
                        $statusBadge = ($row->user->status == 'Active') ? "<span class='badge badge-success status'>Active</span>" : "<span class='badge badge-danger status'>Inactive</span>";
                        return $statusBadge;
                    })
                    ->addColumn('action', function ($row) {
                        $btn = "";
                        $btn .= $row->user->status == 'Active' ?
                            ' <a href="#" class="btn btn-danger btn-sm decline-vendor action-button" data-id="' . $row->id . '"><i class="fa fa-ban"></i></a>' :
                            ' <a href="#" class="btn btn-primary btn-sm active-vendor action-button" data-id="' . $row->id . '"><i class="fa fa-check" aria-hidden="true"></i></a>';
                        $btn .= '&nbsp;';
                        $btn .= '<a href="' . route('vendors.show', $row->id) . '" class="btn btn-info btn-sm"><i class="fa fa-eye"></i></a>';
                        $btn .= ' <a href="' . route('vendors.edit', $row->id) . '" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i></a>';
                        $btn .= ' <a href="javascript:void(0)" class="btn btn-danger btn-sm deleteVendor" data-id="' . $row->id . '"><i class="fa fa-trash"></i></a>';
                        return $btn;
                    })
                    ->rawColumns(['action', 'status'])
                    ->make(true);
            }
            return view('vendors.index');
        } catch (Exception $e) {
            return response()->json(['message' => $e->getMessage(), 'exception_code' => $e->getCode(), 'exception_string' => $e->__toString()]);
        }
    }

    public function show($id)
    {
        try {
            $vendor = $this->vendorService->vendorDetails($id);
            return view('vendors.show', compact('vendor'));
        } catch (Exception $e) {
            return response()->json(['message' => $e->getMessage(), 'exception_code' => $e->getCode(), 'exception_string' => $e->__toString()]);
        }
    }

    public function create()
    {
        return view('vendors.create');
    }

    public function store(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'name' => 'required|string|max:50',
                'email' => 'required|email|unique:users',
                'phone' => 'nullable|string|unique:users',
                'company_name' => 'required|string|unique:users',
                'password' => 'required|string|min:6',
                'confirm_password' => 'required|string|same:password',
            ]);
            if ($validator->fails()) {
                return redirect()->back()
                    ->withErrors($validator)
                    ->withInput()
                    ->with('notification', [
                        'messege' => 'Validation Error',
                        'alert-type' => 'error'
                    ]);
            }
            $this->vendorService->store($request);
            $notification = array(
                'messege' => "Successfully the vendor has been added",
                'alert-type' => 'success'
            );
            return redirect()->back()->with($notification);
        } catch (Exception $e) {
            $notification = array(
                'messege' => "Something Went Wrong",
                'alert-type' => 'success'
            );
            return redirect()->back()->with($notification)->withInput();
        }
    }

    public function edit($id)
    {
        $vendor = $this->vendorService->vendorDetails($id);
        return view('vendors.edit', compact('vendor'));
    }

    public function update(Request $request, $id)
    {
        try {
            $vendor = Vendor::find($id);
            $user = $vendor->user;
            $validator = Validator::make($request->all(), [
                'name' => 'nullable|string|max:50',
                'email' => 'nullable|email|unique:users,email,' . $user->id,
                'phone' => 'nullable|string|unique:users,phone,' . $user->id,
                'company_name' => 'nullable|string|unique:users,company_name,' . $user->id
            ]);

            if ($validator->fails()) {
                return redirect()->back()
                    ->withErrors($validator)
                    ->withInput()
                    ->with('notification', [
                        'messege' => 'Validation Error',
                        'alert-type' => 'error'
                    ]);
            }
            $this->vendorService->updateVendor($request, $id);
            $notification = array(
                'messege' => "Successfully the vendor has been updated",
                'alert-type' => 'success'
            );
            return redirect('/vendors')->with($notification);
        } catch (Exception $e) {
            $notification = array(
                'messege' => "Something Went Wrong",
                'alert-type' => 'success'
            );
            return redirect()->back()->with($notification)->withInput();
        }
    }

    public function destroy($id)
    {
        try {
            $vendor = Vendor::findOrFail($id);
            $vendor->delete();
            return response()->json(['status' => true, 'message' => 'Vendor deleted successfully.']);
        } catch (Exception $e) {
            throw $e;
            exit;
        }
    }
}
