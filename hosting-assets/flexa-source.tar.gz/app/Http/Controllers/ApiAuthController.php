<?php

namespace App\Http\Controllers;

use Exception;
use Illuminate\Http\Request;
use Validator;
use App\Models\User;
use App\Models\Vendor;
use Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use App\Support\MarketplaceCountry;

class ApiAuthController extends Controller
{
    
      public function updateUser(Request $request, User $user)
    {
             if (!$request->user() || $request->user()->id !== $user->id) {
                 return response()->json(['status' => false, 'message' => 'Unauthorized'], 403);
             }
             DB::beginTransaction();
        try {
            $validator = Validator::make($request->all(), [
                'name' => 'nullable|string|max:50',
                'email' => 'nullable|email|unique:users,email,' . $user->id,
                'phone' => 'nullable|string|unique:users,phone,' . $user->id,
                'city' => 'nullable|string|max:255',
            ]);

            if ($validator->fails()) {
                return ['status' => false, 'message' => 'The given data was invalid', 'data' => $validator->errors()];
            }
            if ($request->file('image')) {
                if (file_exists(public_path($user->image))) {
                    unlink(public_path($user->image));
                }
                $file = $request->file('image');
                $name = time() . countCategories() . $file->getClientOriginalName();
                $file->move(public_path() . '/uploads/users/', $name);

                $path = 'uploads/users/' . $name;

            } else {
                $path = $user->image ?? null;
            }

            $request->request->remove('role');
            $request->request->remove('role_id');
            $request->request->remove('account_status');
            $request->request->remove('status');
            $user->name = $request->name ?? $user->name;
            $user->company_name = $request->company_name ?? $user->company_name;
            $user->email = $request->email ?? $user->email;
            $user->phone = $request->phone ?? $user->phone;
            if ($request->has('city')) {
                $user->city = $request->city;
            }
            $user->address = $request->address ?? $user->address;

            $user->image = $path;
            $user->save();

            DB::commit();

            return response()->json([
                'status' => true,
                'message' => 'User Details Updated Successfully'
            ], 200);
        } catch (Exception $e) {
                        DB::rollback();

            return response()->json([
                'status' => true,
                'message' => 'something went wrong!'
            ], 500);
        }
    }
    public function login(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'email_or_company' => 'required',
                'password' => 'required|string|min:6',
                'use_for' => 'required|in:user,vendor',
            ]);

            if ($validator->fails()) {
                return ['status' => false, 'message' => 'The given data was invalid', 'data' => $validator->errors()];
            }

            $user = User::where('email', $request->email_or_company)->orWhere('company_name', $request->email_or_company)->first();
if(!$user){
     return ['status' => false, 'message' => 'Invalid Information', 'data' => ['token' => "", 'id' => 0, 'vendor_id' => 0, 'name' => "", "email" => "", 'phone' => "", 'company_name' => "", 'image' => ""]];
}
            if ($user && !$user->isActive()) {
                return response()->json(['status' => false, 'message' => 'You are not the active vendor!']);
            }
                    $vendor = Vendor::where('user_id', $user->id)->first();
            if ($request->use_for === 'vendor' && (!$vendor || !$user->hasRole('seller'))) {
                  return response()->json(['status' => false, 'message' => 'You are not a registered vendor!']);
            }

            if (filter_var($request->email_or_company, FILTER_VALIDATE_EMAIL)) {
                $credentials = ['email' => $request->email_or_company, 'password' => $request->password];
            } else {
                $credentials = ['company_name' => $request->email_or_company, 'password' => $request->password];
            }

            if (Auth::attempt($credentials)) {
                $user = Auth::user();
                if ($user->image == NULL) {
                    $image = "";
                } else {
                    $image = $user->image;
                }

                if ($request->use_for == 'vendor') {
                    $vendor = Vendor::where('user_id', $user->id)->first();

                    $vendor_id = $vendor->id;

                } else {
                    $vendor_id = 0;
                }

                $data['token'] = $user->createToken('MyApp')->plainTextToken;
                $data['id'] = $user->id;
                $data['vendor_id'] = $vendor_id;
                $data['name'] = $user->name;
                $data['email'] = $user->email;
                $data['phone'] = $user->phone;
                $data['company_name'] = $user->company_name;
                $data['image'] = $image;
                $data['role'] = $user->role;
                $data['account_status'] = $user->account_status;
                $data['is_verified'] = $user->is_verified;
                $user->forceFill(['last_login' => now()])->save();
                return ['status' => true, 'message' => 'Vendor login successfully', 'data' => $data];
            } else {
                return ['status' => false, 'message' => 'Invalid Information', 'data' => ['token' => "", 'id' => 0, 'vendor_id' => 0, 'name' => "", "email" => "", 'phone' => "", 'company_name' => "", 'image' => ""]];
            }


        } catch (Exception $e) {

            return response()->json(['status' => false, 'message' => 'Unable to sign in'], 500);
        }
    }
    public function userLogin(Request $request)
    {
        try {

            $validator = Validator::make($request->all(), [
                'email' => 'required|email',
                'password' => 'required|string|min:6',
                'use_for' => 'required|in:user,vendor',
            ]);

            if ($validator->fails()) {
                return ['status' => false, 'message' => 'The given data was invalid', 'data' => $validator->errors()];
            }
            $user = User::where('email', $request->email)->first();

            // Admin and Owner accounts are never eligible for customer-facing
            // mobile login, even when they retain buyer/seller capabilities.
            if (!$user || !$user->isActive() || $request->use_for != 'user' ||
                in_array($user->role, ['admin', 'owner'], true) || !$user->hasRole('buyer', 'seller')) {
                return response()->json(['status' => false, 'message' => 'You are not an active user!'], 401);
            }

            if (!Auth::attempt(['email' => $request->email, 'password' => $request->password])) {
                return response()->json(['status' => false, 'message' => 'User login unsuccessful'], 401);
            }

            $user = Auth::user();

            $data = [
                'token' => $user->createToken('MyApp')->plainTextToken,
                'id' => $user->id,
                'name' => $user->name,
                'email' => $user->email,
                'phone' => $user->phone,
                'image' => $user->image,
                'role' => $user->role,
                'account_status' => $user->account_status,
                'is_verified' => $user->is_verified,
            ];
            $user->forceFill(['last_login' => now()])->save();

            return response()->json(['status' => true, 'message' => 'User login successful', 'data' => $data], 200);

        } catch (Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'something went wrong!'
            ], 500);
        }
    }

 public function userRegister(Request $request)
    {
        DB::beginTransaction();
        try {
            $validator = Validator::make($request->all(), [
                'name' => 'required|string|max:50',
                'email' => 'required|email|unique:users',
                'phone' => 'nullable|string|unique:users',
                'password' => 'required|string|min:6',
                'confirm_password' => 'required|string|same:password',
                'country' => ['required', 'string', 'size:2', Rule::in(array_keys(MarketplaceCountry::supported()))],
                'city' => 'nullable|string|max:255',
            ]);

            if ($validator->fails()) {
                return ['status' => false, 'message' => 'The given data was invalid', 'data' => $validator->errors()];
            }

            if ($request->file('image')) {

                $file = $request->file('image');
                $name = time() . countCategories() . $file->getClientOriginalName();
                $file->move(public_path() . '/uploads/', $name);

                $path = 'public/uploads/' . $name;

            } else {
                $path = NULL;
            }

            $user = new User();
            $user->name = $request->name;
            $user->role_id = 3;
            $user->role = 'buyer';
            $user->email = $request->email;
            $user->phone = $request->phone;
            $user->password = bcrypt($request->password);
            $user->image = $path;
            $user->address = $request->address;
            $user->country = MarketplaceCountry::normalize($request->country);
            $user->city = $request->city;
            $user->save();

            DB::commit();

            return response()->json([
                'status' => true,
                'message' => 'Successfully registered'
            ]);

        } catch (Exception $e) {
            DB::rollback();
            return response()->json([
                'status' => false,
                'message' => 'Something Went Wrong!'
            ]);
        }
    }
    public function register(Request $request)
    {
        $role = $request->input('role');
        if (!in_array($role, ['buyer', 'seller', 'buyer_seller'], true)) {
            return response()->json(['status' => false, 'message' => 'Only buyer, seller, or buyer_seller registration is allowed'], 422);
        }
        if ($role === 'buyer') {
            return $this->userRegister($request);
        }
        $request->merge(['confirm_password' => $request->input('confirm_password', $request->password)]);
        return app(ApiController::class)->storeVendor($request);
    }
  public function userLogout(Request $request)
    {
        try {
            auth()->user()->tokens()->delete();
            return response()->json([
                'status' => true,
                'message' => 'User logout successful',
            ], 200);
        } catch (Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'something went wrong!'
            ], 500);
        }
    }
    
    public function userProfile($userId)
    {
        try {
            if (!auth('sanctum')->check() || (int) auth('sanctum')->id() !== (int) $userId) {
                return response()->json(['status' => false, 'message' => 'Unauthorized'], 403);
            }
            return response()->json([
                'status' => true,
                'userProfile' => User::find($userId),
            ], 200);
        } catch (Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'something went wrong!'
            ], 500);
        }
    }
    
    public function logout(Request $request)
    {
        try {
            auth()->user()->tokens()->delete();
            $data = array('status' => true, 'message' => 'successfully logged out!');
            return $data;
        } catch (Exception $e) {

            $message = $e->getMessage();
            $code = $e->getCode();
            $string = $e->__toString();
            return response()->json(['message' => $message, 'execption_code' => $code, 'execption_string' => $string]);
        }
    }
   public function changePass(Request $request)
{
    try {
        $validator = Validator::make($request->all(), [
            'old_password' => 'required|string|min:6',
            'password' => 'required|string|min:6|confirmed',
            'password_confirmation' => 'required|string|min:6',
            'vendor_id' => 'nullable|integer',
            'user_id' => 'nullable|integer',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'message' => 'The given data was invalid',
                'data' => $validator->errors()
            ]);
        }

        if ($request->has('vendor_id')) {
            $vendor = Vendor::with('user')->find($request->vendor_id);
            $user = $vendor->user ?? null;
        } else {
            $user = User::findOrFail($request->user_id);
        }
        if (!$request->user() || !$user || $request->user()->id !== $user->id) {
            return response()->json(['status' => false, 'message' => 'Unauthorized'], 403);
        }

        if (!$user) {
            return response()->json([
                'status' => false,
                'message' => 'User not found'
            ]);
        }

        // Check if the old password is correct
        if (!Hash::check($request->old_password, $user->password)) {
            return response()->json([
                'status' => false,
                'message' => 'The old password is incorrect'
            ]);
        }

        // Update the user's password
        $user->password = Hash::make($request->password);
        $user->save();

        return response()->json([
            'status' => true,
            'message' => 'Password has been successfully changed'
        ]);
    } catch (Exception $e) {
        return response()->json([
            'status' => false,
            'message' => 'Unable to change password'
        ]);
    }
}

    
    public function resetPassword(Request $request)
    {
        // Password reset tokens have not been configured for this application.
        // Never accept an email address alone as proof of account ownership.
        return response()->json([
            'status' => false,
            'message' => 'Password recovery is currently unavailable. Please contact support.'
        ], 503);
    }
}
