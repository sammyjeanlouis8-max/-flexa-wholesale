<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreSliderRequest;
use App\Http\Requests\UpdateSliderRequest;
use App\Models\Slider;
use App\Services\SliderService;
use Exception;
use Illuminate\Http\Request;
use DataTables;

class SliderController extends Controller
{
    protected $slider;

    public function __construct(SliderService $slider)
    {
        $this->slider = $slider;
        // $this->middleware('auth_check');
    }

    public function index(Request $request)
    {
       try {
            if ($request->ajax()) {
                $sliders = $this->slider->sliders($request);
                return Datatables::of($sliders)
                    ->addIndexColumn()
                    ->addColumn('src', function ($row) {
                        return '<img class="img-fluid"style="width:150px;height:70px" src="' . url('/') . "/" . $row->src . '">';
                    })
                    ->addColumn('status', function ($row) {
                        $statusBadge = ($row->status == 'Active') ? "<span class='badge badge-success status'>Active</span>" : "<span class='badge badge-danger status'>Inactive</span>";
                        return $statusBadge;
                    })
                    ->addColumn('action', function ($row) {
                        $btn = "";
                        $btn .= '&nbsp;';
                        $btn .= $row->status == 'Active' ?
                            ' <a href="#" class="btn btn-danger btn-sm decline-slider action-button" data-id="' . $row->id . '"><i class="fa fa-ban"></i></a>' :
                            ' <a href="#" class="btn btn-primary btn-sm active-slider action-button" data-id="' . $row->id . '"><i class="fa fa-check" aria-hidden="true"></i></a>';
                        $btn .= '&nbsp;';
                        $btn .= ' <a href="' . route('sliders.show', $row->id) . '" class="btn btn-primary btn-sm action-button"><i class="fa fa-edit"></i></a>';
                        $btn .= '&nbsp;';
                        $btn .= ' <a href="#" class="btn btn-danger btn-sm delete-slider action-button" data-id="' . $row->id . '"><i class="fa fa-trash"></i></a>';
                        return $btn;
                    })
                    ->rawColumns(['action', 'src','status'])
                    ->make(true);
            }
            return view('sliders.index');
        } catch (Exception $e) {
            $message = $e->getMessage();
            $code = $e->getCode();
            $string = $e->__toString();
            return response()->json([
                'message' => $message,
                'execption_code' => $code,
                'execption_string' => $string
            ]);
            exit;
        }
    }


    public function create()
    {
        return view('sliders.create');
    }


    public function store(StoreSliderRequest $request)
    {
        try {
            $this->slider->storeSlider($request);
            $notification = array(
                'messege' => "Successfully slider has been added",
                'alert-type' => 'success'
            );
            return redirect()->back()->with($notification);
        } catch (Exception $e) {
            $notification = array(
                'messege' => "Something Went Wrong",
                'alert-type' => 'success'
            );
            return redirect()->back()->with($notification)->withInput();
        }
    }

    public function show(Slider $slider)
    {
        return view('sliders.edit', compact('slider'));
    }




    public function update(UpdateSliderRequest $request, Slider $slider)
    {
        try {
            $this->slider->updateSlider($request, $slider);
            $notification = array(
                'messege' => "Successfully the slider has been updated",
                'alert-type' => 'success'
            );
            return redirect('/sliders')->with($notification);
        } catch (Exception $e) {
            $notification = array(
                'messege' => "Something Went Wrong",
                'alert-type' => 'success'
            );
            return redirect()->back()->with($notification)->withInput();
        }
    }

    public function destroy(Slider $slider)
    {
        try {
            $this->slider->deleteSlider($slider);
            return response()->json([
                'status' => true,
                'message' => 'Successfully the slider has been deleted'
            ]);
        } catch (Exception $e) {
            throw $e;
            exit;
        }
    }
}
