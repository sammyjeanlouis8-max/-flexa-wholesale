<?php

namespace App\Http\Controllers;

use App\Models\OrderTransaction;
use App\Models\PaymentMethod;
use App\Models\ProductReview;
use App\Models\Rating;
use App\Models\Slider;
use App\Models\User;
use App\Models\Vendor;
use App\Models\WithdrawRequestLog;
use App\Services\ProductService;
use Exception;
use Illuminate\Http\Request;
use App\Services\VendorService;
use App\Models\Category;
use App\Models\Product;
use App\Models\Variant;
use App\Models\Unit;
use App\Models\Setting;
use App\Models\Subcategory;
use App\Support\MarketplaceCountry;
use Illuminate\Support\Facades\Validator;
use App\Models\Order;
use App\Models\Orderdetail;
use App\Models\StatusLog;
use App\Services\CardDetailService;
use App\Services\WithdrawRequestLogService;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class ApiController extends Controller
{



    public function __construct(
        protected VendorService $vendorService,
        protected ProductService $productService,
        protected CardDetailService $cardDetailService,
        protected WithdrawRequestLogService $withdrawRequestLogService
    ) {
    }


    public function variants($categoryId)
    {
        $variants = Variant::select([
            'id',
            'variant_name',
            'variant_value'
        ])->where('category_id', $categoryId)
            ->latest()
            ->get();
        $variants->transform(function ($variant) {
            $variant->variant_value = explode(',', $variant->variant_value);
            return $variant;
        });


        return response()->json(['status' => true, 'variant_list' => $variants]);
    }
    public function allUnits($vendorId = null, $categoryId = null)
    {
        $units = Unit::where([

            'status' => 'Active'
        ])
            ->select([
                'id',
                'unit_name'
            ])
            ->latest()
            ->get();

        return response()->json(['status' => true, 'unit_list' => $units]);
    }
    public function variantValues($variantId)
    {
        $variant = Variant::where('id', $variantId)
            ->select('variant_value')
            ->latest()
            ->first();

        if (!$variant) {
            return response()->json(['status' => false, 'message' => 'Variant not found'], 404);
        }

        $variantValues = explode(',', $variant->variant_value);

        return response()->json(['status' => true, 'data' => $variantValues]);
    }
    public function categories()
    {
        $categories = Category::active()
            ->with([
                'subcategories' => function ($query) {
                    $query->where('status', 'Active');
                }
            ])
            ->latest()
            ->get();

        return response()->json(['status' => count($categories), 'data' => $categories]);
    }
    public function allCategories()
    {
        $categories = Category::active()
            ->select(['id', 'category_name'])
            ->latest()
            ->get();
        return response()->json(['status' => true, 'data' => $categories]);
    }

    public function categoryWiseSubCategory($categoryId)
    {
        $subCategories = Subcategory::where([
            'status' => 'Active',
            'category_id' => $categoryId
        ])->select(['id', 'subcategory_name'])
            ->latest()
            ->get();
        return response()->json(['status' => true, 'sub_category_list' => $subCategories]);
    }
    public function storeVendor(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:50',
            'email' => 'required|email|unique:users',
            'phone' => 'nullable|string|unique:users',
            'company_name' => 'required|string|unique:users',
            'password' => 'required|string|min:6',
            'confirm_password' => 'required|string|same:password',
             'country' => ['required', 'string', 'size:2', \Illuminate\Validation\Rule::in(array_keys(MarketplaceCountry::supported()))],
             'city' => ['required', 'string', 'max:255'],
             'address' => ['required', 'string', 'max:1000'],
             'region' => ['nullable', 'string', 'max:255'],
             'postal_code' => ['nullable', 'string', 'max:32'],
             'sales_country_codes' => ['required', 'array', 'min:1'],
             'sales_country_codes.*' => ['string', 'size:2', \Illuminate\Validation\Rule::in(array_keys(MarketplaceCountry::supported()))],
        ]);
        if ($validator->fails()) {
            return ['status' => false, 'message' => 'The given data was invalid', 'data' => $validator->errors()];
        }
        $storeVendor = $this->vendorService->store($request);
        return $storeVendor;
    }
    public function updateVendor(Request $request, $vendor)
    {
        $vendor = Vendor::find($vendor);
        if (!$vendor || !$request->user() || $vendor->user_id !== $request->user()->id) {
            return response()->json(['status' => false, 'message' => 'Unauthorized'], 403);
        }
        $user = $vendor->user;
        $validator = Validator::make($request->all(), [
            'name' => 'nullable|string|max:50',
            'email' => 'nullable|email|unique:users,email,' . $user->id,
            'phone' => 'nullable|string|unique:users,phone,' . $user->id,
            'company_name' => 'nullable|string|unique:users,company_name,' . $user->id
        ]);

        if ($validator->fails()) {
            return ['status' => false, 'message' => 'The given data was invalid', 'data' => $validator->errors()];
        }
        $storeVendor = $this->vendorService->updateVendor($request, $vendor);
        return $storeVendor;
    }
    public function vendorDetails(Request $request, $id)
    {
        if ((int) $id !== $this->vendorId()) {
            return response()->json(['status' => false, 'message' => 'Unauthorized'], 403);
        }
        $vendor = $this->vendorService->vendorDetails($id);
        return response()->json(['status' => true, 'vendor' => $vendor]);

    }

    public function categoryDetails(Request $request, $category)
    {
        // First, find the category by the given ID
        $category = Category::where('id', $category)
            ->with([
                'subcategories' => function ($query) {
                    $query->where('status', 'Active')
                        ->select(['id', 'subcategory_name', 'category_id'])
                        ->with([
                            'products' => function ($query) use ($request) {
                                $query->with([
                                    'images' => function ($query) {
                                        $query->orderBy('id')->select('src'); // No need for `first()` here
                                    }
                                ])->where('status', 'Active');
                                MarketplaceCountry::availableQuery($query, $request->input('country'));
                                $query->select(['id', 'subcategory_id', 'category_id', 'product_name']);
                            }
                        ]);
                }
            ])
            ->select(['id', 'category_name'])
            ->first(); // Use first() here to fetch the single record

        // Check if the category exists and process its subcategories and products
        if ($category) {
            foreach ($category->subcategories as $subCategory) {
                $subCategory->products->transform(function ($product) {
                    $product->image = $product->images->isEmpty() ? null : $product->images->first()->src;
                    unset($product->images);
                    return $product;
                });
            }
        }

        // Return the response with the category details
        return response()->json(['status' => true, 'data' => $category]);
    }



    public function subCategoryDetails(Request $request,  $subcategory)
    {
        // Get the search key from the query parameters
        $searchKey = $request->input('searchKey');
$subcategoryDetails=Subcategory::whereId($subcategory);
//dd($subcategoryDetails);
        $subCategoryDetails = $subcategoryDetails
            ->with([
                'products' => function ($query) use ($searchKey, $request) {

                    if ($searchKey) {
                        $query->where('product_name', 'LIKE', '%' . $searchKey . '%');
                    }

                    $query->with('images');
                    $query->where('status', 'Active');
                    MarketplaceCountry::availableQuery($query, $request->input('country'));
                    $query->select(['id', 'subcategory_id', 'category_id', 'product_name', 'product_price', 'product_discount']);
                }
            ])
            ->select(['id', 'subcategory_name'])
            ->latest()
            ->first();

        if ($subCategoryDetails) {
            $subCategoryDetails->products->transform(function ($product) {
                $product->image = $product->images->isEmpty() ? null : $product->images->first()->src;
                $product->avg_ratings = number_format(3.4, 2);
                $product->total_sold = 50375;
                $product->total_reviews = 435;
                unset($product->images);
                return $product;
            });
        }
        return response()->json(['status' => true, 'data' => $subCategoryDetails]);
    }




    public function productDetails(Request $request, $product)
    {
        $product = Product::find($product);
        abort_unless($product && $product->status === 'Active' && $product->isAvailableIn(MarketplaceCountry::current($request)), 404);
        $productDetails = $product->load('variants', 'images', 'media', 'availabilityCountries', 'priceTiers', 'category', 'subCategory', 'unit', 'vendor');
        $marketplaceCountry = MarketplaceCountry::current($request);
        $variants = $productDetails->variants->map(function ($variant) {
            return [
                'id' => $variant->id,
                'variant_name' => $variant->variant_name,
                'variant_values' => $variant->pivot->variant_value
            ];
        });


        $imageUrls = $productDetails->images->pluck('src')->toArray();
        $vendor = $productDetails->vendor;
        $vendorUser = $vendor->user()->first();
        $store = [
            "id" => $vendor->id,
            "image" => $vendorUser->image ?? '',
            "name" => $vendorUser->company_name ?? '',
            "verified" => $vendorUser->verified_at == null ? 1 : 0
        ];

        return response()->json([
            'status' => true,
            'data' => [
                'id' => $productDetails->id,
                'vendor_id' => intval($productDetails->vendor_id),
                'category_id' => intval($productDetails->category_id),
                'subcategory_id' => intval($productDetails->subcategory_id),
                'unit_id' => intval($productDetails->unit_id),
                'category_name' => $productDetails->category->display_name,

                'subcategory_name' => $productDetails->subCategory ? $productDetails->subCategory->subcategory_name : '',
                'unit_name' => $productDetails->unit ? $productDetails->unit->unit_name : '',
                'product_name' => $productDetails->product_name,
                'product_price' => floatval($productDetails->product_price),
                'sku' => $productDetails->sku,
                'minimum_order_quantity' => intval($productDetails->minimum_order_quantity),
                'wholesale_unit_type' => $productDetails->wholesale_unit_type,
                'price_tiers' => $productDetails->priceTiers->map(fn ($tier) => [
                    'min_quantity' => $tier->min_quantity,
                    'max_quantity' => $tier->max_quantity,
                    'unit_price' => floatval($tier->unit_price),
                    'currency_code' => $tier->currency_code,
                ])->values(),
                'product_short_description' => $productDetails->product_short_description,
                'product_discount' => intval($productDetails->product_discount),
                'product_stock' => intval($productDetails->product_stock),
                'product_stock_limit' => intval($productDetails->product_stock_limit),
                'is_featured' => intval($productDetails->is_featured),
                'top_picks' => intval($productDetails->top_picks),
                'delivery_duration' => intval($productDetails->delivery_duration),
                'delivery_duration_unit' => $productDetails->delivery_duration_unit,
                'return_available' => intval($productDetails->return_available),
                'warrenty_available' => intval($productDetails->warrenty_available),
                'total_sold' => intval($product->total_sold),
                'total_favourite' => intval($product->total_favourite),
                'delivery_charge' => floatval($productDetails->delivery_charge),
                'is_delivery_free' => intval($productDetails->is_delivery_free),
                'total_reviews' => intval($product->total_reviews),
                'avg_ratings' => strval($product->avg_ratings),
                'status' => $productDetails->status,
                'variants' => $variants,
                 'images' => $imageUrls,
                 'media' => $productDetails->media,
                   'availability_type' => $productDetails->availability_type ?: 'selected',
                  'country' => $productDetails->country,
                  'city' => $productDetails->city,
                  'region' => $productDetails->region,
                  'stock_location' => [
                      'country' => $productDetails->country,
                      'city' => $productDetails->city,
                      'region' => $productDetails->region,
                  ],
                  'shipping_methods' => [
                      'international' => (bool) $productDetails->ships_internationally,
                      'local_delivery' => (bool) $productDetails->offers_local_delivery,
                      'warehouse_pickup' => (bool) $productDetails->offers_warehouse_pickup,
                      'seller_delivery' => (bool) $productDetails->offers_seller_delivery,
                      'marketplace_logistics' => (bool) $productDetails->offers_marketplace_logistics,
                  ],
                 'available_in_country' => $productDetails->isAvailableIn($marketplaceCountry),
                 'marketplace_country' => $marketplaceCountry,
                'store' => $store
            ]
        ]);
    }
    public function storeProduct(Request $request)
    {
        if (!$request->user() || !$request->user()->hasRole('seller') || (int) optional($request->user()->vendor)->id !== (int) $request->vendor_id) {
            return response()->json(['status' => false, 'message' => 'Unauthorized'], 403);
        }
        $validator = Validator::make($request->all(), [
            'vendor_id' => 'required|exists:vendors,id',
            'category_id' => [
                'required',
                \Illuminate\Validation\Rule::exists('categories', 'id')->where(
                    fn ($query) => $query->where('status', 'Active')->whereIn('slug', Category::principalSlugs())
                ),
            ],
            'subcategory_id' => 'required|exists:subcategories,id',
            'unit_id' => 'required|exists:units,id',
            'product_name' => 'required|string|max:255|unique:products,product_name',
            'product_price' => 'required',
            'product_discount' => 'nullable',
            'product_stock' => 'required',
             'sku' => 'nullable|string|max:100',
             'minimum_order_quantity' => 'nullable|integer|min:1',
             'wholesale_unit_type' => 'nullable|in:box,case,carton,pallet,bundle,lot',
            'is_featured' => 'required',
            'top_picks' => 'required',
              'price_tiers' => ['sometimes', 'array'],
              'price_tiers.*.min_quantity' => ['nullable', 'integer', 'min:1'],
              'price_tiers.*.max_quantity' => ['nullable', 'integer', 'min:1'],
              'price_tiers.*.unit_price' => ['nullable', 'numeric', 'min:0'],
            'videos' => ['nullable', 'array'],
            'videos.*' => ['file', 'mimetypes:video/mp4,video/webm,video/quicktime', 'max:51200'],
            'status' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }
        if ($tierErrors = $this->priceTierErrors($request->input('price_tiers', []))) {
            return response()->json([
                'status' => false,
                'message' => 'Validation failed',
                'errors' => $tierErrors,
            ], 422);
        }
        try {
            $profile = $this->vendorService->productProfile($request->user()->vendor);
            $request->merge($profile);
            $this->productService->storeProduct($request);

            return response()->json(['status' => true, 'message' => 'Product stored successfully'], 200);
        } catch (ValidationException $e) {
            return response()->json([
                'status' => false,
                'message' => 'Seller profile is incomplete',
                'errors' => $e->errors(),
            ], 422);
        } catch (Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'Unable to store product'
            ], 500);
        }
    }

    public function updateProduct(Request $request, $product)
    {
        try {
            $product = Product::find($product);

            if (!$product) {
                return response()->json(['status' => false, 'message' => 'Product not found'], 404);
            }
            if (!$request->user() || (int) optional($request->user()->vendor)->id !== (int) $product->vendor_id || (int) $request->vendor_id !== (int) $product->vendor_id) {
                return response()->json(['status' => false, 'message' => 'Unauthorized'], 403);
            }
            $validator = Validator::make($request->all(), [
                'vendor_id' => 'required|exists:vendors,id',
                'category_id' => [
                    'required',
                    \Illuminate\Validation\Rule::exists('categories', 'id')->where(
                        fn ($query) => $query->where('status', 'Active')->whereIn('slug', Category::principalSlugs())
                    ),
                ],
                'subcategory_id' => 'required|exists:subcategories,id',
                'unit_id' => 'required|exists:units,id',
                'product_name' => 'required|string|max:255|unique:products,product_name,' . $product->id,
                'product_price' => 'required',
                'product_discount' => 'nullable',
                'product_stock' => 'required',
                'is_featured' => 'required',
                'top_picks' => 'required',
                 'sku' => ['nullable', 'string', 'max:100'],
                 'minimum_order_quantity' => ['nullable', 'integer', 'min:1'],
                 'wholesale_unit_type' => ['nullable', 'in:box,case,carton,pallet,bundle,lot'],
                 'price_tiers' => ['sometimes', 'array'],
                 'price_tiers.*.min_quantity' => ['nullable', 'integer', 'min:1'],
                 'price_tiers.*.max_quantity' => ['nullable', 'integer', 'min:1'],
                 'price_tiers.*.unit_price' => ['nullable', 'numeric', 'min:0'],
                'status' => 'required',
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'status' => false,
                    'message' => 'Validation failed',
                    'errors' => $validator->errors()
                ], 422);
            }
            if ($tierErrors = $this->priceTierErrors($request->input('price_tiers', []))) {
                return response()->json([
                    'status' => false,
                    'message' => 'Validation failed',
                    'errors' => $tierErrors,
                ], 422);
            }
            $profile = $this->vendorService->productProfile($request->user()->vendor);
            $request->merge($profile);
            $this->productService->updateProduct($request, $product);

            return response()->json(['status' => true, 'message' => 'Product updated successfully'], 200);
        } catch (ValidationException $e) {
            return response()->json([
                'status' => false,
                'message' => 'Seller profile is incomplete',
                'errors' => $e->errors(),
            ], 422);
        } catch (Exception $e) {
            return response()->json([
                'status' => false,
                'message' => 'Unable to update product'
            ], 500);
        }
    }

    public function deleteProduct(Request $request, $product)
    {
        try {
            $product = Product::find($product);

            if (!$product) {
                return response()->json(['status' => false, 'message' => 'Product not found'], 404);
            }
            if (!$request->user() || (int) optional($request->user()->vendor)->id !== (int) $product->vendor_id) {
                return response()->json(['status' => false, 'message' => 'Unauthorized'], 403);
            }

            $this->productService->deleteProduct($product);

            return response()->json(['status' => true, 'message' => 'Product deleted successfully'], 200);
        } catch (Exception $e) {
            return response()->json([
                'status' => false,
                'message' => $e->getMessage(),
                'exception_code' => $e->getCode()
            ], 405);
        }
    }
    public function allProducts(Request $request)
    {
        $products = $this->productService->products($request);
        $data = array();
        foreach ($products as $product) {
            $data[] = [
                'id' => $product->id,
                'vendor_id' => intval($product->vendor_id),
                'category_id' => intval($product->category_id),
                'subcategory_id' => intval($product->subcategory_id),
                'unit_id' => intval($product->unit_id),
                'product_name' => $product->product_name,
                'product_price' => floatval($product->product_price),
                'product_short_description' => "",
                'product_discount' => intval($product->product_discount),
                'product_stock' => intval($product->product_stock),
                'product_stock_limit' => intval($product->product_stock_limit),
                'is_featured' => intval($product->is_featured),
                'top_picks' => intval($product->top_picks),
                'delivery_duration' => intval($product->delivery_duration),
                'delivery_duration_unit' => $product->delivery_duration_unit,
                'return_available' => intval($product->return_available),
                'warrenty_available' => intval($product->warrenty_available),
                'delivery_charge' => floatval($product->delivery_charge),
                'is_delivery_free' => floatval($product->is_delivery_free),
                'total_sold' => intval($product->total_sold),
                'total_fovourite' => intval($product->total_fovourite),
                'status' => $product->status,
                'created_at' => $product->created_at,
                'updated_at' => $product->updated_at,
                'avg_ratings' => strval($product->avg_ratings),
                "total_reviews" => intval($product->total_reviews),
                 'images' => $product->images,
                 'media' => $product->media,
                  'availability_type' => $product->availability_type ?: 'selected',
                   'sku' => $product->sku,
                   'minimum_order_quantity' => intval($product->minimum_order_quantity),
                   'wholesale_unit_type' => $product->wholesale_unit_type,
                   'price_tiers' => $product->priceTiers->map(fn ($tier) => [
                       'min_quantity' => $tier->min_quantity,
                       'max_quantity' => $tier->max_quantity,
                       'unit_price' => floatval($tier->unit_price),
                       'currency_code' => $tier->currency_code,
                   ])->values(),
                  'country' => $product->country,
                  'city' => $product->city,
                  'region' => $product->region,
                   'stock_location' => [
                       'country' => $product->country,
                       'city' => $product->city,
                       'region' => $product->region,
                   ],
                   'shipping_methods' => [
                       'international' => (bool) $product->ships_internationally,
                       'local_delivery' => (bool) $product->offers_local_delivery,
                       'warehouse_pickup' => (bool) $product->offers_warehouse_pickup,
                       'seller_delivery' => (bool) $product->offers_seller_delivery,
                       'marketplace_logistics' => (bool) $product->offers_marketplace_logistics,
                   ],
            ];
        }
        return response()->json(['status' => true, 'data' => $data], 200);
    }

    public function ratingsByType(Request $request)
    {
        $request->validate([
            'productId' => 'nullable|exists:products,id',
            'vendorId' => 'nullable|exists:vendors,id',
        ]);

        $productId = $request->input('productId');
        $vendorId = $request->input('vendorId');
        $ratings = [];

        if ($productId) {
            $product = Product::find($productId);
            if ($product) {
                $ratings = $product->ratings()->with('user')->get();
            }
        } elseif ($vendorId) {
            $vendor = Vendor::find($vendorId);
            if ($vendor) {
                // Fetch all products of the vendor
                $products = $vendor->products;

                // Fetch all ratings for these products
                $ratings = $products->flatMap(function ($product) {
                    return $product->ratings()->with('user')->get();
                });
            }
        } else {
            return response()->json(['status' => false, 'message' => 'No productId or vendorId provided'], 400);
        }
        $ratings = $ratings->map(function ($rating) {
            return [
                'rating' => $rating->rating,
                'comment' => $rating->review,
                'images' => json_decode($rating->images),
                'user_name' => $rating->user->name,
                'date' => date("F j, Y", strtotime($rating->created_at)), // Format date without Carbon
            ];
        });

        return response()->json(['status' => true, 'data' => $ratings]);
    }
    public function sliders()
    {
        return response()->json(['status' => true, 'data' => Slider::get()]);
    }
    public function getSettingsData()
    {
        try {
            $setting = Setting::select('id', 'currency', 'currency_code', 'currency_symbol', 'tax')->find(1);

            return response()->json(['status' => true, 'data' => $setting]);
        } catch (Exception $e) {
            $message = $e->getMessage();
            $code = $e->getCode();
            $string = $e->__toString();
            return response()->json(['message' => $message, 'execption_code' => $code, 'execption_string' => $string]);
            exit;
        }
    }
    public function storeRatings(Request $request)
    {
        try {
            $request->validate([
                'product_id' => 'required|exists:products,id',
                'rating' => 'required|integer|min:1|max:5',
                'comment' => 'nullable|string',
                'images.*' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:6048',
            ]);

            $rating = new Rating();
            // Never trust a caller-supplied author.
            $rating->user_id = auth()->id();
            $rating->rateable_type = 'App\Models\Product';
            $rating->rateable_id = $request->product_id;
            $rating->rating = $request->rating;
            $rating->comment = $request->comment;
            $rating->save();

            if ($request->hasFile('images')) {
                $images = insertMultipleImages($request);
                $rating->images()->sync($images);
            }
            return response()->json(['status' => true, 'data' => 'Rating Submitted Successfully']);
        } catch (Exception $e) {
            $message = $e->getMessage();
            $code = $e->getCode();
            $string = $e->__toString();
            return response()->json(['message' => $message, 'execption_code' => $code, 'execption_string' => $string]);
            exit;
        }
    }

    public function availableStock(Request $request)
    {
        $productIds = $request->product_ids;
        // Check if productIds is a string and try to decode it
        if (is_string($productIds)) {
            $productIds = json_decode($productIds, true);
        }

        // Ensure productIds is an array
        if (!is_array($productIds)) {
            return response()->json(['status' => false, 'message' => 'Invalid product_ids format'], 400);
        }
        $productsQuery = Product::whereIn('id', $productIds);
        MarketplaceCountry::availableQuery($productsQuery, MarketplaceCountry::filterValue($request));
        $products = $productsQuery->get(['id', 'product_stock']);

        // Create an associative array of product ID to stock quantity
        $stock = [];
        foreach ($products as $product) {
            $stock[$product->id] = $product->product_stock;
        }

        return response()->json(['status' => true, 'products_stock' => $stock]);
    }

    public function saveOrder(Request $request)
    {
        try {
            $data = $request->validate([
                'delivery_address' => ['required', 'string', 'max:2000'],
                'products' => ['required', 'array', 'min:1'],
                'products.*.product_id' => ['required', 'integer', 'exists:products,id'],
                'products.*.product_quantity' => ['required', 'integer', 'min:1', 'max:1000'],
                'products.*.variants' => ['nullable', 'array'],
                'delivery_country' => ['nullable', 'string', 'size:2', \Illuminate\Validation\Rule::in(array_keys(MarketplaceCountry::supported()))],
            ]);

            $destinationCountry = MarketplaceCountry::purchaseCountry($request);
            $requestedDeliveryCountry = MarketplaceCountry::normalize($data['delivery_country'] ?? null);
            abort_if($requestedDeliveryCountry !== null && $requestedDeliveryCountry !== $destinationCountry, 422, 'Delivery country must match the account country.');
            $orderDetail = DB::transaction(function () use ($data, $destinationCountry) {
                $lines = collect($data['products']);
                $quantities = $lines->groupBy('product_id')->map(fn ($group) => $group->sum('product_quantity'));
                $products = Product::whereIn('id', $quantities->keys()->all())
                    ->orderBy('id')
                    ->lockForUpdate()
                    ->get()
                    ->keyBy('id');

                $subTotal = 0;
                $shipping = 0;
                foreach ($quantities as $productId => $quantity) {
                    $product = $products->get($productId);
                    abort_unless($product && $product->status === 'Active' && $product->product_stock >= $quantity && $quantity >= $product->minimum_order_quantity, 422, 'This wholesale listing requires at least the minimum order quantity.');
                    abort_unless($product->isAvailableIn($destinationCountry), 422, 'This product is not available for delivery or purchase in your selected country.');
                    $subTotal += $product->priceForQuantity($quantity) * $quantity;
                    $shipping += $product->is_delivery_free ? 0 : $product->delivery_charge;
                }

                $number = generateOrderNo();
                $total = $subTotal + $shipping;
                $orderDetail = Orderdetail::create([
                    'user_id' => auth()->id(),
                    'order_no' => $number,
                    'delivery_address' => $data['delivery_address'],
                    'delivery_country' => $destinationCountry,
                    'sub_total' => $subTotal,
                    'shipping_cost' => $shipping,
                    'tax' => 0,
                    'tax_percentage' => 0,
                    'total_cost' => $total,
                    'payment_method' => 'Direct with seller',
                    'to_receive' => $total,
                    'to_send' => 0,
                    'to_pay' => $total,
                    'status' => 'Pending',
                    'date' => now()->toDateString(),
                    'time' => now()->format('h:i:s A'),
                    'month' => now()->format('F'),
                    'year' => now()->format('Y'),
                ]);

                foreach ($lines as $line) {
                    $product = $products->get($line['product_id']);
                    $quantity = (int) $line['product_quantity'];
                    $lineShipping = $product->is_delivery_free ? 0 : $product->delivery_charge;
                    Order::create([
                        'orderdetail_id' => $orderDetail->id,
                        'vendor_id' => $product->vendor_id,
                        'product_id' => $product->id,
                        'product_price' => $product->priceForQuantity($quantity),
                        'product_quantity' => $quantity,
                        'variants' => json_encode($line['variants'] ?? []),
                        'unit_total_price' => $product->priceForQuantity($quantity) * $quantity,
                        'return_available' => $product->return_available,
                        'warrenty_avaialbe' => $product->warrenty_available,
                        'to_review' => 0,
                        'shipping_cost' => $lineShipping,
                        'status' => 'Pending',
                    ]);
                    $product->decrement('product_stock', $quantity);
                }

                StatusLog::create([
                    'orderdetail_id' => $orderDetail->id,
                    'status' => 'Pending',
                    'timestamp' => time(),
                ]);

                return $orderDetail;
            });

            return response()->json([
                'success' => true,
                'order_id' => (int) $orderDetail->id,
                'order_no' => $orderDetail->order_no,
                'message' => __('marketplace.purchase_request_sent'),
            ]);
        } catch (Exception $e) {
            report($e);
            return response()->json(['success' => false, 'message' => 'Unable to place order.'], 422);
        }
    }
    public function acceptOrDeclineOrder($orderDetailId, Request $request)
    {
        try {
            DB::beginTransaction();
            $orderDetail = Orderdetail::where('id', $orderDetailId)->with('user', 'orders')->first();
            // Check if the OrderDetail exists
            if (!$orderDetail) {
                return response()->json([
                    'success' => false,
                    'message' => 'Order detail not found.'
                ], 404);
            }
            $user = $orderDetail->user;

            $specificVendorOrder = Order::where([
                'orderdetail_id' => $orderDetailId,
                'vendor_id' => auth()->user()->vendor->id
            ]);
            if (!$specificVendorOrder->exists()) {
                DB::rollBack();
                return response()->json(['success' => false, 'message' => 'Unauthorized'], 403);
            }

            $specificVendorOrder->update(['status' => $request->status]);

            if ($request->status == 'Declined' && $orderDetail->payment_method != "cod") {
                foreach ($specificVendorOrder->get() as $order) {
                    refund($user->id, $order->id);
                }
            }
            $toReceive = $orderDetail->to_receive;
            $toSent = $orderDetail->to_sent;
            $toPay = $orderDetail->to_pay;
            $status = $orderDetail->status;
            // Fetch the orders related to the specific order detail and vendor, excluding pending orders
            $orders = Order::where([
                'orderdetail_id' => $orderDetailId,
            ])
                ->get();

            // Fetch pending orders separately
            $pendingOrders = Order::where([
                'orderdetail_id' => $orderDetailId,
            ])
                ->where('status', 'Pending')
                ->count();

            // Extract statuses for existing orders
            $acceptedOrders = $orders->where('status', 'Accepted');
            $declinedOrders = $orders->where('status', 'Declined');

            // Determine the status based on the conditions
            if ($pendingOrders > 0) {
                // If there are any pending orders, keep the status as it is
                $status = $orderDetail->status;
            } elseif ($acceptedOrders->count() > 0 && $acceptedOrders->count() + $declinedOrders->count() === $orders->count() && $pendingOrders === 0) {
                // If any order is accepted and all others are declined (and none are pending)
                $status = 'Shipped';
                $toReceive = 0;
                $toSent = 1;
                addStatusLog($status, $orderDetail->id);
            } elseif ($declinedOrders->count() === $orders->count()) {
                // If all orders are declined
                $status = 'Cancelled';
                $toReceive = 0;
                $toSent = 0;
                foreach ($orderDetail->orders as $order) {
                    refund($orderDetail->user->id, $order->id);
                }
                addStatusLog($status, $orderDetail->id);
            } else {
                // Default case (should not hit this if all cases are covered)
                $status = $orderDetail->status;
            }


            $subTotal = Order::where('orderdetail_id', $orderDetailId)->sum('unit_total_price');
            $totalShippingCost = Order::where('orderdetail_id', $orderDetailId)->sum('shipping_cost');
            $taxPercentage = $orderDetail->tax_percentage;
            $tax = ($subTotal * $taxPercentage) / 100;
            $totalCost = $subTotal + $tax;
            $orderDetail->update([
                'sub_total' => $subTotal,
                'tax' => $tax,
                'total_cost' => $totalCost,
                'shipping_cost' => $totalShippingCost,
                'to_receive' => $toReceive,
                'to_sent' => $toSent,
                'to_pay' => $toPay,
                'status' => $status
            ]);


            sendMailToUser($user);
            DB::commit();
            return response()->json([
                'success' => true,
                'message' => 'Successfully Order Has Been ' . $request->status
            ]);

        } catch (Exception $e) {
            DB::rollBack();
            return response()->json([
                'message' => $e->getMessage(),
                'exception_code' => $e->getCode(),
                'exception_string' => $e->__toString()
            ]);
        }
    }

    public function orderLists(Request $request)
    {
        try {
            $query = Orderdetail::query();

            if ($request->has('from_date')) {
                $query->where('orderdetails.date', '>=', $request->from_date);
            }

            if ($request->has('to_date')) {
                $query->where('orderdetails.date', '<=', $request->to_date);
            }

            if ($request->has('status')) {
                $query->where('orderdetails.status', $request->status);
            }

            if (auth()->user()->hasRole('seller')) {
                $query->whereHas('orders', fn ($orders) => $orders->where('vendor_id', $this->vendorId()));
            } else {
                $query->where('orderdetails.user_id', auth()->id());
            }

            if ($request->has('search')) {
                $search = $request->search;
                $query->where('orderdetails.order_no', 'LIKE', "%$search%");
            }

            $data = $query->with(['orders' => function ($orders) {
                if (auth()->user()->hasRole('seller')) {
                    $orders->where('vendor_id', $this->vendorId());
                }
            }])->latest()->get();

            return response()->json(['status' => count($data) > 0, 'total' => count($data), 'data' => $data]);
        } catch (Exception $e) {
            $message = $e->getMessage();
            $code = $e->getCode();
            $string = $e->__toString();
            return response()->json(['message' => $message, 'execption_code' => $code, 'execption_string' => $string]);
        }
    }

    public function statusLogs(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'order_id' => 'required|integer',
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'status' => false,
                    'message' => 'Validation failed',
                    'errors' => $validator->errors()
                ], 422);
            }
            $logs = StatusLog::where('orderdetail_id', $request->order_id)->latest()->get();
            $detail = Orderdetail::find($request->order_id);
            if (!$detail || ($detail->user_id !== auth()->id() && !($this->vendorId() && $detail->orders()->where('vendor_id', $this->vendorId())->exists()))) {
                return response()->json(['success' => false, 'message' => 'Unauthorized'], 403);
            }
            return response()->json(['success' => count($logs) > 0, 'total' => count($logs), 'data' => $logs]);
        } catch (Exception $e) {
            $message = $e->getMessage();
            $code = $e->getCode();
            $string = $e->__toString();
            return response()->json(['message' => $message, 'execption_code' => $code, 'execption_string' => $string]);
        }
    }
    public function vendorOrderLogs(Request $request)
    {
        try {
            // Validate request
            $validator = Validator::make($request->all(), [
                'vendor_id' => 'required|integer',
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'status' => false,
                    'message' => 'Validation failed',
                    'errors' => $validator->errors()
                ], 422);
            }

            $vendorId = $this->vendorId();
            $query = Orderdetail::query();

            // Filter by vendor ID
            $query->whereHas('orders', function ($query) use ($vendorId) {
                $query->where('vendor_id', $vendorId);
            });

            // Search filter
            if ($request->has('search')) {
                $search = $request->search;
                $query->where('orderdetails.order_no', 'LIKE', "%$search%");
            }

            // Type-specific status filters applied to the related orders
            if ($request->has('type')) {
                $type = $request->type;
                $query->whereHas('orders', function ($query) use ($type, $vendorId) {
                    switch ($type) {
                        case 'pending':
                            $query->where('status', 'Pending')
                                ->where('vendor_id', $vendorId);
                            break;

                        case 'accepted':
                            $query->where('status', 'Accepted')
                                ->where('vendor_id', $vendorId)
                                ->whereDoesntHave('orderDetail', function ($query) {
                                    $query->where('status', 'Delivered');
                                });
                            break;

                        case 'declined':
                            $query->where('status', 'Declined')
                                ->where('vendor_id', $vendorId);
                            break;

                        case 'delivered':
                            $query->where('status', 'Accepted')
                                ->whereHas('orderDetail', function ($query) {
                                    $query->where('status', 'Delivered');
                                });
                            break;
                    }
                });
            }

            // Retrieve logs with vendor-specific orders
            $logs = $query->with([
                'orders' => function ($query) use ($vendorId) {
                    $query->where('vendor_id', $vendorId);  // Filter orders by vendor_id
                }
            ])
                ->latest()
                ->get();

            return response()->json([
                'success' => count($logs) > 0,
                'total' => count($logs),
                'data' => $logs
            ]);
        } catch (Exception $e) {
            return response()->json([
                'message' => $e->getMessage(),
                'exception_code' => $e->getCode(),
                'exception_string' => $e->__toString()
            ]);
        }
    }


    public function userOrderReviews(Request $request)
    {
        try {
            $userId = auth()->user()->id;

            // Retrieve all delivered order details for the user with their associated orders and products
            $orderDetails = OrderDetail::where(['user_id' => $userId, 'status' => 'Delivered'])
                ->with([
                    'orders' => function ($query) {
                        $query->where('to_review', '1')
                            ->where('status', '<>', 'Declined'); // Using '<>' for 'not equal'
                    },
                    'orders.product.variants',
                    'orders.product.images'
                ])
                ->get();

            // Map the orders and include their products
            $response = $orderDetails->flatMap(function ($orderDetail) {
                return $orderDetail->orders->map(function ($order) {
                    $product = $order->product; // Ensure product is correctly accessed

                    return [
                        'order_id' => strval($order->id),
                        'product_id' => strval($product->id),
                        'product_name' => $product->product_name,
                        'product_price' => $product->product_price,
                        'product_quantity' => $order->product_quantity,
                        'unit_total_price' => $order->unit_total_price,
                        'variants' => $product->variants->map(function ($variant) {
                            return [
                                'variant_name' => $variant->variant_name,
                                'variant_value' => $variant->pivot->variant_value
                            ];
                        }),
                        'images' => $product->images->map(function ($image) use ($product) {
                            return [
                                'id' => $image->id,
                                'src' => $image->src,
                                'created_at' => $image->created_at,
                                'updated_at' => $image->updated_at,
                                'pivot' => [
                                    'product_id' => strval($product->id),
                                    'image_id' => strval($image->id)
                                ]
                            ];
                        })
                    ];
                });
            });

            return response()->json([
                'status' => $response->isNotEmpty(),
                'total' => $response->count(),
                'data' => $response
            ]);

        } catch (Exception $e) {
            return response()->json([
                'message' => $e->getMessage(),
                'exception_code' => $e->getCode(),
                'exception_string' => $e->__toString()
            ]);
        }
    }


    public function stateOrderLogs(Request $request)
    {
        try {
            $query = Orderdetail::query();
            if (auth()->user()->hasRole('seller')) {
                $query->whereHas('orders', fn ($orders) => $orders->where('vendor_id', $this->vendorId()));
            } else {
                $query->where('user_id', auth()->id());
            }
            if ($request->has('to_pay')) {
                $query->where('to_pay', $request->to_pay);
            }

            if ($request->has('to_receive')) {
                $query->where('to_receive', $request->to_receive);
            }

            if ($request->has('to_send')) {
                $query->where('to_send', $request->to_send);
            }

            $data = $query->with(['orders' => function ($orders) {
                if (auth()->user()->hasRole('seller')) {
                    $orders->where('vendor_id', $this->vendorId());
                }
            }])->latest()->get();

            return response()->json(['status' => count($data) > 0, 'total' => count($data), 'data' => $data]);

        } catch (Exception $e) {
            $message = $e->getMessage();
            $code = $e->getCode();
            $string = $e->__toString();
            return response()->json(['message' => $message, 'execption_code' => $code, 'execption_string' => $string]);
        }
    }
    public function storeReview(Request $request)
    {
        DB::beginTransaction();
        try {
            $images = [];
            if ($request->has('images')) {
                foreach ($request->file('images') as $file) {
                    $name = time() . $file->getClientOriginalName();
                    $file->move(public_path() . '/uploads/reviews', $name);
                    $path = 'uploads/reviews/' . $name;
                    $images[] = $path;
                }
            } else {
                $path = NULL;
            }
            $order = Order::whereKey($request->order_id)->whereHas('orderDetail', fn ($q) => $q->where('user_id', auth()->id()))->first();
            if (!$order || (int) $order->product_id !== (int) $request->product_id) {
                DB::rollBack();
                return response()->json(['success' => false, 'message' => 'Unauthorized'], 403);
            }
            $review = new ProductReview();
            $review->user_id = auth()->user()->id;
            $review->order_id = $request->order_id;
            $review->product_id = $request->product_id;
            $review->rating = $request->rating;
            $review->review = $request->msg;
            $review->images = $request->has('images') ? json_encode($images) : $path;
            $review->save();

            $order->to_review = 0;
            $order->update();

            DB::commit();
            return response()->json(['success' => true, 'message' => 'Successfully a review has been taken']);

        } catch (Exception $e) {
            $message = $e->getMessage();
            $code = $e->getCode();
            $string = $e->__toString();
            DB::rollback();
            return response()->json(['message' => $message, 'execption_code' => $code, 'execption_string' => $string]);
        }
    }
   public function getCategoryDetails($id)
{
    $category = Category::with([
        'subcategories' => function ($query) {
            $query->where('status', '<>', 'Inactive') // Only active subcategories
                ->with(['products' => function ($query) {
                    $query->where('status', '<>', 'Inactive'); // Only active products
                }]);
        }
    ])->findOrFail($id);

    return $category;
}

    public function peymentMethods()
    {
        return response()->json([
            'status' => true,
            'payment_methods' => [
                'direct_seller' => [
                    'label' => __('marketplace.direct_seller_payment'),
                    'online' => false,
                ],
            ],
        ]);
    }
    public function orderTransaction(Request $request)
    {
        return response()->json([
            'status' => false,
            'message' => __('marketplace.no_in_app_payment'),
        ], 410);
    }

    public function contactDetails()
    {
        $settingsData = Setting::first();
        return response()->json([
            'email' => $settingsData->contact_email,
            'phone' => [
                $settingsData->contact_phone_first,
                $settingsData->contact_phone_second
            ]
        ]);
    }
    public function vendorsCustomers( $vendor)
    {
        try {
            $vendor=Vendor::whereId($vendor)->first();
            if (!$this->ownsVendor($vendor)) {
                return response()->json(['success' => false, 'message' => 'Unauthorized'], 403);
            }
            $orderDetailIds = Order::where('vendor_id', $vendor->id)
                ->distinct()
                ->pluck('orderdetail_id');

            $userIds = OrderDetail::whereIn('id', $orderDetailIds)
                ->distinct()
                ->pluck('user_id');

            $users = User::whereIn('id', $userIds)->get();

            return response()->json([
                'success' => true,
                'data' => $users,
            ], 200);
        } catch (Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 500);
        }
    }

    public function cardDetails($vendor)
    {
        try {
            $vendor = Vendor::find($vendor);
            if (!$this->ownsVendor($vendor)) {
                return response()->json(['success' => false, 'message' => 'Unauthorized'], 403);
            }
            $orderDetailIds = Order::where('vendor_id', $vendor->id)
                ->distinct()
                ->pluck('orderdetail_id');

            $monthlyRevenue = Order::select(
                DB::raw('DATE_FORMAT(orders.created_at, "%Y-%m") as month'),
                DB::raw('SUM(orders.unit_total_price) as total_revenue')
            )
                ->join('orderdetails', 'orders.orderdetail_id', '=', 'orderdetails.id')
                ->where('orderdetails.status', 'Delivered')
                ->where(['orders.vendor_id' => $vendor->id, 'orders.status' => 'Accepted'])
                ->groupBy(DB::raw('DATE_FORMAT(orders.created_at, "%Y-%m")'))
                ->orderBy('month', 'desc')
                ->limit(6)
                ->get()
                ->reverse();


            // Prepare data for the response
            $months = $monthlyRevenue->pluck('month')->map(function ($date) {
                return Carbon::parse($date)->format('F Y');
            });
            $revenues = $monthlyRevenue->pluck('total_revenue');

            //vendor orders
            $vendorOrders = OrderDetail::whereIn('id', $orderDetailIds);

            //vendorTotalRevenue
            $vendorTotalRevenue = Order::join('orderdetails', 'orders.orderdetail_id', '=', 'orderdetails.id')
                ->where(['orders.vendor_id' => $vendor->id, 'orders.status' => 'Accepted'])
                ->where('orderdetails.status', 'Delivered')
                ->sum('orders.unit_total_price');


            // total orders
            $totalOrders = $vendorOrders->count();

            // Count pending orders (status is empty)
            $pendingOrders = Order::whereIn('orderdetail_id', $orderDetailIds)
                ->where(['status' => 'Pending', 'vendor_id' => $vendor->id])
                ->distinct('orderdetail_id')
                ->count();
            // Count accepted orders (status is empty)
            $acceptedOrders = Order::whereIn('orderdetail_id', $orderDetailIds)
                ->where(['status' => 'Accepted', 'vendor_id' => $vendor->id])
                ->whereHas('orderDetail', function ($query) {
                    $query->where('status', '<>', 'Delivered');
                })->distinct('orderdetail_id')
                ->count();
            // Count cancelled orders (status is 'Cancelled')
            $cancelledOrders = Order::whereIn('orderdetail_id', $orderDetailIds)
                ->where(['status' => 'Declined', 'vendor_id' => $vendor->id])
                ->distinct('orderdetail_id')
                ->count();

            // Count completed orders (status is 'Delivered')
            $completedOrders = Order::whereIn('orderdetail_id', $orderDetailIds)
                ->where(['status' => 'Accepted', 'vendor_id' => $vendor->id])
                ->whereHas('orderDetail', function ($query) {
                    $query->where('status', 'Delivered');
                })->distinct('orderdetail_id')
                ->count();

            return response()->json([
                'success' => true,
                'data' => [
                    'monthly_revenue' => [
                        'months' => $months,
                        'revenues' => $revenues,
                    ],
                    'total_revenue' => $vendorTotalRevenue,
                    'total_orders' => $totalOrders,
                    'pending_orders' => $pendingOrders,
                    'accepted_orders' => $acceptedOrders,
                    'cancelled_orders' => $cancelledOrders,
                    'completed_orders' => $completedOrders,
                ],
            ], 200);
        } catch (Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 500);
        }
    }
    public function userOrderProducts($orderDetailId)
    {
        try {
            $detail = Orderdetail::find($orderDetailId);
            if (!$detail || ($detail->user_id !== auth()->id() && !($this->vendorId() && $detail->orders()->where('vendor_id', $this->vendorId())->exists()))) {
                return response()->json(['success' => false, 'message' => 'Unauthorized'], 403);
            }
            $orderProducts = Order::where('orderdetail_id', $orderDetailId)
                ->when(auth()->user()->hasRole('seller'), fn ($orders) => $orders->where('vendor_id', $this->vendorId()))
                ->with('product', 'product.images')->get();
            return response()->json([
                'success' => true,
                'data' => $orderProducts

            ], 200);
        } catch (Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 500);
        }
    }
    public function gateWays()
    {
        return response()->json([
            'status' => true,
            'gateways' => ['direct_seller'],
            'message' => __('marketplace.no_in_app_payment'),
        ]);
    }
    public function addCard(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'vendor_id' => 'required|exists:vendors,id',
            'bank_name' => 'required|string',
            'account_no' => 'required|string',
            'cvc' => 'required|integer',
            'expiry_month' => 'required|integer',
            'expiry_year' => 'required|integer',
            'holder_name' => 'required|string'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'message' => 'Validation Error',
                'errors' => $validator->errors()
            ], 422);
        }
        if ((int) $request->vendor_id !== $this->vendorId()) {
            return response()->json(['status' => false, 'message' => 'Unauthorized'], 403);
        }
        try {

            $cardDetail = $this->cardDetailService->addCard($request);
            return response()->json([
                'status' => true,
                'message' => 'Card Added Successfully.'
            ]);

        } catch (Exception $e) {
            $message = $e->getMessage();
            $code = $e->getCode();
            $string = $e->__toString();
            return response()->json(['message' => $message, 'execption_code' => $code, 'execption_string' => $string]);
        }
    }

    public function deleteCard(Request $request, $id)
    {
        try {

            $card = \App\Models\CardDetail::find($id);
            if (!$card || (int) $card->vendor_id !== $this->vendorId()) {
                return response()->json(['success' => false, 'message' => 'Unauthorized'], 403);
            }
            $this->cardDetailService->deleteCard($id);
            return response()->json([
                'success' => true,
                'message' => 'Card Deleted Successfully',
            ], 200);
        } catch (Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 500);
        }
    }

    public function getCardsByVendorId($vendor)
    {
        try {

            if ((int) $vendor !== $this->vendorId()) {
                return response()->json(['success' => false, 'message' => 'Unauthorized'], 403);
            }
            $result = $this->cardDetailService->getCardsByVendorId($vendor);

            if (isset($result['status']) && $result['status'] == 404) {
                return response()->json(['message' => $result['message']], $result['status']);
            }

            return response()->json([
                'success' => true,
                'data' => $result,
            ], 200);
        } catch (Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 500);
        }
    }
    public function getBalanceAmount($vendor)
    {
        try {
            if ((int) $vendor !== $this->vendorId()) {
                return response()->json(['success' => false, 'message' => 'Unauthorized'], 403);
            }
            $balance = $this->vendorService->getVendorBalance($vendor);

            return response()->json([
                'success' => true,
                'vendor_balance' => $balance ?? 0.00,
                'withdraw_charge' => Setting::first()->withdraw_charge
            ], 200);
        } catch (Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 500);
        }
    }
    public function makeWithdrawRequest(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'vendor_id' => 'required|exists:vendors,id',
                'amount' => 'required|numeric|min:0.01',
                'card_id' => 'required|exists:card_details,id',
                'status' => 'required|string'
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'message' => 'Validation Error',
                    'errors' => $validator->errors()
                ], 422);
            }
            if ((int) $request->vendor_id !== $this->vendorId() || !\App\Models\CardDetail::whereKey($request->card_id)->where('vendor_id', $this->vendorId())->exists()) {
                return response()->json(['success' => false, 'message' => 'Unauthorized'], 403);
            }
            $request->merge(['vendor_id' => $this->vendorId(), 'status' => 'Pending']);
            $this->withdrawRequestLogService->makeRequest($request);

            return response()->json([
                'success' => true,
                'message' => 'Withdraw Request Has Been Made.',
            ], 200);
        } catch (Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 500);
        }
    }
    public function filterWithdrawRequests(Request $request)
    {
        try {
            $request->merge(['vendor_id' => $this->vendorId()]);
            $withdrawRequests = $this->withdrawRequestLogService->filterWithdrawRequests($request);

            return response()->json([
                'message' => 'Withdraw requests retrieved successfully',
                'data' => $withdrawRequests
            ], 200);
        } catch (Exception $e) {
            return response()->json([
                'message' => $e->getMessage(),
                'exception_code' => $e->getCode(),
                'exception_string' => $e->__toString()
            ], 500);
        }
    }


    public function getVendorAmountSatement($vendorId)
    {
        try {
            if ((int) $vendorId !== $this->vendorId()) {
                return response()->json(['status' => false, 'message' => 'Unauthorized'], 403);
            }
            // Fetch the order details where the related orders have 'Delivered' status
            $orderDetails = Order::join('orderdetails', 'orders.orderdetail_id', '=', 'orderdetails.id')
                ->where('orders.vendor_id', $vendorId)
                ->where('orderdetails.status', 'Delivered')
                ->get(['orderdetails.id as orderdetail_id', 'orders.unit_total_price', 'orderdetails.created_at']);

            // Group by orderdetail_id and sum unit_total_price
            $groupedOrderDetails = $orderDetails->groupBy('orderdetail_id')
                ->map(function ($orders) {
                    return [
                        'created_at' => $orders->first()->created_at->format('d-m-Y H:i:s'), // Human-readable format
                        'total_amount' => (double) $orders->sum('unit_total_price'),
                        'type' => 'Credit'
                    ];
                })
                ->values(); // Convert the collection to an array

            // Fetch the approved withdrawals
            $withdraws = WithdrawRequestLog::where([
                'status' => 'Approved',
                'vendor_id' => $vendorId
            ])
                ->get(['created_at', 'amount'])
                ->map(function ($withdraw) {
                    return [
                        'created_at' => $withdraw->created_at->format('d-m-Y H:i:s'), // Human-readable format
                        'total_amount' => (float) $withdraw->amount,
                        'type' => 'Debit'
                    ];
                })
                ->toArray();

            // Combine order details and withdrawals
            $combined = array_merge($groupedOrderDetails->toArray(), $withdraws);

            // Sort combined array by date
            usort($combined, function ($a, $b) {
                return strtotime($a['created_at']) - strtotime($b['created_at']);
            });

            // Prepare the response
            $response = [
                'status' => true,
                'vendor_id' => $vendorId,
                'transactions' => $combined
            ];

            return response()->json($response);
        } catch (Exception $e) {
            $message = $e->getMessage();
            $code = $e->getCode();
            $string = $e->__toString();
            return response()->json([
                'status' => false,
                'message' => $message,
                'exception_code' => $code,
                'exception_string' => $string
            ]);
        }
    }

    public function orderDetails($orderId, $vendorId)
    {
        if ((int) $vendorId !== $this->vendorId()) {
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 403);
        }
        $orderDetails = OrderDetail::whereId($orderId)
            ->whereHas('orders', function ($query) use ($vendorId) {
                $query->where('vendor_id', $vendorId);
            })
            ->with([
                'user',
                'orders' => function ($query) use ($vendorId) {
                    $query->where('vendor_id', $vendorId);  // Filter orders by vendor_id
                },
                'orders.product.images'
            ])
            ->first();

        if ($orderDetails) {
            return response()->json([
                'success' => true,
                'data' => $orderDetails
            ]);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'Order details not found for the given vendor.'
            ], 404);
        }
    }

    private function vendorId(): ?int
    {
        return optional(auth()->user()->vendor)->id;
    }

    private function ownsVendor(?Vendor $vendor): bool
    {
        return $vendor && $this->vendorId() && (int) $vendor->id === (int) $this->vendorId();
    }

    private function priceTierErrors(array $tiers): array
    {
        $normalized = collect($tiers)
            ->filter(fn ($tier) => is_array($tier) && (($tier['min_quantity'] ?? '') !== '' || ($tier['unit_price'] ?? '') !== ''))
            ->map(fn ($tier) => [
                'min_quantity' => (int) ($tier['min_quantity'] ?? 0),
                'max_quantity' => ($tier['max_quantity'] ?? '') === '' ? null : (int) $tier['max_quantity'],
                'unit_price' => (float) ($tier['unit_price'] ?? -1),
            ])
            ->values()
            ->all();

        usort($normalized, fn (array $left, array $right) => $left['min_quantity'] <=> $right['min_quantity']);
        $errors = [];
        $previous = null;
        foreach ($normalized as $index => $tier) {
            if ($tier['min_quantity'] < 1 || $tier['unit_price'] < 0) {
                $errors["price_tiers.$index"][] = __('validation.custom.price_tier_values');
            }
            if ($tier['max_quantity'] !== null && $tier['max_quantity'] < $tier['min_quantity']) {
                $errors["price_tiers.$index.max_quantity"][] = __('validation.custom.price_tier_range');
            }
            if ($previous !== null && ($previous['max_quantity'] === null || $tier['min_quantity'] <= $previous['max_quantity'])) {
                $errors["price_tiers.$index.min_quantity"][] = __('validation.custom.price_tier_overlap');
            }
            $previous = $tier;
        }

        return $errors;
    }


}
