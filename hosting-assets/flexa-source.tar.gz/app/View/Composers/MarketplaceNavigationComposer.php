<?php

namespace App\View\Composers;

use App\Models\CartItem;
use App\Models\Favorite;
use App\Models\MarketplaceNotification;
use App\Models\Message;
use App\Models\Orderdetail;
use App\Support\MarketplaceCountry;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;

class MarketplaceNavigationComposer
{
    public function compose(View $view): void
    {
        $user = Auth::user();
        $isSeller = $user?->canSell() ?? false;
        $counts = [
            'cart' => 0,
            'favorites' => 0,
            'messages' => 0,
            'notifications' => 0,
            'orders' => 0,
        ];

        if ($user) {
            $counts['cart'] = (int) CartItem::whereHas('cart', fn ($query) => $query->where('user_id', $user->id))->sum('quantity');
            $counts['favorites'] = (int) Favorite::where('user_id', $user->id)->count();
            $counts['messages'] = (int) Message::where('recipient_id', $user->id)->whereNull('read_at')->count();
            $counts['notifications'] = (int) MarketplaceNotification::where('user_id', $user->id)->whereNull('read_at')->count();
            $counts['orders'] = (int) Orderdetail::where('user_id', $user->id)->count();
        }

        $view->with('marketplaceNavigation', [
            'user' => $user,
            'isSeller' => $isSeller,
            'counts' => $counts,
            'accountCountry' => MarketplaceCountry::details($user?->country),
            'marketplaceCountry' => MarketplaceCountry::selection(),
        ]);
    }
}