<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Blade;
use Session;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\View;
use App\Services\CategoryService; 
use App\Services\SubcategoryService; 

use App\Services\ProductService; 
use App\Services\UnitService; 

use App\Services\VariantService; 

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        $this->app->bind(CategoryService::class, function ($app) {
            return new CategoryService(
                $app->make(ProductService::class),
                $app->make(SubcategoryService::class)
            );
        });
    
        $this->app->bind(SubcategoryService::class, function ($app) {
            return new SubcategoryService(
                $app->make(ProductService::class)
            );
        });
    
        $this->app->bind(ProductService::class, function ($app) {
            return new ProductService();
        });
    
        $this->app->bind(UnitService::class, function ($app) {
            return new UnitService(
                $app->make(ProductService::class)
            );
        });
    
        $this->app->bind(VariantService::class, function ($app) {
            return new VariantService();
        });
    }


    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        Paginator::useBootstrap();
        Schema::defaultStringLength(191);
        View::composer('marketplace.layout', \App\View\Composers\MarketplaceNavigationComposer::class);
        Blade::directive('toastr', function ($expression){
            return "<script>
                    toastr.{{ Session::get('alert-type') }}($expression)
                 </script>";
        });
    }
}
