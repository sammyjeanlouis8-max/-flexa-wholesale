<?php

use App\Http\Controllers\AccessController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\ChatController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\IndexController;
use App\Http\Controllers\InstallController;
use App\Http\Controllers\LocaleController;
use App\Http\Controllers\MarketplaceController;
use App\Http\Controllers\MarketplaceCountryController;
use App\Http\Controllers\PasswordResetController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\SellerWorkspaceController;
use App\Http\Controllers\SettingController;
use App\Http\Controllers\SliderController;
use App\Http\Controllers\SubcategoryController;
use App\Http\Controllers\UnitController;
use App\Http\Controllers\VariantController;
use App\Http\Controllers\VendorController;
use App\Http\Controllers\WithdrawRequestLogController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::middleware('locale')->group(function () {
    Route::get('/', [MarketplaceController::class, 'home'])->name('marketplace.home');
    Route::get('/search', [MarketplaceController::class, 'search'])->name('marketplace.search');
    Route::get('/search/suggestions', [MarketplaceController::class, 'searchSuggestions'])->name('marketplace.search.suggestions');
    Route::get('/marketplace/products/{product}', [MarketplaceController::class, 'product'])->name('marketplace.product');
    Route::get('/stores/{vendor}', [MarketplaceController::class, 'store'])->name('marketplace.store');

    Route::get('/auth', [AccessController::class, 'show'])->name('auth.show');
    Route::get('/login', [AccessController::class, 'show'])->name('login');
    Route::get('/signup', [AccessController::class, 'show'])->name('signup');
    Route::post('/login', [AccessController::class, 'login'])->name('auth.login');
    Route::post('/register', [AccessController::class, 'register'])->name('auth.register');
    Route::get('/password/forgot', [PasswordResetController::class, 'showRequest'])->name('password.request');
    Route::post('/password/email', [PasswordResetController::class, 'sendResetLink'])->name('password.email');
    Route::get('/password/reset/{token}', [PasswordResetController::class, 'showResetForm'])->name('password.reset');
    Route::post('/password/reset', [PasswordResetController::class, 'reset'])->name('password.update');
    Route::post('admin-login', [AccessController::class, 'adminLogin']);
    Route::post('/logout', [AccessController::class, 'logout'])->name('logout');
    Route::post('/locale/{locale}', [LocaleController::class, 'update'])->name('locale.update');
    Route::post('/marketplace-country/{country}', [MarketplaceCountryController::class, 'update'])->name('marketplace.country.update');
});

Route::middleware(['auth', 'locale', 'prevent-back-history'])->group(function () {
    Route::get('/dashboard', [AccessController::class, 'redirectToDashboard'])->name('dashboard');
    Route::get('/buyer/dashboard', [DashboardController::class, 'buyer'])->middleware('role:buyer,seller')->name('buyer.dashboard');
    Route::middleware('role:buyer,seller')->group(function () {
        Route::get('/favorites', [MarketplaceController::class, 'favorites'])->name('marketplace.favorites');
        Route::post('/favorites/{product}', [MarketplaceController::class, 'addFavorite'])->name('marketplace.favorite.add');
        Route::delete('/favorites/{favorite}', [MarketplaceController::class, 'removeFavorite'])->name('marketplace.favorite.remove');
        Route::get('/cart', [MarketplaceController::class, 'cart'])->name('marketplace.cart');
        Route::post('/cart/{product}', [MarketplaceController::class, 'addToCart'])->name('marketplace.cart.add');
        Route::patch('/cart/items/{item}', [MarketplaceController::class, 'updateCart'])->name('marketplace.cart.update');
        Route::delete('/cart/items/{item}', [MarketplaceController::class, 'removeFromCart'])->name('marketplace.cart.remove');
        Route::get('/checkout', [MarketplaceController::class, 'checkout'])->name('marketplace.checkout');
        Route::post('/checkout', [MarketplaceController::class, 'placeOrder'])->name('marketplace.checkout.place');
        Route::get('/my-orders', [MarketplaceController::class, 'orders'])->name('marketplace.orders');
        Route::get('/my-orders/{order}', [MarketplaceController::class, 'order'])->name('marketplace.order');
        Route::get('/messages', [MarketplaceController::class, 'messages'])->name('marketplace.messages');
        Route::get('/notifications', [MarketplaceController::class, 'notifications'])->name('marketplace.notifications');
        Route::get('/profile', [MarketplaceController::class, 'profile'])->name('marketplace.profile');
        Route::patch('/profile', [MarketplaceController::class, 'updateProfile'])->name('marketplace.profile.update');
        Route::get('/settings', [MarketplaceController::class, 'settings'])->name('marketplace.settings');
        Route::patch('/settings', [MarketplaceController::class, 'updateSettings'])->name('marketplace.settings.update');
    });
    Route::middleware('role:seller')->prefix('seller')->group(function () {
        Route::get('/dashboard', [SellerWorkspaceController::class, 'dashboard'])->name('seller.dashboard');
        Route::get('/products', [SellerWorkspaceController::class, 'products'])->name('seller.products');
        Route::get('/products/create', [SellerWorkspaceController::class, 'createProduct'])->name('seller.product-create');
        Route::post('/products', [SellerWorkspaceController::class, 'storeProduct'])->name('seller.product-store');
        Route::get('/products/{product}/edit', [SellerWorkspaceController::class, 'editProduct'])->name('seller.product-edit');
        Route::patch('/products/{product}', [SellerWorkspaceController::class, 'updateProduct'])->name('seller.product-update');
        Route::get('/orders', [SellerWorkspaceController::class, 'orders'])->name('seller.orders');
        Route::get('/customers', [SellerWorkspaceController::class, 'customers'])->name('seller.customers');
        Route::get('/earnings', [SellerWorkspaceController::class, 'earnings'])->name('seller.earnings');
        Route::get('/plans', [SellerWorkspaceController::class, 'plans'])->name('seller.plans');
        Route::get('/settings', [SellerWorkspaceController::class, 'settings'])->name('seller.settings');
        Route::patch('/settings', [SellerWorkspaceController::class, 'updateSettings'])->name('seller.settings.update');
    });
    Route::get('/admin/dashboard', [DashboardController::class, 'Dashboard'])->middleware('role:admin,owner')->name('admin.dashboard');

    Route::middleware('role:admin,owner')->group(function () {

    Route::resource('categories', CategoryController::class)->middleware('permission:manage_categories');
    Route::resource('subcategories', SubcategoryController::class)->middleware('permission:manage_categories');
    Route::resource('products', ProductController::class)->middleware('permission:manage_products');
    Route::resource('units', UnitController::class)->middleware('permission:manage_marketplace');
    Route::resource('variants', VariantController::class)->middleware('permission:manage_marketplace');
    Route::resource('sliders', SliderController::class)->middleware('permission:manage_promotions');
    Route::resource('vendors', VendorController::class)->middleware('permission:manage_sellers');

    Route::get('/get-settings', [SettingController::class, 'getSettings'])->middleware('permission:manage_settings');
    Route::post('/update-settings', [SettingController::class, 'updateSettings'])->middleware('permission:manage_settings');
    Route::get('/mail-settings', [SettingController::class, 'mailSettings'])->middleware('permission:manage_settings');
    Route::post('settings-mail', [SettingController::class, 'settingsMail'])->middleware('permission:manage_settings');
    Route::get('/refunds', [SettingController::class, 'refundLogs'])->middleware('permission:manage_payments');
    Route::get('/orders', [SettingController::class, 'orders'])->middleware('permission:manage_orders');
    Route::get('/orders/{id}', [SettingController::class, 'showOrderDetails'])->middleware('permission:manage_orders');
    Route::get('/support-chat', [ChatController::class, 'realCrud'])->middleware('permission:manage_support')->name('support-chat');
    Route::match(['get', 'post'], '/withdraw-requests', [WithdrawRequestLogController::class, 'getWithdrawStatement'])->middleware('permission:manage_payments')->name('withdraw-statement');
    Route::get('/withdraw-requests/{id}/card-details', [WithdrawRequestLogController::class, 'getCardDetails'])->middleware('permission:manage_payments');
    Route::put('/orders/{id}/status', [SettingController::class, 'updateOrderStatus'])->middleware('permission:manage_orders')->name('orders.updateStatus');
    Route::put('/withdraw/{id}/status', [WithdrawRequestLogController::class, 'updateWithdrawStatus'])->middleware('permission:manage_payments');
    Route::get('/refund-details/{id}', [SettingController::class, 'getRefundDetails'])->middleware('permission:manage_payments');

    Route::get('admin-settings', [SettingController::class, 'showSettingsPage'])->middleware('permission:manage_settings')->name('admin.settings');
    Route::post('update-admin-profile', [SettingController::class, 'updateProfile'])->middleware('permission:manage_settings')->name('admin.updateProfile');
    Route::post('update-admin-password', [SettingController::class, 'updatePassword'])->middleware('permission:manage_settings')->name('admin.updatePassword');

    Route::middleware('role:owner')->group(function () {
        Route::get('/admin-management', [AdminController::class, 'index'])->name('admin-management.index');
        Route::post('/admin-management', [AdminController::class, 'store'])->name('admin-management.store');
        Route::post('/admin-management/promote', [AdminController::class, 'promote'])->name('admin-management.promote');
        Route::put('/admin-management/{admin}', [AdminController::class, 'update'])->name('admin-management.update');
        Route::delete('/admin-management/{admin}', [AdminController::class, 'destroy'])->name('admin-management.destroy');
        Route::patch('/admin-management/{admin}/demote', [AdminController::class, 'demote'])->name('admin-management.demote');
        Route::patch('/admin-management/{admin}/suspend', [AdminController::class, 'suspend'])->name('admin-management.suspend');
        Route::patch('/admin-management/{admin}/restore', [AdminController::class, 'restore'])->name('admin-management.restore');
    });
    });
});

Route::get('/get-variants/{categoryId}', [VariantController::class, 'getVariantsCategoryWise']);
Route::get('/get-variant-values/{variantId}', [VariantController::class, 'getVariantValues']);

Route::get('/install', [InstallController::class, 'install']);
Route::post('store-info', [InstallController::class, 'storeInfo']);
Route::get('/admin-register', [InstallController::class, 'register']);
Route::post('register-admin', [InstallController::class, 'registerAdmin']);