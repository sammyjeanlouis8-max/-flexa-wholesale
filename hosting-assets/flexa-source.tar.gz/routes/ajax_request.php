<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AjaxRequestController;

Route::middleware(['auth', 'role:admin,owner'])->group(function () {
    Route::patch('/active-category/{id}', [AjaxRequestController::class, 'activeCategory'])->middleware('permission:manage_categories');
    Route::patch('/decline-category/{id}', [AjaxRequestController::class, 'declineCategory'])->middleware('permission:manage_categories');
    Route::patch('/active-subcategory/{id}', [AjaxRequestController::class, 'activeSubcategory'])->middleware('permission:manage_categories');
    Route::patch('/decline-subcategory/{id}', [AjaxRequestController::class, 'declineSubcategory'])->middleware('permission:manage_categories');
    Route::patch('/active-unit/{id}', [AjaxRequestController::class, 'activeUnit'])->middleware('permission:manage_marketplace');
    Route::patch('/decline-unit/{id}', [AjaxRequestController::class, 'declineUnit'])->middleware('permission:manage_marketplace');
    Route::patch('/active-product/{id}', [AjaxRequestController::class, 'activeProduct'])->middleware('permission:manage_products');
    Route::patch('/decline-product/{id}', [AjaxRequestController::class, 'declineProduct'])->middleware('permission:manage_products');
    Route::patch('/active-vendor/{id}', [AjaxRequestController::class, 'activeVendor'])->middleware('permission:manage_sellers');
    Route::patch('/decline-vendor/{id}', [AjaxRequestController::class, 'declineVendor'])->middleware('permission:manage_sellers');
    Route::patch('/active-slider/{id}', [AjaxRequestController::class, 'activeSlider'])->middleware('permission:manage_promotions');
    Route::patch('/decline-slider/{id}', [AjaxRequestController::class, 'declineSlider'])->middleware('permission:manage_promotions');
});

Route::get('/get-subcategories/{id}', [AjaxRequestController::class, 'getSubcategories']);
Route::get('/getVariants/{categoryId}', [AjaxRequestController::class, 'getVariants']);
// Route::get('/accept-withdraw/{id}', [AjaxRequestController::class, 'acceptWithdraw']);
// Route::get('/reject-withdraw/{id}', [AjaxRequestController::class, 'rejectWithdraw']);
