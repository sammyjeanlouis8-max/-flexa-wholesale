<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ApiController;
use App\Http\Controllers\ApiAuthController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

//authentication

Route::post('login', [ApiAuthController::class, 'login']);
Route::post('user-login', [ApiAuthController::class, 'userLogin']);
Route::post('user-register', [ApiAuthController::class, 'userRegister']);
Route::post('register', [ApiAuthController::class, 'register']);



Route::post('store-vendor', [ApiController::class, 'storeVendor']);

//categories

Route::get('categories', [ApiController::class, 'categories']);
Route::get('all-variants/{categoryId}', [ApiController::class, 'variants']);
Route::get('all-units/{vendorId}/{categoryId}', [ApiController::class, 'allUnits']);
Route::get('variant-values/{variantId}', [ApiController::class, 'variantValues']);
Route::get('sliders', [ApiController::class, 'sliders']);
Route::get('get-settings-data', [ApiController::class, 'getSettingsData']);
Route::get('all-categories', [ApiController::class, 'allCategories']);
Route::get('category-wise-sub-category/{categoryId}', [ApiController::class, 'categoryWiseSubCategory']);

Route::get('category-details/{category}', [ApiController::class, 'categoryDetails']);

Route::get('/get-category-details/{id}', [ApiController::class, 'getCategoryDetails']);

Route::get('sub-category-details/{subcategory}', [ApiController::class, 'subCategoryDetails']);
Route::get('product-details/{product}', [ApiController::class, 'productDetails']);


Route::get('all-products', [ApiController::class, 'allProducts']);
Route::post('available-stocks', [ApiController::class, 'availableStock']);


Route::post('reset-password', [ApiAuthController::class, 'resetPassword']); // intentionally unavailable without reset tokens


//
Route::get('ratings', [ApiController::class, 'ratingsByType']);

Route::get('payment-methods', [ApiController::class, 'peymentMethods']);
Route::get('support-details', [ApiController::class, 'contactDetails']);
Route::get('gateways', [ApiController::class, 'gateWays']);
Route::middleware('auth:sanctum')->group(function () {
    Route::post('update-user/{user}', [ApiAuthController::class, 'updateUser']);
    Route::get('user-profile/{userId}', [ApiAuthController::class, 'userProfile']);
    Route::post('update-vendor/{vendor}', [ApiController::class, 'updateVendor']);
    Route::post('/change-password', [ApiAuthController::class, 'changePass']);
    Route::middleware('role:seller')->group(function () {
        Route::get('/vendor-details/{id}', [ApiController::class, 'vendorDetails']);
        Route::post('store-product', [ApiController::class, 'storeProduct']);
        Route::post('update-product/{product}', [ApiController::class, 'updateProduct']);
        Route::post('delete-product/{product}', [ApiController::class, 'deleteProduct']);
        Route::post('vendor-order-logs', [ApiController::class, 'vendorOrderLogs']);
        Route::post('vendor-order-status-change/{orderDetailId}', [ApiController::class, 'acceptOrDeclineOrder']);
        Route::get('vendor-customers/{vendor}', [ApiController::class, 'vendorsCustomers']);
        Route::get('dashboard-card-details/{vendor}', [ApiController::class, 'cardDetails']);
        Route::get('get-vendor-tnx-statement/{vendorId}', [ApiController::class, 'getVendorAmountSatement']);
        Route::post('/add-card', [ApiController::class, 'addCard']);
        Route::post('/delete-card/{id}', [ApiController::class, 'deleteCard']);
        Route::get('/card-details/vendor/{vendor_id}', [ApiController::class, 'getCardsByVendorId']);
        Route::get('/get-vendor-balance/{vendor}', [ApiController::class, 'getBalanceAmount']);
        Route::post('/withdraw-request', [ApiController::class, 'makeWithdrawRequest']);
        Route::post('/withdraw-requests/filter', [ApiController::class, 'filterWithdrawRequests']);
        Route::get('order-details/{orderId}/{vendorId}', [ApiController::class, 'orderDetails']);
    });
    //logout
    Route::post('/logout', [ApiAuthController::class, 'logout']);

    //order
    Route::middleware('role:buyer,seller')->group(function () {
        Route::post('save-order', [ApiController::class, 'saveOrder']);
        Route::post('order-transaction', [ApiController::class, 'orderTransaction']);
        Route::post('store-ratings', [ApiController::class, 'storeRatings']);
    });
    Route::middleware('role:buyer,seller')->group(function () {
        Route::post('order-lists', [ApiController::class, 'orderLists']);
        Route::post('state-order-logs', [ApiController::class, 'stateOrderLogs']);
        Route::get('user-order-details/{orderDetailId}', [ApiController::class, 'userOrderProducts']);
        Route::post('status-logs', [ApiController::class, 'statusLogs']);
    });

    Route::post('user-logout', [ApiAuthController::class, 'userLogout']);

    Route::middleware('role:buyer,seller')->group(function () {
        Route::post('user-order-reviews', [ApiController::class, 'userOrderReviews']);
        Route::post('store-review', [ApiController::class, 'storeReview']);
    });
    //change password 
});
