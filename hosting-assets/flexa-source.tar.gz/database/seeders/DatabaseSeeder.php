<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Rating;
use App\Models\Product;
use App\Models\User;
use Faker\Factory as Faker;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker::create();

        // List of product IDs to seed ratings for
        $productIds = [1, 2, 4, 5, 6, 7, 8, 16, 18];

        // Assuming you have some users in the users table
        $userIds = User::pluck('id')->toArray();

        foreach ($productIds as $productId) {
            // Create a random number of ratings for each product
            for ($i = 0; $i < rand(5, 15); $i++) {
                Rating::create([
                    'user_id' => $faker->randomElement($userIds),
                    'rateable_id' => $productId,
                    'rateable_type' => Product::class,
                    'rating' => $faker->numberBetween(1, 5),
                    'comment' => $faker->sentence,
                ]);
            }
        }
    }
}
