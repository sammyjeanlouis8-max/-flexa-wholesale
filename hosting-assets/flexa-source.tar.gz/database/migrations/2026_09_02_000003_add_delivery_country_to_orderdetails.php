<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up()
    {
        if (Schema::hasTable('orderdetails') && !Schema::hasColumn('orderdetails', 'delivery_country')) {
            Schema::table('orderdetails', function (Blueprint $table) {
                $table->string('delivery_country', 2)->nullable()->index();
            });
        }
    }

    public function down()
    {
        if (Schema::hasTable('orderdetails') && Schema::hasColumn('orderdetails', 'delivery_country')) {
            Schema::table('orderdetails', function (Blueprint $table) {
                $table->dropColumn('delivery_country');
            });
        }
    }
};