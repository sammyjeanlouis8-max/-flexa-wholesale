<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        if (!Schema::hasColumn('users', 'is_primary_admin')) {
            Schema::table('users', function (Blueprint $table) {
                $table->boolean('is_primary_admin')->default(false);
            });
        }

        $primaryAdmin = DB::table('users')
            ->where('role_id', 1)
            ->orderBy('id')
            ->first();

        if ($primaryAdmin) {
            DB::table('users')
                ->where('id', $primaryAdmin->id)
                ->update(['is_primary_admin' => true]);
        }
    }

    public function down()
    {
        if (Schema::hasColumn('users', 'is_primary_admin')) {
            Schema::table('users', function (Blueprint $table) {
                $table->dropColumn('is_primary_admin');
            });
        }
    }
};