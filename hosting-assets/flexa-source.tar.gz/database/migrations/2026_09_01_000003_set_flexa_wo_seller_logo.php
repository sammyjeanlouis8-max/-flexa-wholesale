<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration {
    public function up(): void
    {
        DB::table('settings')
            ->whereIn('app_logo', [
                'public/uploads/logo/logo.png',
                'uploads/logo/logo.png',
                'public/upload/logo/logo.png',
                'custom/flexa-wo-seller-logo.png',
            ])
            ->update([
                'app_logo' => 'custom/flexa-wo-seller-logo.png',
                'updated_at' => now(),
            ]);
    }

    public function down(): void
    {
        // The previous logo path varied by installation and is not restored.
    }
};