<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up()
    {
        Schema::table('users', function (Blueprint $table) {
            $table->string('role')->nullable()->index()->after('role_id');
            $table->string('account_status')->default('active')->index()->after('status');
            $table->boolean('is_verified')->default(false)->after('account_status');
            $table->timestamp('last_login')->nullable()->after('is_verified');
            $table->integer('legacy_role_id')->nullable()->after('role_id');
        });

        DB::table('users')->orderBy('id')->each(function ($user) {
            $role = $user->is_primary_admin ? 'owner' : ((int) $user->role_id === 1 ? 'admin' : ((int) $user->role_id === 2 ? 'seller' : ((int) $user->role_id === 3 ? 'buyer' : null)));
            DB::table('users')->where('id', $user->id)->update([
                'role' => $role,
                'account_status' => strtolower($user->status ?? 'Active') === 'inactive' ? 'inactive' : 'active',
                'is_verified' => !empty($user->email_verified_at),
                'legacy_role_id' => $role ? null : $user->role_id,
            ]);
        });
    }

    public function down()
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn(['role', 'account_status', 'is_verified', 'last_login', 'legacy_role_id']);
        });
    }
};