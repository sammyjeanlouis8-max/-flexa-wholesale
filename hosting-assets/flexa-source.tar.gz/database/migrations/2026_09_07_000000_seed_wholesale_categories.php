<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        $defaultOwnerId = DB::table('users')->orderBy('id')->value('id') ?? 1;
        $now = now();
        $image = 'custom/flexa-wo-seller-logo.png';

        $categories = [
            'Agriculture & Garden',
            'Automotive & Transport',
            'Baby & Children',
            'Beauty & Personal Care',
            'Cleaning & Hygiene',
            'Construction & Hardware',
            'Electronics & Accessories',
            'Fashion & Apparel',
            'Food & Beverages',
            'Health & Wellness',
            'Home & Kitchen',
            'Jewelry & Accessories',
            'Office & School',
            'Packaging & Business Supplies',
            'Pet Supplies',
            'Sports & Fitness',
        ];

        foreach ($categories as $categoryName) {
            DB::table('categories')->insertOrIgnore([
                'user_id' => $defaultOwnerId,
                'category_name' => $categoryName,
                'status' => 'Active',
                'image' => $image,
                'created_at' => $now,
                'updated_at' => $now,
            ]);
        }
    }

    public function down(): void
    {
        DB::table('categories')
            ->whereIn('category_name', [
                'Agriculture & Garden',
                'Automotive & Transport',
                'Baby & Children',
                'Beauty & Personal Care',
                'Cleaning & Hygiene',
                'Construction & Hardware',
                'Electronics & Accessories',
                'Fashion & Apparel',
                'Food & Beverages',
                'Health & Wellness',
                'Home & Kitchen',
                'Jewelry & Accessories',
                'Office & School',
                'Packaging & Business Supplies',
                'Pet Supplies',
                'Sports & Fitness',
            ])
            ->delete();
    }
};