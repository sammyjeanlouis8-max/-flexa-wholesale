<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;

return new class extends Migration {
    public function up(): void
    {
        if (!Schema::hasTable('countries')) {
            return;
        }

        foreach ([
            'name' => 'string',
            'flag' => 'string',
            'currency_code' => 'string',
            'phone_code' => 'string',
        ] as $column => $type) {
            if (!Schema::hasColumn('countries', $column)) {
                Schema::table('countries', function (Blueprint $table) use ($column, $type) {
                    $table->{$type}($column)->nullable();
                });
            }
        }

        foreach (config('countries.supported', []) as $code => $country) {
            $name = is_array($country) ? ($country[0] ?? $code) : $country;
            DB::table('countries')->updateOrInsert(
                ['code' => $code],
                [
                    'name_key' => Str::snake(str_replace(' ', '_', $name)),
                    'name' => $name,
                    'flag' => is_array($country) ? ($country[1] ?? null) : null,
                    'currency_code' => is_array($country) ? ($country[2] ?? null) : null,
                    'phone_code' => is_array($country) ? ($country[3] ?? null) : null,
                    'updated_at' => now(),
                    'created_at' => now(),
                ]
            );
        }
    }

    public function down(): void
    {
        if (!Schema::hasTable('countries')) {
            return;
        }

        foreach (['phone_code', 'currency_code', 'flag', 'name'] as $column) {
            if (Schema::hasColumn('countries', $column)) {
                Schema::table('countries', fn (Blueprint $table) => $table->dropColumn($column));
            }
        }
    }
};