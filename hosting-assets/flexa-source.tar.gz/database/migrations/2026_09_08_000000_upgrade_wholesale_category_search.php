<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('categories', function (Blueprint $table) {
            $table->string('slug')->nullable()->unique()->after('category_name');
            $table->text('search_terms')->nullable()->after('slug');
        });

        $ownerId = DB::table('users')->orderBy('id')->value('id') ?? 1;
        $now = now();
        $image = 'custom/flexa-wo-seller-logo.png';
        $targetIds = [];

        foreach ($this->categories() as $slug => $definition) {
            $aliases = array_values(array_unique(array_merge([$definition['name']], $definition['aliases'])));
            $matches = DB::table('categories')
                ->where('slug', $slug)
                ->orWhereIn('category_name', $aliases)
                ->orderBy('id')
                ->get();

            $target = $matches->firstWhere('slug', $slug)
                ?? $matches->firstWhere('category_name', $definition['name'])
                ?? $matches->first();

            if ($target === null) {
                $targetId = DB::table('categories')->insertGetId([
                    'user_id' => $ownerId,
                    'category_name' => $definition['name'],
                    'slug' => $slug,
                    'search_terms' => $this->normalizeTerms($definition['terms']),
                    'status' => 'Active',
                    'image' => $image,
                    'created_at' => $now,
                    'updated_at' => $now,
                ]);
            } else {
                $targetId = $target->id;
                $duplicateIds = $matches->pluck('id')->reject(fn ($id) => (int) $id === (int) $targetId);
                $this->moveCategoryRelations($duplicateIds, $targetId);
                DB::table('categories')->whereIn('id', $duplicateIds)->update([
                    'status' => 'Inactive',
                    'slug' => null,
                    'updated_at' => $now,
                ]);
                DB::table('categories')->where('id', $targetId)->update([
                    'category_name' => $definition['name'],
                    'slug' => $slug,
                    'search_terms' => $this->normalizeTerms($definition['terms']),
                    'status' => 'Active',
                    'updated_at' => $now,
                ]);
            }

            $targetIds[$slug] = $targetId;
        }

        $legacyMappings = [
            'Cleaning & Hygiene' => 'health-wellness',
            'Office & School' => 'professional-industrial-supplies',
            'Packaging & Business Supplies' => 'professional-industrial-supplies',
            'Pet Supplies' => 'agriculture-livestock',
        ];

        foreach ($legacyMappings as $legacyName => $targetSlug) {
            $legacyIds = DB::table('categories')
                ->where('category_name', $legacyName)
                ->whereNotIn('id', array_values($targetIds))
                ->pluck('id');
            $this->moveCategoryRelations($legacyIds, $targetIds[$targetSlug]);
            DB::table('categories')->whereIn('id', $legacyIds)->update([
                'status' => 'Inactive',
                'slug' => null,
                'updated_at' => $now,
            ]);
        }

        $otherId = $targetIds['other-products'];
        $remainingIds = DB::table('categories')
            ->whereNotIn('id', array_values($targetIds))
            ->where('status', 'Active')
            ->pluck('id');
        $this->moveCategoryRelations($remainingIds, $otherId);
        DB::table('categories')->whereIn('id', $remainingIds)->update([
            'status' => 'Inactive',
            'slug' => null,
            'updated_at' => $now,
        ]);
    }

    public function down(): void
    {
        Schema::table('categories', function (Blueprint $table) {
            $table->dropUnique(['slug']);
            $table->dropColumn(['slug', 'search_terms']);
        });
    }

    private function moveCategoryRelations($sourceIds, int $targetId): void
    {
        if ($sourceIds->isEmpty()) {
            return;
        }

        DB::table('products')->whereIn('category_id', $sourceIds)->update(['category_id' => $targetId]);
        DB::table('subcategories')->whereIn('category_id', $sourceIds)->update(['category_id' => $targetId]);
        DB::table('variants')->whereIn('category_id', $sourceIds)->update(['category_id' => $targetId]);
    }

    private function normalizeTerms(array $terms): string
    {
        return collect($terms)
            ->map(fn ($term) => Str::lower(Str::ascii($term)))
            ->unique()
            ->implode(' ');
    }

    private function categories(): array
    {
        return [
            'food-beverages' => [
                'name' => 'Food & Beverages',
                'aliases' => ['Alimentation & Boissons'],
                'terms' => ['food', 'foods', 'beverage', 'beverages', 'drink', 'drinks', 'nourriture', 'alimentation', 'boisson', 'boissons', 'manje', 'bwason', 'comida', 'bebida'],
            ],
            'beauty-perfume-personal-care' => [
                'name' => 'Beauty, Perfume & Personal Care',
                'aliases' => ['Beauty & Personal Care', 'Beauté, Parfums & Soins personnels'],
                'terms' => ['beauty', 'perfume', 'fragrance', 'lotion', 'makeup', 'hair', 'shampoo', 'soap', 'cream', 'deodorant', 'beaute', 'parfum', 'soins personnels', 'bote', 'swen pesonel', 'belleza'],
            ],
            'fashion-clothing' => [
                'name' => 'Fashion & Clothing',
                'aliases' => ['Fashion & Apparel', 'Mode & Vêtements'],
                'terms' => ['fashion', 'clothing', 'clothes', 'apparel', 'shoe', 'shoes', 'bag', 'bags', 'accessories', 'mode', 'vetement', 'vetements', 'chaussure', 'chaussures', 'rad', 'soulye', 'ropa', 'zapatos'],
            ],
            'electronics-phones' => [
                'name' => 'Electronics & Phones',
                'aliases' => ['Electronics & Accessories', 'Électronique & Téléphones'],
                'terms' => ['electronics', 'phone', 'phones', 'computer', 'computers', 'tablet', 'television', 'charger', 'headphones', 'camera', 'electronique', 'telephone', 'ordinateur', 'telefòn', 'òdinatè', 'electronica', 'telefono'],
            ],
            'home-kitchen' => [
                'name' => 'Home & Kitchen',
                'aliases' => ['Maison & Cuisine'],
                'terms' => ['home', 'house', 'kitchen', 'furniture', 'decoration', 'bedding', 'curtain', 'maison', 'cuisine', 'meuble', 'kay', 'kwizin', 'muebles', 'cocina'],
            ],
            'home-appliances' => [
                'name' => 'Home Appliances',
                'aliases' => ['Appareils électroménagers'],
                'terms' => ['appliance', 'appliances', 'refrigerator', 'fridge', 'freezer', 'washing machine', 'stove', 'microwave', 'air conditioner', 'fan', 'electromenager', 'frigo', 'refrigerateur', 'aparèy', 'refrijerate', 'electrodomesticos'],
            ],
            'automotive-parts' => [
                'name' => 'Automotive & Parts',
                'aliases' => ['Automotive & Transport', 'Automobile & Pièces détachées'],
                'terms' => ['automotive', 'automobile', 'auto', 'car', 'vehicle', 'parts', 'tire', 'tires', 'battery', 'voiture', 'pieces detachees', 'machin', 'pyes machin', 'coche', 'repuestos'],
            ],
            'construction-hardware' => [
                'name' => 'Construction & Hardware',
                'aliases' => ['Construction & Bricolage'],
                'terms' => ['construction', 'hardware', 'building materials', 'tools', 'paint', 'plumbing', 'electrical', 'bricolage', 'materiaux', 'konstriksyon', 'zouti', 'construccion', 'ferreteria'],
            ],
            'agriculture-livestock' => [
                'name' => 'Agriculture & Livestock',
                'aliases' => ['Agriculture & Garden', 'Agriculture & Élevage'],
                'terms' => ['agriculture', 'farming', 'farm', 'livestock', 'seed', 'seeds', 'fertilizer', 'animal feed', 'elevage', 'semence', 'angre', 'elvaj', 'agricultura', 'ganado'],
            ],
            'baby-children' => [
                'name' => 'Baby & Children',
                'aliases' => ['Bébé & Enfants'],
                'terms' => ['baby', 'babies', 'children', 'kids', 'toy', 'toys', 'bebe', 'enfant', 'timoun', 'jwèt', 'nino', 'ninos'],
            ],
            'health-wellness' => [
                'name' => 'Health & Wellness',
                'aliases' => ['Santé & Bien-être'],
                'terms' => ['health', 'wellness', 'hygiene', 'authorized wellness', 'sante', 'bien etre', 'hygiene', 'sante', 'byennet', 'salud', 'bienestar'],
            ],
            'jewelry-accessories' => [
                'name' => 'Jewelry & Accessories',
                'aliases' => ['Bijoux & Accessoires'],
                'terms' => ['jewelry', 'jewellery', 'watch', 'watches', 'glasses', 'accessories', 'bijoux', 'montre', 'lunettes', 'bijou', 'mont', 'joyas', 'relojes'],
            ],
            'sports-leisure' => [
                'name' => 'Sports & Leisure',
                'aliases' => ['Sports & Fitness', 'Sport & Loisirs'],
                'terms' => ['sport', 'sports', 'fitness', 'leisure', 'bicycle', 'bike', 'games', 'loisirs', 'velo', 'espò', 'bisiklèt', 'deportes', 'ocio'],
            ],
            'professional-industrial-supplies' => [
                'name' => 'Professional & Industrial Supplies',
                'aliases' => ['Fournitures professionnelles & Industrielles'],
                'terms' => ['business', 'professional', 'industrial', 'restaurant', 'store', 'office', 'warehouse', 'industry', 'supplies', 'fournitures professionnelles', 'industrielles', 'biznis', 'endistriyel', 'suministros', 'industriales'],
            ],
            'used-products' => [
                'name' => 'Used Products',
                'aliases' => ['Produits d’occasion'],
                'terms' => ['used', 'second hand', 'preowned', 'pre-owned', 'occasion', 'usagé', 'itilize', 'dezyem men', 'usado', 'segunda mano'],
            ],
            'other-products' => [
                'name' => 'Other Products',
                'aliases' => ['Autres produits'],
                'terms' => ['other', 'others', 'miscellaneous', 'autre', 'autres', 'lot', 'divers', 'lòt', 'otros', 'varios'],
            ],
        ];
    }
};