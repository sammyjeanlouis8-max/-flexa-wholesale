<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('withdraw_request_logs', function (Blueprint $table) {
            $table->id();
            $table->integer('vendor_id');
            $table->decimal('amount', 10, 2);
            $table->decimal('actual_withDraw_amount', 10, 2);
            $table->string('tnx_id')->nullable();
            $table->integer('card_id');
            $table->string('status');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('withdraw_request_logs');
    }
};
