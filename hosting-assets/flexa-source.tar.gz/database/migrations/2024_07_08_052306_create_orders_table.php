<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('orders', function (Blueprint $table) {
            $table->id();
            $table->integer('orderdetail_id');
            $table->integer('vendor_id')->nullable();
            $table->integer('product_id');
            $table->integer('to_review')->nullable();
            $table->string('product_price');
            $table->string('product_quantity');
            $table->string('unit_total_price');
            $table->longText('variants')->nullable();
            $table->string('return_available')->nullable();
            $table->string('warrenty_avaialbe')->nullable();
            $table->string('shipping_cost')->nullable();
            $table->enum('status', ['Pending','Accepted', 'Declined'])->default('Pending');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('orders');
    }
};
