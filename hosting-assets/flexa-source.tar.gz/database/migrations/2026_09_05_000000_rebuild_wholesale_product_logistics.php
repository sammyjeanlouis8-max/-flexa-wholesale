<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (Schema::hasTable('products')) {
            Schema::table('products', function (Blueprint $table) {
                if (! Schema::hasColumn('products', 'postal_code')) {
                    $table->string('postal_code', 32)->nullable();
                }
                if (! Schema::hasColumn('products', 'sku')) {
                    $table->string('sku', 100)->nullable()->unique();
                }
                if (! Schema::hasColumn('products', 'minimum_order_quantity')) {
                    $table->unsignedInteger('minimum_order_quantity')->default(1);
                }
                if (! Schema::hasColumn('products', 'wholesale_unit_type')) {
                    $table->string('wholesale_unit_type', 32)->default('box');
                }
                if (! Schema::hasColumn('products', 'warehouse_name')) {
                    $table->string('warehouse_name')->nullable();
                }
                if (! Schema::hasColumn('products', 'warehouse_address')) {
                    $table->text('warehouse_address')->nullable();
                }
                if (! Schema::hasColumn('products', 'warehouse_city')) {
                    $table->string('warehouse_city')->nullable();
                }
                if (! Schema::hasColumn('products', 'warehouse_region')) {
                    $table->string('warehouse_region')->nullable();
                }
                if (! Schema::hasColumn('products', 'warehouse_postal_code')) {
                    $table->string('warehouse_postal_code', 32)->nullable();
                }
                if (! Schema::hasColumn('products', 'warehouse_country')) {
                    $table->string('warehouse_country', 2)->nullable();
                }
                if (! Schema::hasColumn('products', 'ships_internationally')) {
                    $table->boolean('ships_internationally')->default(false);
                }
                if (! Schema::hasColumn('products', 'offers_local_delivery')) {
                    $table->boolean('offers_local_delivery')->default(false);
                }
                if (! Schema::hasColumn('products', 'offers_warehouse_pickup')) {
                    $table->boolean('offers_warehouse_pickup')->default(false);
                }
                if (! Schema::hasColumn('products', 'offers_seller_delivery')) {
                    $table->boolean('offers_seller_delivery')->default(false);
                }
                if (! Schema::hasColumn('products', 'offers_marketplace_logistics')) {
                    $table->boolean('offers_marketplace_logistics')->default(false);
                }
            });
        }

        if (! Schema::hasTable('product_price_tiers')) {
            Schema::create('product_price_tiers', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('product_id');
                $table->unsignedInteger('min_quantity');
                $table->unsignedInteger('max_quantity')->nullable();
                $table->decimal('unit_price', 12, 2);
                $table->string('currency_code', 3)->nullable();
                $table->timestamps();

                $table->foreign('product_id')->references('id')->on('products')->cascadeOnDelete();
                $table->index(['product_id', 'min_quantity']);
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('product_price_tiers');

        if (Schema::hasTable('products')) {
            $columns = [
                'postal_code',
                'sku',
                'minimum_order_quantity',
                'wholesale_unit_type',
                'warehouse_name',
                'warehouse_address',
                'warehouse_city',
                'warehouse_region',
                'warehouse_postal_code',
                'warehouse_country',
                'ships_internationally',
                'offers_local_delivery',
                'offers_warehouse_pickup',
                'offers_seller_delivery',
                'offers_marketplace_logistics',
            ];

            foreach ($columns as $column) {
                if (Schema::hasColumn('products', $column)) {
                    Schema::table('products', fn (Blueprint $table) => $table->dropColumn($column));
                }
            }
        }
    }
};