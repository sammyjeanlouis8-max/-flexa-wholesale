<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (!Schema::hasTable('products') || !Schema::hasTable('countries') || !Schema::hasTable('product_country_availability')) {
            return;
        }

        DB::table('products')
            ->where(function ($query) {
                $query->where('availability_type', 'worldwide')
                    ->orWhereNull('availability_type');
            })
            ->orderBy('id')
            ->get(['id', 'country'])
            ->each(function ($product): void {
                $countryCode = strtoupper(trim((string) $product->country));
                $countryId = $countryCode === ''
                    ? null
                    : DB::table('countries')->where('code', $countryCode)->value('id');

                DB::table('products')
                    ->where('id', $product->id)
                    ->update(['availability_type' => 'selected']);

                if ($countryId) {
                    DB::table('product_country_availability')->updateOrInsert(
                        ['product_id' => $product->id, 'country_id' => $countryId],
                        []
                    );
                }
            });
    }

    public function down(): void
    {
        // Availability is intentionally not widened again when rolling back.
    }
};