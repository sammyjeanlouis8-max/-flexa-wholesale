<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up()
    {
        if (Schema::hasTable('users')) {
            if (! Schema::hasColumn('users', 'country')) {
                Schema::table('users', function (Blueprint $table) {
                    $table->string('country', 2)->nullable()->index();
                });
            }
            if (! Schema::hasColumn('users', 'city')) {
                Schema::table('users', function (Blueprint $table) {
                    $table->string('city')->nullable();
                });
            }
        }

        if (Schema::hasTable('products')) {
            if (! Schema::hasColumn('products', 'country')) {
                Schema::table('products', function (Blueprint $table) {
                    $table->string('country', 2)->nullable()->index();
                });
            }
            if (! Schema::hasColumn('products', 'city')) {
                Schema::table('products', function (Blueprint $table) {
                    $table->string('city')->nullable()->index();
                });
            }
            if (! Schema::hasColumn('products', 'region')) {
                Schema::table('products', function (Blueprint $table) {
                    $table->string('region')->nullable();
                });
            }
        }
    }

    public function down()
    {
        if (Schema::hasTable('users')) {
            foreach (['country', 'city'] as $column) {
                if (Schema::hasColumn('users', $column)) {
                    Schema::table('users', fn (Blueprint $table) => $table->dropColumn($column));
                }
            }
        }

        if (Schema::hasTable('products')) {
            foreach (['country', 'city', 'region'] as $column) {
                if (Schema::hasColumn('products', $column)) {
                    Schema::table('products', fn (Blueprint $table) => $table->dropColumn($column));
                }
            }
        }
    }
};