<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration {
    public function up(): void
    {
        DB::table('settings')
            ->whereIn('app_name', ['Explore', 'Laravel', 'Flexa Market', 'FlexaMarket'])
            ->update([
                'app_name' => 'Flexa Wo Seller',
                'updated_at' => now(),
            ]);
    }

    public function down(): void
    {
        // The previous value varied by installation and is not restored.
    }
};