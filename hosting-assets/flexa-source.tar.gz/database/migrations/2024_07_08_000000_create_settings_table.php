<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSettingsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('settings', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('app_name', 191)->default('Flexa Wo Seller')->nullable();
            $table->string('app_logo', 191)->default('uploads/logo/logo.png')->nullable();
            $table->string('currency', 191)->nullable();
            $table->string('currency_code', 191)->nullable();
            $table->string('currency_symbol', 191)->nullable();
            $table->double('shipping_charge', 10, 2)->default(0.00)->nullable();
            $table->double('tax', 10, 2)->default(0.00)->nullable();
            $table->double('withdraw_charge', 10, 2)->nullable();
            $table->string('contact_email', 191)->nullable();
            $table->string('contact_phone_first', 191)->nullable();
            $table->string('contact_phone_second', 191)->nullable();
            $table->string('fcm_secret_key', 191)->nullable();
            $table->string('admob_app_id', 191)->nullable();
            $table->string('admob_android_banner_id', 191)->nullable();
            $table->string('admob_ios_banner_id', 191)->nullable();
            $table->string('admob_android_interstial_id', 191)->nullable();
            $table->string('admob_ios_interstial_id', 191)->nullable();
            $table->string('admob_android_native_id', 191)->nullable();
            $table->string('admob_ios_native_id', 191)->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('settings');
    }
}
