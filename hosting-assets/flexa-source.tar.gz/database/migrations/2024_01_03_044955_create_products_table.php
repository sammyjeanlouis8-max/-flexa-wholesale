<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('products', function (Blueprint $table) {
            $table->id();
            $table->integer('vendor_id');
            $table->integer('category_id');
            $table->integer('subcategory_id')->nullable();
            $table->integer('unit_id');
            $table->string('product_name')->unique();
            $table->float('product_price', 10, 2);
            $table->text('product_short_description')->nullable();
            $table->integer('product_discount')->default('0');
            $table->integer('product_stock')->default('0');
            $table->integer('product_stock_limit')->default('0')->nullable();
            $table->integer('is_featured')->default('0');
            $table->integer('top_picks')->default('0');
            $table->integer('delivery_duration')->default('0');
            $table->enum('delivery_duration_unit', ['Days', 'Weeks', 'Months', 'Year']);
            $table->integer('return_available')->default('0');
            $table->double('delivery_charge',10,2)->default('0.00');
            $table->integer('is_delivery_free')->default('0');
            $table->integer('warrenty_available')->default('0');
            $table->enum('status', ['Active', 'Inactive']);
            $table->integer('total_sold')->default(0);
            $table->integer('total_favourite')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('products');
    }
};
