<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Add locale support without changing installations that already manage
     * their own users.locale column.
     */
    public function up()
    {
        if (Schema::hasTable('users') && ! Schema::hasColumn('users', 'locale')) {
            Schema::table('users', function (Blueprint $table) {
                $table->string('locale', 5)->nullable()->index()->after('email');
            });
        }
    }

    /**
     * Intentionally no-op: this migration may run against an installation
     * where a locale column predated it, so rollback must not remove it.
     */
    public function down()
    {
        //
    }
};