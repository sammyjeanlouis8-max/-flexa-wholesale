<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('orderdetails', function (Blueprint $table) {
            $table->id();
            $table->integer('user_id');
            $table->string('payment_method');
            $table->string('order_no');
            $table->text('delivery_address');
            $table->string('sub_total');
            $table->string('shipping_cost')->nullable();
            $table->string('tax')->nullable();
            $table->string('tax_percentage')->nullable();
            $table->string('total_cost');
            $table->string('to_receive')->nullable();
            $table->string('to_send')->nullable();
            $table->string('to_pay')->nullable();
            $table->date('date');
            $table->string('time');
            $table->string('month');
            $table->string('year');
            $table->string('status')->default('Pending');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('orderdetails');
    }
};
