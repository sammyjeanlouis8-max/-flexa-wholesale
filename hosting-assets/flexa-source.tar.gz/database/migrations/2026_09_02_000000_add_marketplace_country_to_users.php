<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up()
    {
        if (Schema::hasTable('users') && !Schema::hasColumn('users', 'marketplace_country')) {
            Schema::table('users', function (Blueprint $table) {
                $table->string('marketplace_country', 2)->nullable()->index();
            });
        }
    }

    public function down()
    {
        if (Schema::hasTable('users') && Schema::hasColumn('users', 'marketplace_country')) {
            Schema::table('users', function (Blueprint $table) {
                $table->dropColumn('marketplace_country');
            });
        }
    }
};