@extends('admin_master')
@section('content')
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0">Add Slider</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="{{URL::to('/dashboard')}}">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="{{URL::to('/sliders')}}">All Sliders</a></li>
            <li class="breadcrumb-item active">Add Slider</li>
          </ol>
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div>
  </div>


  <section class="content">
    <div class="card card-primary">
      <div class="card-header">
        <h3 class="card-title">Add Slider</h3>
      </div>
      <!-- /.card-header -->
      <!-- form start -->
      <form action="{{route('sliders.store')}}" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="card-body">
          <div class="row">
            <div class="col-md-12">
              <div class="form-group">
                <label for="title">Title <span class="required">*</span></label>
                <input type="text" name="title" class="form-control" id="title" placeholder="Title"
                  value="{{old('title')}}" required="">
                @error('title')
          <span class="alert alert-danger">{{ $message }}</span>
        @enderror
              </div>
            </div>
            <div class="col-md-12">
              <div class="form-group">
                <label for="src">Image <span class="required">*</span></label>
                <input name="src" type="file" id="image" accept="image/*" class="dropify" data-height="200"
                  required="" />
                @error('src')
          <span class="alert alert-danger">{{ $message }}</span>
        @enderror
              </div>
            </div>
            <div class="col-md-12">
              <div class="form-group">
                <label for="status">Select Status <span class="required">*</span></label>
                <select class="form-control select2bs4" name="status" id="status" required="">
                  <option value="" selected="" disabled="">Select Status</option>
                  <option value="Active">Active</option>
                  <option value="Inactive">Inactive</option>
                </select>
                @error('status')
          <span class="alert alert-danger">{{ $message }}</span>
        @enderror
              </div>
            </div>
          </div>
          <div class="form-group">
            <button type="submit" class="btn btn-primary">Submit</button>
          </div>
        </div>
      </form>
    </div>
    <!-- /.card-body -->
  </section>
</div>
@endsection