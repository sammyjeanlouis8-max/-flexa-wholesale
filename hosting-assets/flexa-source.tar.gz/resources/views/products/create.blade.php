@extends('admin_master')
@section('content')
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Add Product</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="{{URL::to('/dashboard')}}">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="{{URL::to('/products')}}">All Product</a></li>
                        <li class="breadcrumb-item active">Add Product</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <section class="content">
        <div class="card card-primary">
            <div class="card-header">
                <h3 class="card-title">Add Product</h3>
            </div>
            <!-- /.card-header -->
            <!-- form start -->
            <form action="{{route('products.store')}}" method="POST" enctype="multipart/form-data">
                @csrf
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="vendor_id">Select Vendor <span class="required">*</span></label>
                                <select class="form-control select2bs4" name="vendor_id" id="vendor_id">
                                    <option value="" selected="" disabled="">Select Vendor</option>
                                    @foreach(vendors() as $vendor)
                                        <option value="{{$vendor->id}}">{{$vendor->user->name}}</option>
                                    @endforeach
                                </select>
                                @error('vendor_id')
                                    <span class="alert alert-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="product_name">Product Name <span class="required">*</span></label>
                                <input type="text" name="product_name" class="form-control" id="product_name"
                                    placeholder="Product Name" value="{{old('product_name')}}">
                                @error('product_name')
                                    <span class="alert alert-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="category_id">Select Category <span class="required">*</span></label>
                                <select class="form-control select2bs4 product-category" name="category_id" id="category_id">
                                    <option value="" selected="" disabled="">Select Category</option>
                                    @foreach(categories() as $category)
                                        <option value="{{$category->id}}">{{$category->category_name}}</option>
                                    @endforeach
                                </select>
                                @error('category_id')
                                    <span class="alert alert-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>


                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="subcategory_id">Select Subcategory</label>
                                <select class="form-control select2bs4" name="subcategory_id" id="subcategory_id">
                                    <option value="" selected="" disabled="">Select Subcategory</option>

                                </select>
                                @error('subcategory_id')
                                    <span class="alert alert-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>


                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="unit_id">Select Unit <span class="required">*</span></label>
                                <select class="form-control select2bs4" name="unit_id" id="unit_id">
                                    <option value="" selected="" disabled="">Select Unit</option>
                                    @foreach(units() as $unit)
                                        <option value="{{$unit->id}}">{{$unit->unit_name}}</option>
                                    @endforeach
                                </select>
                                @error('unit_id')
                                    <span class="alert alert-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>


                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="product_price">Product Price <span class="required">*</span></label>
                                <input type="" name="product_price" class="form-control numericInput" id="product_price"
                                    placeholder="Product Price" value="{{old('product_price')}}">
                                @error('product_price')
                                    <span class="alert alert-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="discount">Product Discount <span class="required">*</span></label>
                                <input type="text" name="discount" class="form-control numericInput" id="discount"
                                    placeholder="Product Discount" value="{{old('discount')}}">
                                @error('discount')
                                    <span class="alert alert-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>


                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="product_stock">Stock Quantity <span class="required">*</span></label>
                                <input type="text" name="product_stock" class="form-control numericInput"
                                    id="product_stock" placeholder="Stock Quantity" value="{{old('product_stock')}}">
                                @error('product_stock')
                                    <span class="alert alert-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>


                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="low_stock_limit">Stock Limit <span class="required">*</span></label>
                                <input type="text" name="low_stock_limit" class="form-control numericInput"
                                    id="low_stock_limit" placeholder="Stock Limit" value="{{old('low_stock_limit')}}">
                                @error('low_stock_limit')
                                    <span class="alert alert-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <div class="col-md-12">
                            <div class="card card-info">
                                <div class="card-header"><h5>Product Location</h5></div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-4"><div class="form-group"><label for="country">Country <span class="required">*</span></label><select class="form-control select2bs4" name="country" id="country" required><option value="">Select Country</option>@foreach($countries as $code => $name)<option value="{{ $code }}" @selected(old('country') === $code)>{{ $code }} · {{ $name }}</option>@endforeach</select>@error('country')<span class="alert alert-danger">{{ $message }}</span>@enderror</div></div>
                                        <div class="col-md-4"><div class="form-group"><label for="city">City <span class="required">*</span></label><input type="text" name="city" class="form-control" id="city" required value="{{ old('city') }}">@error('city')<span class="alert alert-danger">{{ $message }}</span>@enderror</div></div>
                                        <div class="col-md-4"><div class="form-group"><label for="region">Region/State</label><input type="text" name="region" class="form-control" id="region" value="{{ old('region') }}">@error('region')<span class="alert alert-danger">{{ $message }}</span>@enderror</div></div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        

                        @if(count(variants()) > 0)
                            <div class="col-md-12">
                                <div class="card card-info">
                                    <div class="card-header">
                                        <h5>Add Variant</h5>
                                    </div>

                                    <div class="card-body" id="variantBody">
                                        <div class="row">
                                            <!--@foreach(variants() as $variant)-->
                                            <!--    <div class="col-md-6">-->
                                            <!--        <div class="form-group">-->
                                            <!--            <label for="{{$variant->id}}">{{$variant->variant_name}}</label>-->
                                            <!--            <select class="form-control select2bs4"-->
                                            <!--                name="variants[{{$variant->id}}][values][]" multiple="">-->
                                            <!--                @foreach(variantExplodes($variant->id) as $value)-->
                                            <!--                    <option value="{{$value}}">{{$value}}</option>-->
                                            <!--                @endforeach-->
                                            <!--            </select>-->
                                            <!--            <input type="hidden" name="variants[{{$variant->id}}][name]"-->
                                            <!--                value="{{$variant->variant_name}}">-->
                                            <!--        </div>-->
                                            <!--    </div>-->
                                            <!--@endforeach-->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @endif


<div class="col-md-4">
                            <div class="form-group">
                                <label for="return_available">Return Availablity <span class="required">*</span></label>
                                <select class="form-control select2bs4" name="return_available" id="return_available">
                                    <option value="" selected="" disabled="">Return Availablity</option>
                                    <option value="1">Yes</option>
                                    <option value="0">No</option>
                                </select>
                                @error('return_available')
                                    <span class="alert alert-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="delivery_duration">Delivery Duration <span class="required">*</span></label>
                                <input type="text" name="delivery_duration" class="form-control numericInput"
                                    id="delivery_duration" placeholder="Delivery Duration"
                                    value="{{old('delivery_duration')}}">
                                @error('delivery_duration')
                                    <span class="alert alert-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>


                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="delivery_duration_unit">Delivery Duratiom Unit <span
                                        class="required">*</span></label>
                                <select class="form-control select2bs4" name="delivery_duration_unit"
                                    id="delivery_duration_unit">
                                    <option value="" selected="" disabled="">Delivery Duratiom Unit</option>
                                    <option value="Days">Days</option>
                                    <option value="Weeks">Weeks</option>
                                    <option value="Months">Months</option>
                                    <option value="Year">Year</option>
                                </select>
                                @error('delivery_duration_unit')
                                    <span class="alert alert-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>


                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="warrenty_available">Warrenty Availablity <span
                                        class="required">*</span></label>
                                <select class="form-control select2bs4" name="warrenty_available"
                                    id="warrenty_available">
                                    <option value="" selected="" disabled="">Warrenty Availablity</option>
                                    <option value="1">Yes</option>
                                    <option value="0">No</option>
                                </select>
                                @error('warrenty_available')
                                    <span class="alert alert-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>


                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="status">Select Status <span class="required">*</span></label>
                                <select class="form-control select2bs4" name="status" id="status">
                                    <option value="" selected="" disabled="">Select Status</option>
                                    <option value="Active">Active</option>
                                    <option value="Inactive">Inactive</option>
                                </select>
                                @error('status')
                                    <span class="alert alert-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>


                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="is_featured">Is Featured? <span class="required">*</span></label>
                                <select class="form-control select2bs4" name="is_featured" id="is_featured">
                                    <option value="" selected="" disabled="">Is Featured?</option>
                                    <option value="1">Yes</option>
                                    <option value="0">No</option>
                                </select>
                                @error('is_featured')
                                    <span class="alert alert-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>


                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="top_picks">Top Picks <span class="required">*</span></label>
                                <select class="form-control select2bs4" name="top_picks" id="top_picks">
                                    <option value="" selected="" disabled="">Top Picks</option>
                                    <option value="1">Yes</option>
                                    <option value="0">No</option>
                                </select>
                                @error('top_picks')
                                    <span class="alert alert-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="delivery_charge">Delivery Charge <span class="required">*</span></label>
                                <input type="text" name="delivery_charge" class="form-control numericInput"
                                    id="delivery_charge" placeholder="Delivery Charge"
                                    value="{{old('delivery_charge')}}">
                                @error('delivery_charge')
                                    <span class="alert alert-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="is_delivery_free">Is Delivery Free <span class="required">*</span></label>
                                <select class="form-control select2bs4" name="is_delivery_free" id="is_delivery_free">
                                    <option value="" selected="" disabled="">Is Delivery Free</option>
                                    <option value="1">Yes</option>
                                    <option value="0">No</option>
                                </select>
                                @error('is_delivery_free')
                                    <span class="alert alert-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="short_description">Short Description <span class="required">*</span></label>
                                <input class="form-control"name="short_description" placeholder="Enter short description">
                                @error('short_description')
                                    <span class="alert alert-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="images">Images <span class="required">*</span></label>
                                <input name="images[]" type="file" id="images" accept="image/*" class="form-control"
                                    multiple />
                                @error('images')
                                    <span class="alert alert-danger">{{ $message }}</span>
                                @enderror
                            </div>
                            <div id="image-preview" class="row"></div>
                        </div>
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </div>
            </form>
        </div>
        <!-- /.card-body -->
    </section>
</div>

@endsection