@extends('admin_master')
@section('content')
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Edit Product</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="{{URL::to('/dashboard')}}">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="{{URL::to('/products')}}">All Product</a></li>
                        <li class="breadcrumb-item active">Edit Product</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <section class="content">
        <div class="card card-primary">
            <div class="card-header">
                <h3 class="card-title">Edit Product</h3>
            </div>
            <!-- /.card-header -->
            <!-- form start -->
            <form action="{{ route('products.update', $product->id) }}" method="POST" enctype="multipart/form-data">
                @csrf
                @method('PUT')
                <div class="card-body">
                    <div class="row">
                          <div class="col-md-4">
                            <div class="form-group">
                                <label for="vendor_id">Select Vendor <span class="required">*</span></label>
                                <select class="form-control select2bs4" name="vendor_id" id="vendor_id">
                                    <option value="" selected="" disabled="">Select Vendor</option>
                                    @foreach(vendors() as $vendor)
                                        <option value="{{ $vendor->id }}" {{ $product->vendor_id == $vendor->id ?
                                    'selected' : '' }}>{{ $vendor->user->name }}</option> @endforeach
                                </select>
                                @error('vendor_id')
                                    <span class="alert alert-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="product_name">Product Name <span class="required">*</span></label>
                                <input type="text" name="product_name" class="form-control" id="product_name"
                                    placeholder="Product Name"
                                    value="{{ old('product_name', $product->product_name) }}">
                                @error('product_name')
                                <span class="alert alert-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="category_id">Select Category <span class="required">*</span></label>
                                <select class="form-control select2bs4 product-category" name="category_id" id="category_id">
                                    <option value="" disabled="">Select Category</option>
                                    @foreach(categories() as $category)
                                    <option value="{{ $category->id }}" {{ $product->category_id == $category->id ?
                                        'selected' : '' }}>{{ $category->category_name }}</option>
                                    @endforeach
                                </select>
                                @error('category_id')
                                <span class="alert alert-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="subcategory_id">Select Subcategory</label>
                                <select class="form-control select2bs4" name="subcategory_id" id="subcategory_id"
                                    data-selected="{{ $product->subcategory_id ?? '' }}">
                                    <option value="" disabled="">Select Subcategory</option>
                                    <!-- Populate subcategories if needed -->
                                </select>
                                @error('subcategory_id')
                                <span class="alert alert-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="unit_id">Select Unit <span class="required">*</span></label>
                                <select class="form-control select2bs4" name="unit_id" id="unit_id">
                                    <option value="" disabled="">Select Unit</option>
                                    @foreach(units() as $unit)
                                    <option value="{{ $unit->id }}" {{ $product->unit_id == $unit->id ? 'selected' : ''
                                        }}>{{ $unit->unit_name }}</option>
                                    @endforeach
                                </select>
                                @error('unit_id')
                                <span class="alert alert-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="product_price">Product Price <span class="required">*</span></label>
                                <input type="text" name="product_price" class="form-control numericInput"
                                    id="product_price" placeholder="Product Price"
                                    value="{{ old('product_price', $product->product_price) }}">
                                @error('product_price')
                                <span class="alert alert-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="discount">Product Discount <span class="required">*</span></label>
                                <input type="text" name="discount" class="form-control numericInput" id="discount"
                                    placeholder="Product Discount"
                                    value="{{ old('discount', $product->product_discount) }}">
                                @error('discount')
                                <span class="alert alert-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="product_stock">Stock Quantity <span class="required">*</span></label>
                                <input type="text" name="product_stock" class="form-control numericInput"
                                    id="product_stock" placeholder="Stock Quantity"
                                    value="{{ old('product_stock', $product->product_stock) }}">
                                @error('product_stock')
                                <span class="alert alert-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="low_stock_limit">Stock Limit <span class="required">*</span></label>
                                <input type="text" name="low_stock_limit" class="form-control numericInput"
                                    id="low_stock_limit" placeholder="Stock Limit"
                                    value="{{ old('low_stock_limit', $product->product_stock_limit) }}">
                                @error('low_stock_limit')
                                <span class="alert alert-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <div class="col-md-12">
                            <div class="card card-info">
                                <div class="card-header"><h5>Product Location</h5></div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-4"><div class="form-group"><label for="country">Country <span class="required">*</span></label><select class="form-control select2bs4" name="country" id="country" required><option value="">Select Country</option>@foreach($countries as $code => $name)<option value="{{ $code }}" @selected(old('country', $product->country) === $code)>{{ $code }} · {{ $name }}</option>@endforeach</select>@error('country')<span class="alert alert-danger">{{ $message }}</span>@enderror</div></div>
                                        <div class="col-md-4"><div class="form-group"><label for="city">City <span class="required">*</span></label><input type="text" name="city" class="form-control" id="city" required value="{{ old('city', $product->city) }}">@error('city')<span class="alert alert-danger">{{ $message }}</span>@enderror</div></div>
                                        <div class="col-md-4"><div class="form-group"><label for="region">Region/State</label><input type="text" name="region" class="form-control" id="region" value="{{ old('region', $product->region) }}">@error('region')<span class="alert alert-danger">{{ $message }}</span>@enderror</div></div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        

                        @if(count(variants()) > 0)
                        <div class="col-md-12">
                            <div class="card card-info">
                                <div class="card-header">
                                    <h5>Edit Variant</h5>
                                </div>

                                <div class="card-body" id="variantBody">
                                    <div class="row">
                                    
                                        
                                        <script>
    var product = @json($product ?? null);
        var productVariants = @json($product->variants ?? null);

</script>
                                    </div>
                                </div>



                            </div>
                        </div>
                        @endif
<div class="col-md-4">
                            <div class="form-group">
                                <label for="return_available">Return Availability <span
                                        class="required">*</span></label>
                                <select class="form-control select2bs4" name="return_available" id="return_available">
                                    <option value="" disabled="">Return Availability</option>
                                    <option value="1" {{ $product->return_available ? 'selected' : '' }}>Yes</option>
                                    <option value="0" {{ !$product->return_available ? 'selected' : '' }}>No</option>
                                </select>
                                @error('return_available')
                                <span class="alert alert-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="delivery_duration">Delivery Duration <span class="required">*</span></label>
                                <input type="text" name="delivery_duration" class="form-control numericInput"
                                    id="delivery_duration" placeholder="Delivery Duration"
                                    value="{{ old('delivery_duration', $product->delivery_duration) }}">
                                @error('delivery_duration')
                                <span class="alert alert-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="delivery_duration_unit">Delivery Duration Unit <span
                                        class="required">*</span></label>
                                <select class="form-control select2bs4" name="delivery_duration_unit"
                                    id="delivery_duration_unit">
                                    <option value="" disabled="">Delivery Duration Unit</option>
                                    <option value="Days" {{ old('delivery_duration_unit', $product->
                                        delivery_duration_unit) == 'Days' ? 'selected' : '' }}>Days</option>
                                    <option value="Weeks" {{ old('delivery_duration_unit', $product->
                                        delivery_duration_unit) == 'Weeks' ? 'selected' : '' }}>Weeks</option>
                                    <option value="Months" {{ old('delivery_duration_unit', $product->
                                        delivery_duration_unit) == 'Months' ? 'selected' : '' }}>Months</option>
                                    <option value="Year" {{ old('delivery_duration_unit', $product->
                                        delivery_duration_unit) == 'Year' ? 'selected' : '' }}>Year</option>
                                </select>
                                @error('delivery_duration_unit')
                                <span class="alert alert-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="warrenty_available">Warranty Availability <span
                                        class="required">*</span></label>
                                <select class="form-control select2bs4" name="warrenty_available"
                                    id="warrenty_available">
                                    <option value="" disabled="">Warranty Availability</option>
                                    <option value="1" {{ $product->warrenty_available ? 'selected' : '' }}>Yes</option>
                                    <option value="0" {{ !$product->warrenty_available ? 'selected' : '' }}>No</option>
                                </select>
                                @error('warrenty_available')
                                <span class="alert alert-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="status">Select Status <span class="required">*</span></label>
                                <select class="form-control select2bs4" name="status" id="status">
                                    <option value="" disabled="">Select Status</option>
                                    <option value="Active" {{ $product->status == 'Active' ? 'selected' : '' }}>Active
                                    </option>
                                    <option value="Inactive" {{ $product->status == 'Inactive' ? 'selected' : '' }}>
                                        Inactive</option>
                                </select>
                                @error('status')
                                <span class="alert alert-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="is_featured">Is Featured? <span class="required">*</span></label>
                                <select class="form-control select2bs4" name="is_featured" id="is_featured">
                                    <option value="" disabled="">Is Featured?</option>
                                    <option value="1" {{ $product->is_featured ? 'selected' : '' }}>Yes</option>
                                    <option value="0" {{ !$product->is_featured ? 'selected' : '' }}>No</option>
                                </select>
                                @error('is_featured')
                                <span class="alert alert-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="top_picks">Top Picks <span class="required">*</span></label>
                                <select class="form-control select2bs4" name="top_picks" id="top_picks">
                                    <option value="" disabled="">Top Picks</option>
                                    <option value="1" {{ $product->top_picks ? 'selected' : '' }}>Yes</option>
                                    <option value="0" {{ !$product->top_picks ? 'selected' : '' }}>No</option>
                                </select>
                                @error('top_picks')
                                <span class="alert alert-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="delivery_charge">Delivery Charge <span class="required">*</span></label>
                                <input type="text" name="delivery_charge" class="form-control numericInput"
                                    id="delivery_charge" placeholder="Delivery Charge"
                                    value="{{ old('delivery_charge', $product->delivery_charge) }}">
                                @error('delivery_charge')
                                <span class="alert alert-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="is_delivery_free">Is Delivery Free <span class="required">*</span></label>
                                <select class="form-control select2bs4" name="is_delivery_free" id="is_delivery_free">
                                    <option value="" disabled="">Is Delivery Free</option>
                                    <option value="1" {{ $product->is_delivery_free ? 'selected' : '' }}>Yes</option>
                                    <option value="0" {{ !$product->is_delivery_free ? 'selected' : '' }}>No</option>
                                </select>
                                @error('is_delivery_free')
                                <span class="alert alert-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="short_description">Short Description <span class="required">*</span></label>
                                <input class="form-control" name="short_description" value="{{$product->product_short_description}}"  placeholder="Enter short description">
                                @error('short_description')
                                    <span class="alert alert-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="images">Images <span class="required">*</span></label>
                                <input name="images[]" type="file" id="images" accept="image/*" class="form-control"
                                    multiple />
                                 @error('images')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                        
                                <!-- Display errors for individual files -->
                                @if ($errors->has('images.*'))
                                    @foreach ($errors->get('images.*') as $key => $messages)
                                        @foreach ($messages as $message)
                                            <span class="text-danger">{{ $message }}</span>
                                        @endforeach
                                    @endforeach
                                @endif
                            </div>
                            <div id="image-preview" class="row">
                                @foreach($product->images as $image)
                                <div class="col-md-2 image-preview-container">
                                    <img src="{{ asset($image->src) }}" alt="Image" class="img-thumbnail image-preview">
                                    <button type="button" class="remove-image"
                                        data-image-id="{{ $image->id }}">Remove</button>
                                </div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary">Update</button>
                    </div>
                </div>
            </form>
        </div>
        <!-- /.card-body -->
    </section>
</div>
@endsection