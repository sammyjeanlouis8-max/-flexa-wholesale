<!DOCTYPE html>
<html lang="{{ current_locale() }}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $title }} - Flexa Wo Seller</title>
    <link rel="icon" href="{{ asset('custom/flexa-wo-seller-logo.png') }}" type="image/png">
    <script src="https://cdn.tailwindcss.com"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        brand: {
                            50: '#f0fdfa',
                            100: '#ccfbf1',
                            500: '#14b8a6',
                            600: '#0DA487',
                            700: '#0f766e',
                            900: '#134e4a',
                        }
                    },
                    fontFamily: {
                        sans: ['Inter', 'ui-sans-serif', 'system-ui', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'Roboto', 'Helvetica Neue', 'Arial', 'sans-serif'],
                    }
                }
            }
        }
    </script>
    <style>
        [x-cloak] { display: none !important; }
        .nav-item {
            display: flex;
            align-items: center;
            padding: 0.75rem 1rem;
            border-radius: 0.5rem;
            font-weight: 500;
            transition: all 0.2s;
            margin-bottom: 0.25rem;
        }
        .nav-item.active { background-color: #f0fdfa; color: #0DA487; }
        .nav-item:not(.active):not(.unavailable):hover { background-color: #f3f4f6; color: #111827; }
        .nav-item.unavailable { color: #9ca3af; cursor: not-allowed; }
        .nav-item.unavailable:hover { background-color: transparent; }
    </style>
</head>
<body class="bg-gray-50 text-gray-900 font-sans antialiased" x-data="{ sidebarOpen: false }">

    @php
        $user = Auth::user();
        $isSeller = $user->hasRole('seller');
    @endphp

    <!-- Mobile Sidebar Backdrop -->
    <div x-show="sidebarOpen" x-cloak @click="sidebarOpen = false" class="fixed inset-0 z-20 bg-gray-900 bg-opacity-50 lg:hidden transition-opacity"></div>

    <!-- Sidebar -->
    <aside :class="sidebarOpen ? 'translate-x-0' : '-translate-x-full'" class="fixed inset-y-0 left-0 z-30 w-64 bg-white border-r border-gray-200 transition-transform duration-300 lg:translate-x-0 lg:static lg:inset-0 flex flex-col h-screen">
        <div class="flex items-center justify-between h-16 px-6 border-b border-gray-100">
            <div class="flex items-center gap-2">
                <img src="{{ asset('custom/flexa-wo-seller-logo.png') }}" alt="" aria-hidden="true" class="h-8 w-8 rounded-lg object-cover">
                <span class="text-xl font-bold text-brand-600">Flexa Wo Seller</span>
            </div>
            <button @click="sidebarOpen = false" class="lg:hidden text-gray-500 hover:text-gray-700 focus:outline-none">
                <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
            </button>
        </div>

        <div class="px-4 py-6 flex-1 overflow-y-auto">
            <div class="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-3 px-2">Navigation</div>
            <nav class="space-y-1">
                @if($isSeller)
                    <a href="{{ route('seller.dashboard') }}" class="nav-item active">
                        <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"></path></svg>
                        {{ __('admin.dashboard') }}
                    </a>
                    <a href="{{ url('/') }}" class="nav-item">
                        <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"></path></svg>
                        {{ __('marketplace.marketplace') }}
                    </a>
                    
                    <div class="mt-8 mb-3 px-2 text-xs font-semibold text-gray-400 uppercase tracking-wider">Store Management</div>
                    <div class="nav-item unavailable" title="Feature coming soon">
                        <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"></path></svg>
                         {{ __('marketplace.products') }} <span class="ml-auto text-xs bg-gray-100 text-gray-500 py-0.5 px-2 rounded-full">{{ __('common.coming_soon') }}</span>
                    </div>
                    <div class="nav-item unavailable" title="Feature coming soon">
                        <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01"></path></svg>
                         {{ __('seller.inventory') }} <span class="ml-auto text-xs bg-gray-100 text-gray-500 py-0.5 px-2 rounded-full">{{ __('common.coming_soon') }}</span>
                    </div>
                    <div class="nav-item unavailable" title="Feature coming soon">
                        <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"></path></svg>
                         {{ __('seller.orders') }} <span class="ml-auto text-xs bg-gray-100 text-gray-500 py-0.5 px-2 rounded-full">{{ __('common.coming_soon') }}</span>
                    </div>
                    
                    <div class="mt-8 mb-3 px-2 text-xs font-semibold text-gray-400 uppercase tracking-wider">Finances</div>
                    <div class="nav-item unavailable" title="Feature coming soon">
                        <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"></path></svg>
                        Sales & Earnings <span class="ml-auto text-xs bg-gray-100 text-gray-500 py-0.5 px-2 rounded-full">Soon</span>
                    </div>
                    <div class="nav-item unavailable" title="Feature coming soon">
                        <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>
                        Payouts <span class="ml-auto text-xs bg-gray-100 text-gray-500 py-0.5 px-2 rounded-full">Soon</span>
                    </div>

                    <div class="mt-8 mb-3 px-2 text-xs font-semibold text-gray-400 uppercase tracking-wider">Configuration</div>
                    <div class="nav-item unavailable" title="Feature coming soon">
                        <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
                        Store Settings <span class="ml-auto text-xs bg-gray-100 text-gray-500 py-0.5 px-2 rounded-full">Soon</span>
                    </div>
                @else
                    <a href="{{ route('buyer.dashboard') }}" class="nav-item active">
                        <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"></path></svg>
                        Dashboard
                    </a>
                    <a href="{{ url('/') }}" class="nav-item">
                        <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"></path></svg>
                        Marketplace
                    </a>

                    <div class="mt-8 mb-3 px-2 text-xs font-semibold text-gray-400 uppercase tracking-wider">My Account</div>
                    <div class="nav-item unavailable" title="Feature coming soon">
                        <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"></path></svg>
                        Orders <span class="ml-auto text-xs bg-gray-100 text-gray-500 py-0.5 px-2 rounded-full">Soon</span>
                    </div>
                    <div class="nav-item unavailable" title="Feature coming soon">
                        <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"></path></svg>
                        Messages <span class="ml-auto text-xs bg-gray-100 text-gray-500 py-0.5 px-2 rounded-full">Soon</span>
                    </div>
                    <div class="nav-item unavailable" title="Feature coming soon">
                        <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"></path></svg>
                        Wallet/Payments <span class="ml-auto text-xs bg-gray-100 text-gray-500 py-0.5 px-2 rounded-full">Soon</span>
                    </div>
                    <div class="nav-item unavailable" title="Feature coming soon">
                        <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path></svg>
                        Profile <span class="ml-auto text-xs bg-gray-100 text-gray-500 py-0.5 px-2 rounded-full">Soon</span>
                    </div>
                @endif
            </nav>
        </div>
        
        <div class="border-t border-gray-200 p-4">
            <div class="flex items-center mb-4 px-2">
                <div class="w-8 h-8 rounded-full bg-brand-100 text-brand-700 flex items-center justify-center font-bold text-sm">
                    {{ substr($user->name, 0, 1) }}
                </div>
                <div class="ml-3 truncate">
                    <p class="text-sm font-medium text-gray-900 truncate">{{ $user->name }}</p>
                    <p class="text-xs text-gray-500 truncate">{{ ucfirst($user->role) }}</p>
                </div>
            </div>
            <form action="{{ route('logout', [], false) }}" method="POST">
                @csrf
                <button type="submit" class="flex items-center w-full px-2 py-2 text-sm font-medium text-red-600 rounded-lg hover:bg-red-50 transition-colors">
                    <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path></svg>
                    {{ __('auth.sign_out') }}
                </button>
            </form>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="flex-1 lg:ml-64 min-h-screen flex flex-col">
        <!-- Top header for mobile -->
        <header class="bg-white border-b border-gray-200 h-16 flex items-center justify-between px-4 lg:hidden sticky top-0 z-10">
            <button @click="sidebarOpen = true" class="text-gray-500 hover:text-gray-700 focus:outline-none p-2 -ml-2 rounded-md">
                <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/></svg>
            </button>
            <div class="flex items-center gap-2">
                <img src="{{ asset('custom/flexa-wo-seller-logo.png') }}" alt="" aria-hidden="true" class="h-8 w-8 rounded-lg object-cover">
                <span class="text-lg font-bold text-brand-600">Flexa Wo Seller</span>
            </div>
            <div class="w-8 h-8 rounded-full bg-brand-100 text-brand-700 flex items-center justify-center font-bold text-sm">
                {{ substr($user->name, 0, 1) }}
            </div>
        </header>

        <div class="p-6 lg:p-8 max-w-7xl mx-auto w-full flex-1">
            
            @if (session('messege'))
                <div class="mb-6 p-4 rounded-lg {{ session('alert-type') === 'error' ? 'bg-red-50 border-red-100 text-red-800' : 'bg-green-50 border-green-100 text-green-800' }} border shadow-sm">
                    <p class="text-sm font-medium">{{ session('messege') }}</p>
                </div>
            @endif

            <div class="mb-8">
                <h1 class="text-2xl lg:text-3xl font-bold text-gray-900">{{ $title }}</h1>
                <p class="text-gray-500 mt-1">{{ __('common.welcome_back', ['name' => explode(' ', $user->name)[0]]) }}</p>
            </div>

            <!-- Stats Grid -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-8">
                @foreach($stats as $label => $value)
                    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-6 flex flex-col transition-shadow hover:shadow-md">
                        <span class="text-sm font-medium text-gray-500 mb-1">{{ $label }}</span>
                        <span class="text-3xl font-bold text-gray-900">{{ is_numeric($value) ? number_format($value) : $value }}</span>
                        <div class="mt-4 pt-4 border-t border-gray-50 flex items-center text-sm text-brand-600">
                            <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"></path></svg>
                            {{ __('status.active') }}
                        </div>
                    </div>
                @endforeach
            </div>

            <!-- Dashboard Content Placeholder -->
            <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-8 text-center flex flex-col items-center justify-center min-h-[300px]">
                <div class="w-16 h-16 bg-brand-50 text-brand-500 rounded-full flex items-center justify-center mb-4">
                    <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z"></path></svg>
                </div>
                <h3 class="text-lg font-medium text-gray-900 mb-2">{{ __('dashboard.all_set') }}</h3>
                <p class="text-gray-500 max-w-md mx-auto mb-6">{{ __('dashboard.active_description') }}</p>
                <a href="{{ url('/') }}" class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-brand-600 hover:bg-brand-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-500 transition-colors">
                    {{ __('dashboard.explore_marketplace') }}
                </a>
            </div>
        </div>
    </main>
</body>
</html>
