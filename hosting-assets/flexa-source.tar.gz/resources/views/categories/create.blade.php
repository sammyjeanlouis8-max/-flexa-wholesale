@extends('admin_master')
@section('content')
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0">Add Category</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="{{URL::to('/dashboard')}}">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="{{URL::to('/categories')}}">All Category</a></li>
            <li class="breadcrumb-item active">Add Category</li>
          </ol>
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
  <!-- /.content-header -->

  <section class="content">
    <div class="card card-primary">
      <div class="card-header">
        <h3 class="card-title">Add Category</h3>
      </div>
      <!-- /.card-header -->
      <!-- form start -->
      <form action="{{route('categories.store')}}" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="card-body">
          <div class="row">
            <div class="col-md-12">
              <div class="form-group">
                <label for="category_name">Category Name <span class="required">*</span></label>
                <input type="text" name="category_name" class="form-control" id="category_name" placeholder="Category Name" value="{{old('category_name')}}" required="">
                @error('category_name')
                <span class="alert alert-danger">{{ $message }}</span>
                @enderror
              </div>
            </div>
            <div class="col-md-12">
              <div class="form-group">
                <label for="image">Image <span class="required">*</span></label>
                <input name="image" type="file" id="image" accept="image/*" class="dropify" data-height="200" required="" />
                @error('image')
                <span class="alert alert-danger">{{ $message }}</span>
                @enderror
              </div>
            </div>
            <div class="col-md-12">
              <div class="form-group">
                <label for="status">Select Status <span class="required">*</span></label>
                <select class="form-control select2bs4" name="status" id="status" required="">
                  <option value="" selected="" disabled="">Select Status</option>
                  <option value="Active">Active</option>
                  <option value="Inactive">Inactive</option>
                </select>
                @error('status')
                <span class="alert alert-danger">{{ $message }}</span>
                @enderror
              </div>
            </div>
          </div>
          <div class="form-group">
            <button type="submit" class="btn btn-primary">Submit</button>
          </div>
        </div>
      </form>
    </div>
    <!-- /.card-body -->
  </section>
</div>
@endsection