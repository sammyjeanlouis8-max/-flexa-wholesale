@extends('admin_master')
@section('content')
 <div class="content-wrapper">
   <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Mail Settings</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="{{URL::to('/dashboard')}}">Dashboard</a></li>
              <li class="breadcrumb-item active">Mail Settings</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <section class="content"> 
    	<div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Mail Settings</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form action="{{URL::to('settings-mail')}}" method="POST" enctype="multipart/form-data">
              	@csrf
                <div class="card-body">
                  <div class="form-group">
                    <label for="email">Web Email <span class="required">*</span></label>
                    <input type="text" name="email" class="form-control" id="email" placeholder="Name" value="{{mailData()->email??''}}" required="">
             
                  </div>

                  <div class="form-group">
                  	<label for="mail_host">Mail Host <span class="required">*</span></label>
                  	<input type="text" name="mail_host" class="form-control" id="mail_host" placeholder="Mail Host" value="{{mailData()->mail_host??''}}" required="">
                  </div>


                  <div class="form-group">
                  	<label for="mail_port">Mail Port <span class="required">*</span></label>
                  	<input type="number" name="mail_port" class="form-control" id="mail_port" placeholder="Mail Port" value="{{mailData()->mail_port??''}}" required="">
                  </div>


                  <div class="form-group">
                  	<label for="mail_encryption">Mail Encryption <span class="required">*</span></label>
                  	<input type="text" name="mail_encryption" class="form-control" id="mail_encryption" placeholder="Mail Encryption" value="{{mailData()->mail_encryption??''}}" required="">
                  </div>


                  <div class="form-group">
                    <label for="password">Email Password <span class="required">*</span></label>
                    <input type="password" name="password" class="form-control" id="password" placeholder="Email Password" value="{{mailData()->password??''}}" required="">
             
                  </div>


                  <div class="form-group">
                      <button type="submit" class="btn btn-success">Update</button>
                   </div>

                  
                </div>
                <!-- /.card-body -->

                
              </form>
            </div>
    </section>
 </div>
@endsection