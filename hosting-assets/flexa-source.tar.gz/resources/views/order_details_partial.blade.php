<div>
    <p><strong>Order Number:</strong> {{ $order->order_no }}</p>
    <p><strong>Customer Name:</strong> {{ $order->user->name ?? 'n/a' }}</p>
    <p><strong>Date:</strong> {{ $order->date }}</p>
    <p><strong>Total Cost:</strong> {{ $order->total_cost }}</p>
    <p><strong>Payment Method:</strong> {{ $order->payment_method }}</p>
    <p><strong>Status:</strong> {{ $order->status }}</p>
    <h3>products</h3>
    <hr>
    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>sl.</th>
                <th>Product name</th>
                <th>Vendor name</th>
                <th>Quantity</th>
                <th>Unit Price</th>
                <th>Total Price</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($order->orders as $key => $orderq)
                <tr>
                    <td>{{$key+1}}</td>
                    <td>{{$orderq->product->product_name}}</td>
                    <td>{{$orderq->vendor->user->name}}</td>
                    <td>{{$orderq->product_quantity}}</td>
                    <td>{{$orderq->product_price}}</td>
                    <td>{{$orderq->unit_total_price}}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
    <!-- Add more order details as needed -->
</div>