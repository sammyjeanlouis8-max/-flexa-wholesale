@extends('admin_master')

@section('content')
<div class="content-wrapper">
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Admin Management</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="{{ URL::to('/dashboard') }}">Dashboard</a></li>
                        <li class="breadcrumb-item active">Admin Management</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <section class="content">
        <div class="container-fluid">
            @if ($errors->any())
                <div class="alert alert-danger" style="background:#f8d7da !important; color:#721c24 !important; border:1px solid #f5c6cb !important;">
                    <ul class="mb-0">
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <div class="row">
                <!-- Left Column: Forms -->
                <div class="col-lg-5">

                    <!-- Create Admin Form -->
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">Add New Admin</h3>
                        </div>
                        <form action="{{ route('admin-management.store') }}" method="POST">
                            @csrf
                            <div class="card-body">
                                <div class="form-group">
                                    <label for="name">Name <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="name" name="name" value="{{ old('name') }}" required>
                                </div>
                                <div class="form-group">
                                    <label for="email">Email <span class="text-danger">*</span></label>
                                    <input type="email" class="form-control" id="email" name="email" value="{{ old('email') }}" autocomplete="username" required>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 form-group">
                                        <label for="password">Password <span class="text-danger">*</span></label>
                                        <input type="password" class="form-control" id="password" name="password" autocomplete="new-password" required>
                                    </div>
                                    <div class="col-md-6 form-group">
                                        <label for="password_confirmation">Confirm Password <span class="text-danger">*</span></label>
                                        <input type="password" class="form-control" id="password_confirmation" name="password_confirmation" autocomplete="new-password" required>
                                    </div>
                                </div>

                                <div class="form-group mt-2">
                                    <label>Assign Permissions</label>
                                    <div class="p-3 border rounded bg-light">
                                        <div class="row">
                                            @foreach($permissions as $perm)
                                            <div class="col-md-6 mb-2">
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="perm_{{ $perm->id }}" name="permissions[]" value="{{ $perm->id }}">
                                                    <label class="custom-control-label font-weight-normal" for="perm_{{ $perm->id }}">{{ $perm->name }}</label>
                                                </div>
                                            </div>
                                            @endforeach
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card-footer">
                                <button type="submit" class="btn btn-primary">Create Admin</button>
                            </div>
                        </form>
                    </div>

                    <!-- Promote User Form -->
                    <div class="card card-info mt-4">
                        <div class="card-header">
                            <h3 class="card-title">Promote Existing User</h3>
                        </div>
                        <form action="{{ route('admin-management.promote') }}" method="POST">
                            @csrf
                            <div class="card-body">
                                <div class="form-group">
                                    <label for="user_id">Select User <span class="text-danger">*</span></label>
                                    <select class="form-control select2" id="user_id" name="user_id" required>
                                        <option value="">-- Choose User --</option>
                                        @foreach($eligibleUsers as $user)
                                            <option value="{{ $user->id }}">{{ $user->name }} ({{ $user->email }} - {{ ucfirst($user->role) }})</option>
                                        @endforeach
                                    </select>
                                </div>

                                <div class="form-group mt-2">
                                    <label>Assign Permissions</label>
                                    <div class="p-3 border rounded bg-light">
                                        <div class="row">
                                            @foreach($permissions as $perm)
                                            <div class="col-md-6 mb-2">
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="prom_perm_{{ $perm->id }}" name="permissions[]" value="{{ $perm->id }}">
                                                    <label class="custom-control-label font-weight-normal" for="prom_perm_{{ $perm->id }}">{{ $perm->name }}</label>
                                                </div>
                                            </div>
                                            @endforeach
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card-footer">
                                <button type="submit" class="btn btn-info">Promote to Admin</button>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Right Column: List -->
                <div class="col-lg-7">
                    <div class="card">
                        <div class="card-header border-transparent">
                            <h3 class="card-title">Admin Accounts</h3>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table m-0 table-hover">
                                    <thead>
                                        <tr>
                                            <th class="text-left">Admin Info</th>
                                            <th class="text-left">Role & Access</th>
                                            <th class="text-center">Status</th>
                                            <th class="text-right">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @forelse ($admins as $admin)
                                            <tr>
                                                <td class="text-left">
                                                    <strong>{{ $admin->name }}</strong><br>
                                                    <small class="text-muted">{{ $admin->email }}</small>
                                                </td>
                                                <td class="text-left">
                                                    @if ($admin->is_primary_admin)
                                                        <span class="badge badge-primary mb-1">Primary Owner</span><br>
                                                        <small class="text-muted">Full Access</small>
                                                    @else
                                                        <span class="badge badge-secondary mb-1">Admin</span><br>
                                                        <small class="text-muted" title="{{ $admin->permissions->pluck('name')->implode(', ') }}">
                                                            {{ $admin->permissions->count() }} permission(s)
                                                        </small>
                                                    @endif
                                                </td>
                                                <td class="text-center">
                                                    @php $status = strtolower($admin->account_status ?? $admin->status ?? 'active'); @endphp
                                                    @if($status === 'active')
                                                        <span class="badge badge-success">Active</span>
                                                    @else
                                                        <span class="badge badge-danger">Inactive</span>
                                                    @endif
                                                </td>
                                                <td class="text-right">
                                                    @if (!$admin->is_primary_admin && $admin->id != Auth::id())
                                                        <button type="button" class="btn btn-sm btn-outline-primary mr-1" data-toggle="modal" data-target="#editAdminModal{{ $admin->id }}">
                                                            {{ __('common.edit') }}
                                                        </button>
                                                        <form action="{{ route('admin-management.demote', $admin) }}" method="POST" class="d-inline-block">
                                                            @csrf
                                                            @method('PATCH')
                                                            <button type="submit" class="btn btn-sm btn-outline-warning">{{ __('admin.demote') }}</button>
                                                        </form>
                                                        @if($status === 'active')
                                                            <form action="{{ route('admin-management.suspend', $admin) }}" method="POST" class="d-inline-block">
                                                                @csrf @method('PATCH')
                                                                <button type="submit" class="btn btn-sm btn-outline-danger">{{ __('admin.suspend') }}</button>
                                                            </form>
                                                        @else
                                                            <form action="{{ route('admin-management.restore', $admin) }}" method="POST" class="d-inline-block">
                                                                @csrf @method('PATCH')
                                                                <button type="submit" class="btn btn-sm btn-outline-success">{{ __('admin.restore') }}</button>
                                                            </form>
                                                        @endif
                                                    @else
                                                        <span class="text-muted small border px-2 py-1 rounded bg-light">Protected</span>
                                                    @endif
                                                </td>
                                            </tr>

                                            @if (!$admin->is_primary_admin && $admin->id != Auth::id())
                                            <!-- Edit Modal for {{ $admin->name }} -->
                                            <div class="modal fade" id="editAdminModal{{ $admin->id }}" tabindex="-1" role="dialog" aria-hidden="true" style="text-align: left;">
                                                <div class="modal-dialog" role="document">
                                                    <form action="{{ route('admin-management.update', $admin) }}" method="POST">
                                                        @csrf
                                                        @method('PUT')
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title">Edit Admin: {{ $admin->name }}</h5>
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <div class="form-group">
                                                                    <label>Account Status</label>
                                                                    <select class="form-control" name="account_status" required>
                                                                        <option value="active" {{ $status === 'active' ? 'selected' : '' }}>Active</option>
                                                                        <option value="inactive" {{ $status === 'inactive' ? 'selected' : '' }}>Inactive (Revoke Access)</option>
                                                                    </select>
                                                                </div>
                                                                <div class="form-group mt-3">
                                                                    <label>Update Permissions</label>
                                                                    <div class="p-3 border rounded bg-light">
                                                                        <div class="row">
                                                                            @foreach($permissions as $perm)
                                                                            <div class="col-md-6 mb-2">
                                                                                <div class="custom-control custom-checkbox">
                                                                                    <input type="checkbox" class="custom-control-input" id="edit_perm_{{ $admin->id }}_{{ $perm->id }}" name="permissions[]" value="{{ $perm->id }}" {{ $admin->permissions->contains('id', $perm->id) ? 'checked' : '' }}>
                                                                                    <label class="custom-control-label font-weight-normal" for="edit_perm_{{ $admin->id }}_{{ $perm->id }}">{{ $perm->name }}</label>
                                                                                </div>
                                                                            </div>
                                                                            @endforeach
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                                                <button type="submit" class="btn btn-primary">Save Changes</button>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                            @endif

                                        @empty
                                            <tr>
                                                <td colspan="4" class="text-center py-4 text-muted">No admin accounts found.</td>
                                            </tr>
                                        @endforelse
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
@if(isset($activityLogs) && $activityLogs->isNotEmpty())
<div class="content-wrapper"><section class="content"><div class="container-fluid"><div class="card"><div class="card-header"><h3 class="card-title">{{ __('admin.recent_activity') }}</h3></div><div class="card-body p-0"><ul class="list-group list-group-flush">@foreach($activityLogs as $activity)<li class="list-group-item"><strong>{{ $activity->action }}</strong> <span class="text-muted">{{ $activity->created_at?->diffForHumans() }}</span></li>@endforeach</ul></div></div></div></section></div>
@endif
@endsection