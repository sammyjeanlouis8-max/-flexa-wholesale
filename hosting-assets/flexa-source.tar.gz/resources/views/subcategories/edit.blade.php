@extends('admin_master')
@section('content')
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0">Edit Subcategory</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="{{URL::to('/dashboard')}}">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="{{URL::to('/subcategories')}}">All Subcategory</a></li>
            <li class="breadcrumb-item active">Edit Subcategory</li>
          </ol>
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
  <!-- /.content-header -->

  <section class="content">
    <div class="card card-primary">
      <div class="card-header">
        <h3 class="card-title">Edit Subcategory</h3>
      </div>
      <!-- /.card-header -->
      <!-- form start -->
      <form action="{{route('subcategories.update',$subcategory->id)}}" method="POST" enctype="multipart/form-data">
        @csrf
        @method('PATCH')
        <div class="card-body">
          <div class="row">
            <div class="col-md-12">
              <div class="form-group">
                <label for="subcategory_name">Subcategory Name <span class="required">*</span></label>
                <input type="text" name="subcategory_name" class="form-control" id="subcategory_name" placeholder="Subcategory Name" value="{{old('subcategory_name',$subcategory->subcategory_name)}}" required="">
                @error('subcategory_name')
                <span class="alert alert-danger">{{ $message }}</span>
                @enderror
              </div>
            </div>


            <div class="col-md-12">
              <div class="form-group">
                <label for="category_id">Select Category <span class="required">*</span></label>
                <select class="form-control select2bs4" id="category_id" name="category_id" required="">
                  <option value="" selected="" disabled="">Select Category</option>
                  @foreach(categories() as $category)
                   <option value="{{$category->id}}" <?php if($subcategory->category_id == $category->id){echo "selected";} ?>>{{$category->category_name}}</option>
                  @endforeach
                </select>
                @error('category_id')
                <span class="alert alert-danger">{{ $message }}</span>
                @enderror
              </div>
            </div>

            <div class="col-md-12">
              <div class="form-group">
                <label for="image">Image <span class="required">*</span></label>
                <input name="image" type="file" id="image" accept="image/*" class="dropify" data-height="200" data-default-file="{{URL::to($subcategory->image)}}" /> 
                @error('image')
                <span class="alert alert-danger">{{ $message }}</span>
                @enderror
              </div>
            </div>
            <div class="col-md-12">
              <div class="form-group">
                <label for="status">Select Status <span class="required">*</span></label>
                <select class="form-control select2bs4" name="status" id="status" required="">
                  <option value="" selected="" disabled="">Select Status</option>
                  <option value="Active" <?php if($subcategory->status == 'Active'){echo "selected";} ?>>Active</option>
                  <option value="Inactive" <?php if($subcategory->status == 'Inactive'){echo "selected";} ?>>Inactive</option>
                </select>
                @error('status')
                <span class="alert alert-danger">{{ $message }}</span>
                @enderror
              </div>
            </div>
          </div>
          <div class="form-group">
            <button type="submit" class="btn btn-success">Update</button>
          </div>
        </div>
      </form>
    </div>
    <!-- /.card-body -->
  </section>
</div>
@endsection