@extends('admin_master')
@section('content')

<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0">All Subcategories</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="{{URL::to('/dashboard')}}">Dashboard</a></li>
            <li class="breadcrumb-item active">All Subcategories</li>
          </ol>
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
  <!-- /.content-header -->

  <section class="content">
    <div class="card">
      <div class="card-header">
        <h3 class="card-title">All Subcategories</h3>
      </div>
      <!-- /.card-header -->
      <div class="card-body">
        <a href="{{route('subcategories.create')}}" class="btn btn-primary add-new mb-2">Add New</a><br><br>

        <div class="card">
          <div class="card-body">
            <div class="row">
              <div class="col-md-6">
                <div class="form-group">
                  <label for="selected_category_id">Select Category</label>
                  <select class="form-control select2bs4" id="selected_category_id">
                    <option value="" selected="" disabled="">Select Category</option>
                    @foreach(categories() as $category)
            <option value="{{$category->id}}">{{$category->category_name}}</option>
          @endforeach
                  </select>
                </div>
              </div>

              <div class="col-md-6">
                <div class="form-group">
                  <label for="filter-status"><strong>Filter by status :</strong></label>
                  <select id="filter-status" class="form-control select2bs4">
                    <option value="" disabled="" selected="">Select Status</option>
                    <option value="Active">Active</option>
                    <option value="Inactive">Inactive</option>
                  </select>
                </div>
              </div>
              <div class="col-md-12">
                <div class="form-group">
                  <button type="button" class="btn btn-primary btn-block filter-subcategory"><i
                      class="fa fa-search"></i>
                    Search</button>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="fetch-data table-responsive">
          <table id="subcategory-table" class="table table-bordered table-striped data-table">
            <thead>
              <tr>
                <th>Image</th>
                <th>Subcategory Name</th>
                <th>Category</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody class="conts">
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </section>
</div>
@endsection