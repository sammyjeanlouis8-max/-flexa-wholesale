<!DOCTYPE html>
<html lang="{{ current_locale() }}">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{{setting()->app_name}}</title>
    <link rel="icon" href="{{asset(setting()->app_logo)}}" type="image/x-icon">

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="{{asset('back/plugins/fontawesome-free/css/all.min.css')}}">
  <!-- icheck bootstrap -->
  <link rel="stylesheet" href="{{asset('back/plugins/icheck-bootstrap/icheck-bootstrap.min.css')}}">
  <!-- Theme style -->
  <link rel="stylesheet" href="{{asset('back/dist/css/adminlte.min.css')}}">

  <link rel="stylesheet" href="{{asset('custom/toastr.css')}}">
</head>
<body class="hold-transition login-page" style="background-color:#F8FFFAFF !important">
<div class="login-box" >
  
  <!-- /.login-logo -->
  <div class="card"style="background-color:#0DA487FF !important" >
      <div class="login-logo mt-4">
    <img src="{{ asset('custom/flexa-wo-seller-logo.png') }}" alt="" aria-hidden="true" style="width:72px;height:72px;object-fit:cover;border-radius:16px">
    <a href="{{URL::to('/')}}"><strong class="text-white">{{setting()->app_name}} Admin Panel</strong></a>
  </div>
    <div class="card-body login-card-body" style="background-color:#0DA487FF !important">
      <p class="login-box-msg text-white">Sign in to your account</p>

      <form action="{{URL::to('admin-login')}}" method="post">
       @csrf
        <div class="input-group mb-3">
          <input type="email" name="email" class="form-control" placeholder="Email" autocomplete="username" required="">
          <div class="input-group-append bg-white">
            <div class="input-group-text">
              <span class="fas fa-envelope" style="color:#0DA487FF"></span>
            </div>
          </div>
        </div>
        <div class="input-group mb-3">
          <input type="password" name="password" class="form-control" placeholder="Password" autocomplete="current-password" required="">
          <div class="input-group-append bg-white">
            <div class="input-group-text">
              <span class="fas fa-lock" style="color:#0DA487FF"></span>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-8">
            <!--<div class="icheck-primary">-->
            <!--  <input type="checkbox" id="remember">-->
            <!--  <label for="remember">-->
            <!--    Remember Me-->
            <!--  </label>-->
            <!--</div>-->
          </div>
          <!-- /.col -->
          <div class="col-4">
            <button type="submit" class="btn btn-primary btn-block">Sign In</button>
          </div>
          <!-- /.col -->
        </div>
      </form>

    </div>
    <!-- /.login-card-body -->
  </div>
</div>
<!-- /.login-box -->

<!-- jQuery -->
<script src="{{asset('back/plugins/jquery/jquery.min.js')}}"></script>
<!-- Bootstrap 4 -->
<script src="{{asset('back/plugins/bootstrap/js/bootstrap.bundle.min.js')}}"></script>
<script src="{{asset('back/dist/js/adminlte.min.js')}}"></script>

<script src="{{asset('custom/toastr.js')}}"></script>
 
  @if(Session::has('messege'))
    @toastr("{{ Session::get('messege') }}")
  @endif

</body>
</html>
