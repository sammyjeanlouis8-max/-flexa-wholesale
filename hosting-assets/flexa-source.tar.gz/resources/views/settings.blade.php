@extends('admin_master')
@section('content')
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">General Settings</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="{{URL::to('/dashboard')}}">Dashboard</a></li>
                        <li class="breadcrumb-item active">General Settings</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <section class="content">
        <div class="card card-primary">
            <div class="card-header">
                <h3 class="card-title">General Settings</h3>
            </div>
            <!-- /.card-header -->
            <!-- form start -->
            <form action="{{URL::to('update-settings')}}" method="POST" enctype="multipart/form-data">
                @csrf
                <div class="card-body">
                    @if(auth()->user()->role_id == 1)
                        <div class="row">
                            <div class="col-12 mt-3">
                                <h2>App Settings</h2>
                                <hr>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="app_name">App Name</label>
                                    <input type="text" name="app_name" class="form-control"
                                        id="app_name" placeholder="App name"
                                        value="{{ old('tax', $settings->app_name) }}">
                                    @error('app_name')
                                        <span class="alert alert-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="currency">Currency</label>
                                    <input type="text" name="currency" class="form-control" id="currency"
                                        placeholder="currency" value="{{ old('currency', $settings->currency) }}">
                                    @error('currency')
                                        <span class="alert alert-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="currecny_code">Currency Code</label>
                                    <input type="text" name="currecny_code" class="form-control" id="currecny_code"
                                        placeholder="Currency Code"
                                        value="{{ old('currecny_code', $settings->currency_code) }}">
                                    @error('currecny_code')
                                        <span class="alert alert-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="currency_symbol">Currency Symbol</label>
                                    <input type="text" name="currency_symbol" class="form-control" id="currency_symbol"
                                        placeholder="Currency Symbol"
                                        value="{{ old('currency_symbol', $settings->currency_symbol) }}">
                                    @error('currency_symbol')
                                        <span class="alert alert-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="tax">TAX</label>
                                    <input type="number" name="tax" class="form-control" id="tax" placeholder="Tax"
                                        value="{{ old('tax', $settings->tax) }}">
                                    @error('tax')
                                        <span class="alert alert-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="contact_email">Support Email</label>
                                    <input type="email" name="contact_email" class="form-control" id="contact_email"
                                        placeholder="Support Email"
                                        value="{{ old('contact_email', $settings->contact_email) }}">
                                    @error('contact_email')
                                        <span class="alert alert-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="withdraw_charge">Withdraw Charge</label>
                                    <input type="number" name="withdraw_charge" class="form-control" id="withdraw_charge" placeholder="Withdraw Charge"
                                        value="{{ old('withdraw_charge', $settings->withdraw_charge) }}">
                                    @error('withdraw_charge')
                                        <span class="alert alert-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="contact_phone_first">Support Mobile</label>
                                    <input type="number" name="contact_phone_first" class="form-control"
                                        id="contact_phone_first" placeholder="Support Mobile"
                                        value="{{ old('contact_phone_first', $settings->contact_phone_first) }}">
                                    @error('contact_phone_first')
                                        <span class="alert alert-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="contact_phone_second">Support Mobile Alternative</label>
                                    <input type="number" name="contact_phone_second" class="form-control"
                                        id="contact_phone_second" placeholder="Support Mobile Alternative"
                                        value="{{ old('tax', $settings->contact_phone_second) }}">
                                    @error('contact_phone_second')
                                        <span class="alert alert-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-12">
                                @if($settings->app_logo == NULL)
                                    <label for="image">App Logo <span class="required">*</span></label>
                                    <input name="app_logo" type="file" id="image" class="dropify" data-height="200"
                                        accept="image/*" />
    
                                    @error('app_logo')
                                        <span class="alert alert-danger">{{ $message }}</span>
                                    @enderror
                                @else
    
                                    <div class="form-group">
                                        <label for="image"> App Logo  <span class="required">*</span></label>
                                        <input name="app_logo" type="file" id="image" class="dropify" data-height="200"
                                            accept="image/*" data-default-file="{{URL::to($settings->app_logo)}}" />
    
                                        @error('app_logo')
                                            <span class="alert alert-danger">{{ $message }}</span>
                                        @enderror
    
                                    </div>
                                @endif
                            </div>

                        </div>
                        <div class="row">
                            <div class="col-12">
                                <h2>Payment method Settings</h2>
                                <hr>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12">
                                <h4>Razor Pay</h4>
                                <hr>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="razor_key">Key</label>
                                    <input type="text" name="razor_key" class="form-control" id="razor_key"
                                        placeholder="Razor pay key"
                                        value="{{ old('razor_key', $paymentMethods->razor_key ?? '') }}">
                                    @error('razor_key')
                                        <span class="alert alert-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12">
                                <h4>Stripe</h4>
                                <hr>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="stripe_publish_key">Publish Key</label>
                                    <input type="text" name="stripe_publish_key" class="form-control"
                                        id="stripe_publish_key" placeholder="Stripe Publish key"
                                        value="{{ old('stripe_publish_key', $paymentMethods->stripe_publish_key ?? '') }}">
                                    @error('stripe_publish_key')
                                        <span class="alert alert-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="stripe_secret_key">Secret Key</label>
                                    <input type="text" name="stripe_secret_key" class="form-control" id="stripe_secret_key"
                                        placeholder="Stripe Secret key"
                                        value="{{ old('stripe_secret_key', $paymentMethods->stripe_secret_key ?? '') }}">
                                    @error('stripe_secret_key')
                                        <span class="alert alert-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                        </div>
                    @endif











                    <div class="form-group">
                        <button type="submit" class="btn btn-success">Update</button>
                    </div>


                </div>
                <!-- /.card-body -->
            </form>
        </div>
    </section>
</div>
@endsection