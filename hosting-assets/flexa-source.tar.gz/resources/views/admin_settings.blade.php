@extends('admin_master')

@section('content')
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Admin Settings</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="{{ URL::to('/dashboard') }}">Dashboard</a></li>
                        <li class="breadcrumb-item active">Admin Settings</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <section class="content">
        <div class="card card-primary">
            <div class="card-header">
                <h3 class="card-title">Update Profile</h3>
            </div>
            <!-- /.card-header -->
            <!-- form start -->
            <form action="{{ URL::to('update-admin-profile') }}" method="POST" enctype="multipart/form-data">
                @csrf
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="name">Admin Name</label>
                                <input type="text" name="name" class="form-control" id="name" placeholder="Name"
                                    value="{{ old('name', Auth::user()->name) }}">
                                @error('name')
                                    <span class="alert alert-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="email">Admin Email</label>
                                <input type="email" name="email" class="form-control" id="email" placeholder="Email"
                                    value="{{ old('email', Auth::user()->email) }}" readonly>
                                @error('email')
                                    <span class="alert alert-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-group">
                                <label for="image">Admin Profile Image</label>
                                <input name="image" type="file" id="image" class="dropify" data-height="200"
                                    accept="image/*" data-default-file="{{ URL::to(Auth::user()->image) }}" />
                                @error('image')
                                    <span class="alert alert-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <button type="submit" class="btn btn-success">Update Profile</button>
                    </div>
                </div>
                <!-- /.card-body -->
            </form>
        </div>

        <div class="card card-secondary mt-4">
            <div class="card-header">
                <h3 class="card-title">Change Password</h3>
            </div>
            <!-- /.card-header -->
            <!-- form start -->
            <form action="{{ URL::to('update-admin-password') }}" method="POST">
                @csrf
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="current_password">Current Password</label>
                                <input type="password" name="current_password" class="form-control" id="current_password"
                                    placeholder="Current Password">
                                @error('current_password')
                                    <span class="alert alert-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>
                       <!-- New Password -->
     <div class="col-md-6"> <div class="form-group">
        <label for="new_password">New Password</label>
        <input type="password" name="new_password" class="form-control" id="new_password" placeholder="New Password">
        @error('new_password')
            <span class="alert alert-danger">{{ $message }}</span>
        @enderror
    </div>
 </div>
    <!-- Confirm New Password -->
     <div class="col-md-6"> <div class="form-group">
        <label for="new_password_confirmation">Confirm New Password</label>
        <input type="password" name="new_password_confirmation" class="form-control" id="new_password_confirmation" placeholder="Confirm New Password">
        @error('new_password_confirmation')
            <span class="alert alert-danger">{{ $message }}</span>
        @enderror
    </div></div>
                    </div>

                    <div class="form-group">
                        <button type="submit" class="btn btn-success">Change Password</button>
                    </div>
                </div>
                <!-- /.card-body -->
            </form>
        </div>
    </section>
</div>
@endsection
