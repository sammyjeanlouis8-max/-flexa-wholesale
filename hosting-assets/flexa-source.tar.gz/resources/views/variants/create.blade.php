@extends('admin_master')
@section('content')
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0">Add Variant</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="{{URL::to('/dashboard')}}">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="{{URL::to('/variants')}}">All Variants</a></li>
            <li class="breadcrumb-item active">Add Variant</li>
          </ol>
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
  <!-- /.content-header -->

  <section class="content">
    <div class="card card-primary">
      <div class="card-header">
        <h3 class="card-title">Add Variant</h3>
      </div>
      <!-- /.card-header -->
      <!-- form start -->
      <form action="{{route('variants.store')}}" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="card-body">
          <div class="row">
              <div class="col-md-12">
              <div class="form-group">
                <label for="category_id">Select Category <span class="required">*</span></label>
                <select class="form-control select2bs4" id="category_id" name="category_id" required="">
                  <option value="" selected="" disabled="">Select Category</option>
                  @foreach(categories() as $category)
            <option value="{{$category->id}}">{{$category->category_name}}</option>
          @endforeach
                </select>
                @error('category_id')
          <span class="alert alert-danger">{{ $message }}</span>
        @enderror
              </div>
            </div>
            <div class="col-md-12">
              <div class="form-group">
                <label for="variant_name">Variant Name <span class="required">*</span></label>
                <input type="text" name="variant_name" class="form-control" id="variant_name" placeholder="Variant Name" value="{{old('variant_name')}}" data-role="tagsinput" required="">
                @error('variant_name')
                <span class="alert alert-danger">{{ $message }}</span>
                @enderror
              </div>
            </div>
            
            <div class="col-md-12">
              <div class="form-group">
                <label for="variant_value">Variant Value <span class="required">*</span></label>
                <select class="js-example-basic-single" multiple name="variant_value[]" required=""></select>
                @error('variant_value')
                <span class="alert alert-danger">{{ $message }}</span>
                @enderror
              </div>
            </div>

          <div class="form-group">
            <button type="submit" class="btn btn-primary">Submit</button>
          </div>
        </div>
      </form>
    </div>
    <!-- /.card-body -->
  </section>
</div>
@endsection