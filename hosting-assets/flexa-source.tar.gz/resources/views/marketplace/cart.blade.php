@extends('marketplace.layout')
@section('title', __('ui.your_cart'))
@section('content')
<section class="page-head"><p class="eyebrow">{{ __('ui.shopping_bag') }}</p><h1>{{ __('ui.your_cart') }}</h1><p>{{ __('marketplace.checkout_country') }}: <strong>{{ \App\Support\MarketplaceCountry::details($marketplaceCountry)['flag'] ?? '' }} {{ marketplace_countries()[$marketplaceCountry] ?? $marketplaceCountry }}</strong></p></section>
@if($cart && $cart->items->isNotEmpty())
    <section class="panel">
        @php($total=0) @php($hasUnavailable=false)
        @foreach($cart->items as $item)
            @php($unitPrice=$item->product->priceForQuantity($item->quantity)) @php($line=$unitPrice * $item->quantity) @php($total += $line) @php($available=$item->product->isAvailableIn($marketplaceCountry)) @if(!$available) @php($hasUnavailable=true) @endif
            <div class="order-row {{ !$available ? 'unavailable-row' : '' }}"><span><strong>{{ $item->product->product_name }}</strong><small>{{ number_format($unitPrice,2) }} {{ __('ui.each') }} · {{ __('marketplace.minimum_order_short', ['count' => $item->product->minimum_order_quantity, 'unit' => __('seller.unit_'.$item->product->wholesale_unit_type)]) }}</small>@unless($available)<small class="error">{{ __('marketplace.not_available_country') }}</small>@endunless</span><form action="{{ route('marketplace.cart.update',$item) }}" method="post">@csrf @method('patch')<label class="sr-only" for="qty-{{ $item->id }}">{{ __('marketplace.quantity') }}</label><input id="qty-{{ $item->id }}" name="quantity" type="number" min="{{ $item->product->minimum_order_quantity }}" max="{{ $item->product->product_stock }}" value="{{ $item->quantity }}"><button class="button secondary" {{ !$available ? 'disabled':'' }}>{{ __('ui.update') }}</button></form><span><strong>{{ number_format($line,2) }}</strong><form action="{{ route('marketplace.cart.remove',$item) }}" method="post">@csrf @method('delete')<button class="text-link">{{ __('common.remove') }}</button></form></span></div>
        @endforeach
        <div class="order-row"><strong>{{ __('marketplace.subtotal') }}</strong><span></span><strong>{{ number_format($total,2) }}</strong></div>
        @if($hasUnavailable)<div class="notice warning">{{ __('marketplace.country_checkout_unavailable') }}</div>@else<a class="button" href="{{ route('marketplace.checkout') }}">{{ __('ui.continue_checkout') }}</a>@endif
    </section>
@else
    <div class="empty"><h2>{{ __('ui.cart_empty') }}</h2><p>{{ __('ui.cart_checkout_pending') }}</p><a class="button" href="{{ route('marketplace.home') }}">{{ __('ui.continue_shopping') }}</a></div>
@endif
@endsection