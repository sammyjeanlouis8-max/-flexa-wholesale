@extends('marketplace.layout')
@section('title', __('marketplace.settings'))
@section('content')
<section class="page-head"><p class="eyebrow">{{ __('marketplace.account') }}</p><h1>{{ __('marketplace.settings') }}</h1></section>
@auth
    @php($accountCountry = \App\Support\MarketplaceCountry::details($user->country))
    <form class="panel listing-form" action="{{ route('marketplace.settings.update') }}" method="post">
        @csrf @method('patch')
        <p>{{ __('marketplace.email') }}: <strong>{{ $user->email }}</strong></p>
        <label>{{ __('marketplace.country') }}
            <span class="country-readonly">{{ $accountCountry ? $accountCountry['flag'].' '.$accountCountry['code'].' · '.$accountCountry['name'] : __('marketplace.unknown_location') }}</span>
            <small class="help">{{ __('marketplace.account_country_locked') }}</small>
        </label>
        <label>{{ __('marketplace.city') }}<input name="city" value="{{ old('city', $user->city) }}">@error('city')<small class="error">{{ $message }}</small>@enderror</label>
        <p class="help">{{ __('marketplace.profile_language_note') }}</p>
        <button class="button">{{ __('marketplace.save_settings') }}</button>
    </form>
@else
    <section class="panel"><p>{{ __('marketplace.sign_in_settings') }}</p><a class="button" href="{{ route('login') }}">{{ __('auth.sign_in') }}</a></section>
@endauth
@endsection