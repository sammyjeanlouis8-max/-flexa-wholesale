@extends('marketplace.layout')
@section('title', __('marketplace.profile'))
@section('content')
<section class="page-head"><p class="eyebrow">{{ __('marketplace.account') }}</p><h1>{{ __('marketplace.profile') }}</h1></section>
@auth
    @php($accountCountry = \App\Support\MarketplaceCountry::details($user->country))
    <form class="panel listing-form" action="{{ route('marketplace.profile.update') }}" method="post">
        @csrf @method('patch')
        <label>{{ __('auth.full_name') }}<input name="name" required value="{{ old('name', $user->name) }}">@error('name')<small class="error">{{ $message }}</small>@enderror</label>
        <label>{{ __('auth.phone_number') }}<input name="phone" value="{{ old('phone', $user->phone) }}">@error('phone')<small class="error">{{ $message }}</small>@enderror</label>
        <label>{{ __('marketplace.country') }}
            <span class="country-readonly">{{ $accountCountry ? $accountCountry['flag'].' '.$accountCountry['code'].' · '.$accountCountry['name'] : __('marketplace.unknown_location') }}</span>
            <small class="help">{{ __('marketplace.account_country_locked') }}</small>
        </label>
        <label>{{ __('marketplace.city') }}<input name="city" value="{{ old('city', $user->city) }}">@error('city')<small class="error">{{ $message }}</small>@enderror</label>
        <label>{{ __('marketplace.address') }}<textarea name="address">{{ old('address', $user->address) }}</textarea></label>
        <p class="help">{{ __('marketplace.profile_immutable_fields') }}</p>
        <button class="button">{{ __('marketplace.save_profile') }}</button>
    </form>
@else
    <div class="empty"><h2>{{ __('marketplace.sign_in_profile') }}</h2><a class="button" href="{{ route('login') }}">{{ __('auth.sign_in') }}</a></div>
@endauth
@endsection