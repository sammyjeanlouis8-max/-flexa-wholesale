@extends('marketplace.layout')
@section('title', $product->product_name)
@section('content')
<div class="breadcrumb"><a href="{{ route('marketplace.home') }}">{{ __('marketplace.marketplace') }}</a> / {{ $product->category?->display_name ?? __('marketplace.product') }}</div>
@php($gallery = $product->media->isNotEmpty() ? $product->media : $product->images->map(fn($image) => (object) ['media_type' => 'image', 'url' => asset($image->src), 'original_name' => $product->product_name]))
@php($publicOrigin = collect([$product->city, $product->region, $product->country ? (marketplace_countries()[$product->country] ?? $product->country) : null])->filter()->implode(' · '))
@php($shippingMethods = collect([['ships_internationally', 'marketplace.shipping_method_international'], ['offers_local_delivery', 'marketplace.shipping_method_local'], ['offers_warehouse_pickup', 'marketplace.shipping_method_pickup'], ['offers_seller_delivery', 'marketplace.shipping_method_seller'], ['offers_marketplace_logistics', 'marketplace.shipping_method_marketplace']])->filter(fn($method) => $product->{$method[0]}))
<section class="detail">
    <div class="detail-image product-gallery" aria-label="{{ __('marketplace.product') }}">
        @forelse($gallery as $media)
            @if($media->media_type === 'video')
                <video src="{{ $media->url }}" controls preload="metadata" playsinline aria-label="{{ __('marketplace.product_video') }}"></video>
            @else
                <img src="{{ $media->url }}" alt="{{ $media->original_name ?? $product->product_name }}">
            @endif
        @empty
            <span>{{ __('ui.product_image_unavailable') }}</span>
        @endforelse
    </div>
    <div>
        <p class="eyebrow">{{ $product->category?->display_name ?? __('marketplace.marketplace') }}</p>
        <h1>{{ $product->product_name }}</h1>
        <p class="price large">{{ number_format($product->product_price, 2) }}</p>
        <p class="muted">{{ __('marketplace.wholesale_price') }} · {{ __('marketplace.minimum_order_short', ['count' => $product->minimum_order_quantity, 'unit' => __('seller.unit_'.$product->wholesale_unit_type)]) }}</p>
        <p>{{ $product->product_short_description ?: __('ui.description_pending') }}</p>
        <dl class="specs">
            <div><dt>{{ __('marketplace.availability') }}</dt><dd>{{ $product->product_stock > 0 ? __('ui.in_stock', ['count' => $product->product_stock]) : __('ui.unavailable') }}</dd></div>
            <div><dt>{{ __('marketplace.stock_origin') }}</dt><dd>{{ $publicOrigin ?: __('marketplace.unknown_location') }}</dd></div>
            <div><dt>{{ __('marketplace.delivery') }}</dt><dd>{{ $product->delivery_duration }} {{ $product->delivery_duration_unit }}</dd></div>
            <div><dt>{{ __('marketplace.marketplace_country') }}</dt><dd>{{ marketplace_country_selection() === 'all' ? __('marketplace.all_countries') : (marketplace_countries()[marketplace_country()] ?? marketplace_country()) }}</dd></div>
            <div><dt>{{ __('marketplace.shipping_methods') }}</dt><dd>{{ $shippingMethods->map(fn($method) => __($method[1]))->implode(', ') ?: __('marketplace.delivery') }}</dd></div>
        </dl>
        @if($product->priceTiers->isNotEmpty())
            <div class="panel">
                <h2>{{ __('marketplace.price_tiers') }}</h2>
                <table>
                    <thead><tr><th>{{ __('marketplace.quantity') }}</th><th>{{ __('marketplace.wholesale_price') }}</th></tr></thead>
                    <tbody>
                    @foreach($product->priceTiers as $tier)
                        <tr><td>{{ $tier->min_quantity }}–{{ $tier->max_quantity ?? '∞' }}</td><td>{{ number_format($tier->unit_price, 2) }}</td></tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        @endif
        @unless($availableInCountry)
            <div class="notice warning" role="status">{{ __('marketplace.not_available_country') }}</div>
        @endunless
        <div class="notice warning" role="note">{{ __('marketplace.verify_before_payment') }}</div>
        @auth
            @if($availableInCountry && !$availableForPurchase)
                <div class="notice warning" role="status">{{ __('marketplace.browse_only_other_market') }}</div>
            @endif
        @endauth
        @auth
            <div class="actions">
                <form action="{{ route('marketplace.cart.add',$product) }}" method="post">@csrf<input type="number" name="quantity" min="{{ $product->minimum_order_quantity }}" max="{{ $product->product_stock }}" value="{{ $product->minimum_order_quantity }}" aria-label="{{ __('marketplace.quantity') }}"><button class="button" {{ $product->product_stock < $product->minimum_order_quantity || !$availableForPurchase ? 'disabled':'' }}>{{ __('marketplace.add_to_cart') }}</button></form>
                <form action="{{ route('marketplace.favorite.add',$product) }}" method="post">@csrf<button class="button secondary" {{ !$availableForPurchase ? 'disabled':'' }}>{{ __('ui.save_item') }}</button></form>
            </div>
        @else
            <a class="button" href="{{ route('login') }}">{{ __('auth.sign_in') }}</a>
        @endauth
    </div>
</section>
<section class="seller-card"><p class="eyebrow">{{ __('ui.sold_by') }}</p><h2>{{ $product->vendor->user->company_name ?? $product->vendor->user->name ?? __('ui.independent_seller') }}</h2><p>{{ $product->vendor->city ?? '' }} {{ $product->vendor->region ?? '' }}</p>@if($product->vendor)<a class="text-link" href="{{ route('marketplace.store',$product->vendor) }}">{{ __('ui.visit_store') }}</a>@endif</section>
@endsection