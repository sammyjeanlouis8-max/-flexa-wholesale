<div class="nav-scrim" data-menu-close hidden></div>
<aside class="nav-drawer" id="marketplace-drawer" aria-label="{{ __('marketplace.navigation') }}" aria-hidden="true" tabindex="-1">
    <div class="nav-drawer-head">
        <div>
            <p class="eyebrow">{{ __('marketplace.navigation') }}</p>
            <h2>{{ __('marketplace.explore_flexa') }}</h2>
        </div>
        <button class="icon-button" type="button" data-menu-close aria-label="{{ __('common.close') }}">×</button>
    </div>
    <form class="drawer-search global-search" action="{{ route('marketplace.search') }}" method="get" data-global-search>
        <label class="sr-only" for="market-search-drawer">{{ __('marketplace.search_products') }}</label>
        <input id="market-search-drawer" name="q" placeholder="{{ __('marketplace.search_placeholder') }}" autocomplete="off" aria-expanded="false" aria-controls="drawer-search-suggestions">
        <button type="submit">{{ __('common.search') }}</button>
        <div class="search-suggestions" id="drawer-search-suggestions" data-search-suggestions role="listbox" hidden></div>
    </form>
    <section class="drawer-market panel" aria-labelledby="drawer-market-title">
        <div class="drawer-market-title" id="drawer-market-title">{{ __('marketplace.nav.country_market') }}</div>
        @include('partials.marketplace-country-selector', ['selectorId' => 'drawer-marketplace-country', 'searchId' => 'drawer-marketplace-country-search'])
    </section>

    <section class="account-card">
        @auth
            <div class="account-avatar" aria-hidden="true">{{ \Illuminate\Support\Str::upper(\Illuminate\Support\Str::substr($marketplaceNavigation['user']->name ?? 'F', 0, 1)) }}</div>
            <div class="account-card-copy">
                <strong>{{ $marketplaceNavigation['user']->name ?: __('marketplace.account') }}</strong>
                <span>{{ $marketplaceNavigation['isSeller'] ? __('marketplace.verified_seller') : __('marketplace.buyer_account') }}</span>
                @if($marketplaceNavigation['accountCountry'])
                    <small>{{ $marketplaceNavigation['accountCountry']['flag'] }} {{ $marketplaceNavigation['accountCountry']['name'] }}</small>
                @endif
            </div>
            <span class="verification-dot" title="{{ __('marketplace.account_status') }}" aria-label="{{ __('marketplace.account_status') }}">✓</span>
            <a class="button secondary account-card-link" href="{{ route('marketplace.profile') }}">{{ __('marketplace.view_profile') }}</a>
        @else
            <div class="account-avatar" aria-hidden="true">F</div>
            <div class="account-card-copy">
                <strong>{{ __('auth.welcome_to_marketplace') }}</strong>
                <span>{{ __('marketplace.join_global_wholesale') }}</span>
            </div>
            <div class="account-card-actions">
                <a class="button" href="{{ route('login') }}">{{ __('auth.sign_in') }}</a>
                <a class="text-link" href="{{ route('signup') }}">{{ __('auth.create_account') }}</a>
            </div>
        @endauth
    </section>

    <nav class="drawer-sections">
        <details class="nav-section" open>
            <summary><span class="nav-section-title"><span class="nav-icon">⌂</span>{{ __('marketplace.nav.home') }}</span><span class="nav-chevron">⌄</span></summary>
            <div class="nav-section-links">
                <a class="{{ request()->routeIs('marketplace.home') && !request('q') ? 'active' : '' }}" href="{{ route('marketplace.home') }}"><span class="nav-icon">⌂</span>{{ __('marketplace.nav.home_link') }}</a>
                <a class="{{ request()->routeIs('marketplace.search') ? 'active' : '' }}" href="{{ route('marketplace.search') }}"><span class="nav-icon">⌕</span>{{ __('marketplace.nav.explore') }}</a>
                <a href="{{ route('marketplace.home') }}#categories"><span class="nav-icon">▦</span>{{ __('marketplace.nav.categories') }}</a>
                <a href="{{ route('marketplace.home') }}#catalog"><span class="nav-icon">↗</span>{{ __('marketplace.nav.trending') }}</a>
                <a href="{{ route('marketplace.home') }}#catalog"><span class="nav-icon">✦</span>{{ __('marketplace.nav.new_arrivals') }}</a>
                <a href="{{ route('marketplace.home') }}#featured"><span class="nav-icon">%</span>{{ __('marketplace.nav.promotions') }}</a>
            </div>
        </details>

        <details class="nav-section" open>
            <summary><span class="nav-section-title"><span class="nav-icon">▤</span>{{ __('marketplace.nav.marketplace') }}</span><span class="nav-chevron">⌄</span></summary>
            <div class="nav-section-links">
                <a href="{{ route('marketplace.search') }}"><span class="nav-icon">⌕</span>{{ __('marketplace.nav.browse_products') }}</a>
                <a href="{{ route('marketplace.home') }}#categories"><span class="nav-icon">▦</span>{{ __('marketplace.nav.categories') }}</a>
                <a href="{{ route('marketplace.home') }}#catalog"><span class="nav-icon">✓</span>{{ __('marketplace.nav.verified_stores') }}</a>
                <a href="{{ route('marketplace.home', ['country' => 'all']) }}#catalog"><span class="nav-icon">◎</span>{{ __('marketplace.nav.international_products') }}</a>
                <a href="{{ route('marketplace.home') }}#catalog"><span class="nav-icon">⌖</span>{{ __('marketplace.nav.near_me') }}</a>
                <a href="{{ route('marketplace.home') }}#featured"><span class="nav-icon">✦</span>{{ __('marketplace.nav.featured_products') }}</a>
            </div>
        </details>

        <details class="nav-section">
            <summary><span class="nav-section-title"><span class="nav-icon">▥</span>{{ __('marketplace.nav.wholesale') }}</span><span class="nav-chevron">⌄</span></summary>
            <div class="nav-section-links">
                <a href="{{ route('marketplace.home') }}#catalog"><span class="nav-icon">▥</span>{{ __('marketplace.nav.wholesale_marketplace') }}</a>
                <a href="{{ route('marketplace.search') }}"><span class="nav-icon">▤</span>{{ __('marketplace.nav.buy_wholesale') }}</a>
                <a href="{{ route('marketplace.home') }}#catalog"><span class="nav-icon">♙</span>{{ __('marketplace.nav.wholesale_sellers') }}</a>
                <a href="{{ route('marketplace.orders') }}"><span class="nav-icon">▣</span>{{ __('marketplace.nav.bulk_orders') }}</a>
                <a href="{{ route('marketplace.home') }}#catalog"><span class="nav-icon">≋</span>{{ __('marketplace.nav.quantity_discounts') }}</a>
                @auth
                    <a href="{{ route('marketplace.messages') }}"><span class="nav-icon">✉</span>{{ __('marketplace.nav.request_quote') }}</a>
                @else
                    <a href="{{ route('login') }}"><span class="nav-icon">✉</span>{{ __('marketplace.nav.request_quote') }}</a>
                @endauth
            </div>
        </details>

        <details class="nav-section" @auth open @endauth>
            <summary><span class="nav-section-title"><span class="nav-icon">♙</span>{{ __('marketplace.nav.my_account') }}</span><span class="nav-chevron">⌄</span></summary>
            <div class="nav-section-links">
                @auth
                    <a class="{{ request()->routeIs('buyer.dashboard') ? 'active' : '' }}" href="{{ route('buyer.dashboard') }}"><span class="nav-icon">▦</span>{{ __('marketplace.nav.account_dashboard') }}</a>
                    <a class="{{ request()->routeIs('marketplace.profile') ? 'active' : '' }}" href="{{ route('marketplace.profile') }}"><span class="nav-icon">♙</span>{{ __('marketplace.nav.my_profile') }}</a>
                    <a class="{{ request()->routeIs('marketplace.orders','marketplace.order') ? 'active' : '' }}" href="{{ route('marketplace.orders') }}"><span class="nav-icon">▣</span>{{ __('marketplace.nav.my_orders') }}@if($marketplaceNavigation['counts']['orders'])<span class="nav-count">{{ $marketplaceNavigation['counts']['orders'] }}</span>@endif</a>
                    <a href="{{ route('marketplace.favorites') }}"><span class="nav-icon">♡</span>{{ __('marketplace.nav.saved_products') }}@if($marketplaceNavigation['counts']['favorites'])<span class="nav-count">{{ $marketplaceNavigation['counts']['favorites'] }}</span>@endif</a>
                    <a href="{{ route('marketplace.messages') }}"><span class="nav-icon">✉</span>{{ __('marketplace.nav.messages') }}@if($marketplaceNavigation['counts']['messages'])<span class="nav-count">{{ $marketplaceNavigation['counts']['messages'] }}</span>@endif</a>
                    <a href="{{ route('marketplace.notifications') }}"><span class="nav-icon">◌</span>{{ __('marketplace.nav.notifications') }}@if($marketplaceNavigation['counts']['notifications'])<span class="nav-count">{{ $marketplaceNavigation['counts']['notifications'] }}</span>@endif</a>
                    <a href="{{ route('marketplace.settings') }}"><span class="nav-icon">⚙</span>{{ __('marketplace.nav.addresses_payment') }}</a>
                @else
                    <a href="{{ route('login') }}"><span class="nav-icon">♙</span>{{ __('auth.sign_in') }}</a>
                    <a href="{{ route('signup') }}"><span class="nav-icon">+</span>{{ __('auth.create_account') }}</a>
                @endauth
            </div>
        </details>

        @if($marketplaceNavigation['isSeller'])
            <details class="nav-section" open>
                <summary><span class="nav-section-title"><span class="nav-icon">▥</span>{{ __('marketplace.nav.selling') }}</span><span class="nav-chevron">⌄</span></summary>
                <div class="nav-section-links">
                    <a class="{{ request()->routeIs('seller.dashboard') ? 'active' : '' }}" href="{{ route('seller.dashboard') }}"><span class="nav-icon">▦</span>{{ __('seller.seller_dashboard') }}</a>
                    @if($marketplaceNavigation['user']->vendor)
                        <a href="{{ route('marketplace.store', $marketplaceNavigation['user']->vendor) }}"><span class="nav-icon">▤</span>{{ __('marketplace.nav.my_store') }}</a>
                    @endif
                    <a href="{{ route('seller.product-create') }}"><span class="nav-icon">+</span>{{ __('seller.add_product') }}</a>
                    <a class="{{ request()->routeIs('seller.products','seller.product-create','seller.product-edit') ? 'active' : '' }}" href="{{ route('seller.products') }}"><span class="nav-icon">▣</span>{{ __('marketplace.nav.my_products') }}</a>
                    <a href="{{ route('seller.orders') }}"><span class="nav-icon">▣</span>{{ __('seller.orders') }}</a>
                    <a href="{{ route('seller.customers') }}"><span class="nav-icon">♙</span>{{ __('seller.customers') }}</a>
                    <a href="{{ route('seller.products') }}"><span class="nav-icon">▤</span>{{ __('seller.inventory') }}</a>
                    <a href="{{ route('seller.earnings') }}"><span class="nav-icon">↗</span>{{ __('marketplace.nav.sales_analytics') }}</a>
                    <a href="{{ route('seller.settings') }}"><span class="nav-icon">⚙</span>{{ __('seller.store_settings') }}</a>
                </div>
            </details>
        @endif

        @auth
            <details class="nav-section">
                <summary><span class="nav-section-title"><span class="nav-icon">$</span>{{ __('marketplace.nav.finance') }}</span><span class="nav-chevron">⌄</span></summary>
                <div class="nav-section-links">
                    <a href="{{ $marketplaceNavigation['isSeller'] ? route('seller.earnings') : route('marketplace.orders') }}"><span class="nav-icon">$</span>{{ __('marketplace.nav.wallet') }}</a>
                    <a href="{{ route('marketplace.orders') }}"><span class="nav-icon">↗</span>{{ __('marketplace.nav.transactions') }}</a>
                    <a href="{{ $marketplaceNavigation['isSeller'] ? route('seller.earnings') : route('marketplace.orders') }}"><span class="nav-icon">⇩</span>{{ __('marketplace.nav.withdrawals') }}</a>
                    <a href="{{ route('marketplace.orders') }}"><span class="nav-icon">▣</span>{{ __('marketplace.nav.payments') }}</a>
                    <a href="{{ route('marketplace.orders') }}"><span class="nav-icon">↩</span>{{ __('marketplace.nav.refunds') }}</a>
                    <a href="{{ route('marketplace.settings') }}"><span class="nav-icon">▤</span>{{ __('marketplace.nav.billing') }}</a>
                </div>
            </details>
        @endauth

        <details class="nav-section">
            <summary><span class="nav-section-title"><span class="nav-icon">⚙</span>{{ __('marketplace.nav.settings') }}</span><span class="nav-chevron">⌄</span></summary>
            <div class="nav-section-links">
                <a href="#locale-selector"><span class="nav-icon">文</span>{{ __('marketplace.nav.language') }}</a>
                <a href="#market-selector"><span class="nav-icon">◎</span>{{ __('marketplace.nav.country_market') }}</a>
                @auth
                    <a href="{{ route('marketplace.settings') }}"><span class="nav-icon">$</span>{{ __('marketplace.nav.currency') }}</a>
                    <a href="{{ route('marketplace.notifications') }}"><span class="nav-icon">◌</span>{{ __('marketplace.nav.notification_settings') }}</a>
                    <a href="{{ route('marketplace.settings') }}"><span class="nav-icon">⌑</span>{{ __('marketplace.nav.privacy_security') }}</a>
                @endauth
                @auth
                    <a href="{{ route('marketplace.messages') }}"><span class="nav-icon">?</span>{{ __('marketplace.nav.help_support') }}</a>
                @else
                    <a href="{{ route('login') }}"><span class="nav-icon">?</span>{{ __('marketplace.nav.help_support') }}</a>
                @endauth
            </div>
        </details>
    </nav>
</aside>