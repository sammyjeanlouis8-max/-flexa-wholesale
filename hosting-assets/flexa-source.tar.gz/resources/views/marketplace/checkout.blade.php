@extends('marketplace.layout')
@section('title', __('marketplace.checkout'))
@section('content')
<section class="page-head"><p class="eyebrow">{{ __('marketplace.purchase_request') }}</p><h1>{{ __('marketplace.purchase_request') }}</h1><p>{{ __('marketplace.purchase_request_description') }}</p></section>
@if($cart && $cart->items->isNotEmpty())
    <form class="panel listing-form" action="{{ route('marketplace.checkout.place') }}" method="post">@csrf
        <div class="notice warning"><strong>{{ __('marketplace.verify_before_payment') }}</strong></div>
        <label>{{ __('marketplace.checkout_country') }}<input type="hidden" name="delivery_country" value="{{ $marketplaceCountry }}"><span class="country-readonly">{{ \App\Support\MarketplaceCountry::details($marketplaceCountry)['flag'] ?? '' }} {{ $marketplaceCountry }} · {{ $countries[$marketplaceCountry] ?? $marketplaceCountry }}</span><small class="help">{{ __('marketplace.checkout_country_help') }}</small></label>
        @error('delivery_country')<small class="error">{{ $message }}</small>@enderror
        <label>{{ __('marketplace.meeting_details') }}<textarea name="delivery_address" required rows="4" placeholder="{{ __('marketplace.meeting_details_help') }}">{{ old('delivery_address',auth()->user()->address) }}</textarea><small class="help">{{ __('marketplace.meeting_details_help') }}</small>@error('delivery_address')<small class="error">{{ $message }}</small>@enderror</label>
        <button class="button">{{ __('marketplace.place_purchase_request') }}</button>
    </form>
@else
    <div class="empty"><h2>{{ __('ui.cart_empty') }}</h2><p>{{ __('ui.add_before_checkout') }}</p><a class="button" href="{{ route('marketplace.home') }}">{{ __('ui.continue_shopping') }}</a></div>
@endif
@endsection