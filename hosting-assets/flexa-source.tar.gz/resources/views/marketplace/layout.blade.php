<!doctype html>
<html lang="{{ current_locale() }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta name="description" content="{{ __('marketplace.discover_products') }}">
    <title>@yield('title', __('marketplace.marketplace')) · {{ __('common.app_name') }}</title>
    <link rel="icon" href="{{ asset('custom/flexa-wo-seller-logo.png') }}" type="image/png">
    <link rel="stylesheet" href="{{ asset('custom/marketplace.css') }}">
    <link rel="stylesheet" href="{{ asset('custom/location.css') }}">
    <link rel="stylesheet" href="{{ asset('custom/marketplace-navigation.css') }}">
    <link rel="stylesheet" href="{{ asset('custom/marketplace-hero.css') }}">
    <link rel="stylesheet" href="{{ asset('custom/category-search.css') }}">
    <link rel="stylesheet" href="{{ asset('back/plugins/fontawesome-free/css/all.min.css') }}">
</head>
<body>
    <a class="skip" href="#content">{{ __('common.skip_to_content') }}</a>
    <header class="topbar">
        <a class="brand brand-with-mark" href="{{ route('marketplace.home') }}">
            <img class="brand-mark" src="{{ asset('custom/flexa-wo-seller-logo.png') }}" alt="" aria-hidden="true">
            <span>FLEXA WHOLESALE</span>
        </a>
        <form class="search global-search" action="{{ route('marketplace.search') }}" method="get" data-global-search>
            <label class="sr-only" for="market-search">{{ __('marketplace.search_products') }}</label>
            <input id="market-search" name="q" value="{{ request('q') }}" placeholder="{{ __('marketplace.search_placeholder') }}" autocomplete="off" aria-expanded="false" aria-controls="search-suggestions">
            <button type="submit">{{ __('common.search') }}</button>
            <div class="search-suggestions" id="search-suggestions" data-search-suggestions role="listbox" hidden></div>
        </form>
        <button class="menu-trigger" type="button" data-menu-open aria-controls="marketplace-drawer" aria-expanded="false">
            <span class="menu-trigger-lines" aria-hidden="true">☰</span><span>{{ __('marketplace.menu') }}</span>
        </button>
        <nav class="top-links" aria-label="{{ __('marketplace.account') }}">
            @auth
                <a href="{{ route('marketplace.favorites') }}" class="top-link-with-count">{{ __('marketplace.saved') }}@if($marketplaceNavigation['counts']['favorites'])<span class="count">{{ $marketplaceNavigation['counts']['favorites'] }}</span>@endif</a>
                <a href="{{ route('marketplace.cart') }}" class="top-link-with-count">{{ __('marketplace.cart') }}@if($marketplaceNavigation['counts']['cart'])<span class="count">{{ $marketplaceNavigation['counts']['cart'] }}</span>@endif</a>
                <a href="{{ route('marketplace.orders') }}">{{ __('marketplace.orders') }}</a>
                <a href="{{ route('marketplace.profile') }}">{{ __('marketplace.account') }}</a>
            @else
                <a href="{{ route('login') }}">{{ __('auth.sign_in') }}</a>
            @endauth
        </nav>
        <div id="locale-selector">@include('partials.locale-selector')</div>
        <div id="market-selector">@include('partials.marketplace-country-selector')</div>
    </header>

    @include('marketplace.navigation-drawer')

    @if($marketplaceNavigation['isSeller'])
        <div class="seller-quick-actions">
            <button class="seller-quick-trigger" type="button" data-quick-actions aria-expanded="false" aria-controls="seller-quick-menu">
                <span aria-hidden="true">+</span><span class="sr-only">{{ __('marketplace.nav.quick_seller_actions') }}</span>
            </button>
            <div class="seller-quick-menu" id="seller-quick-menu" hidden>
                <p>{{ __('marketplace.nav.quick_seller_actions') }}</p>
                <a href="{{ route('seller.product-create') }}"><span class="nav-icon">+</span>{{ __('seller.add_product') }}</a>
                <a href="{{ route('seller.products') }}"><span class="nav-icon">▣</span>{{ __('marketplace.nav.my_products') }}</a>
                <a href="{{ route('seller.orders') }}"><span class="nav-icon">▣</span>{{ __('seller.orders') }}</a>
                <a href="{{ route('marketplace.messages') }}"><span class="nav-icon">✉</span>{{ __('marketplace.messages') }}</a>
                <a href="{{ route('seller.earnings') }}"><span class="nav-icon">↗</span>{{ __('marketplace.nav.sales_analytics') }}</a>
            </div>
        </div>
    @endif

    <div class="shell">
        <aside class="sidebar">
            <div class="sidebar-intro">
                <p class="workspace-label">{{ __('marketplace.nav.quick_access') }}</p>
                <button class="sidebar-menu-button" type="button" data-menu-open><span class="nav-icon">☰</span>{{ __('marketplace.menu') }}</button>
            </div>
            <nav aria-label="{{ __('marketplace.navigation') }}">
                <a class="{{ request()->routeIs('marketplace.home') && !request('q') ? 'active' : '' }}" href="{{ route('marketplace.home') }}"><span class="nav-icon">⌂</span>{{ __('marketplace.nav.home_link') }}</a>
                <a class="{{ request()->routeIs('marketplace.search') ? 'active' : '' }}" href="{{ route('marketplace.search') }}"><span class="nav-icon">⌕</span>{{ __('marketplace.nav.explore') }}</a>
                <a href="{{ route('marketplace.home') }}#categories"><span class="nav-icon">▦</span>{{ __('marketplace.nav.categories') }}</a>
                @auth
                    <a href="{{ route('marketplace.favorites') }}"><span class="nav-icon">♡</span>{{ __('marketplace.saved') }}@if($marketplaceNavigation['counts']['favorites'])<span class="nav-count">{{ $marketplaceNavigation['counts']['favorites'] }}</span>@endif</a>
                    <a href="{{ route('marketplace.orders') }}"><span class="nav-icon">▣</span>{{ __('marketplace.my_orders') }}@if($marketplaceNavigation['counts']['orders'])<span class="nav-count">{{ $marketplaceNavigation['counts']['orders'] }}</span>@endif</a>
                    <a href="{{ route('marketplace.messages') }}"><span class="nav-icon">✉</span>{{ __('marketplace.messages') }}@if($marketplaceNavigation['counts']['messages'])<span class="nav-count">{{ $marketplaceNavigation['counts']['messages'] }}</span>@endif</a>
                    <a href="{{ route('marketplace.notifications') }}"><span class="nav-icon">◌</span>{{ __('marketplace.notifications') }}@if($marketplaceNavigation['counts']['notifications'])<span class="nav-count">{{ $marketplaceNavigation['counts']['notifications'] }}</span>@endif</a>
                @endif
            </nav>
        </aside>
        <main id="content">
            @if(session('messege'))<div class="notice">{{ session('messege') }}</div>@endif
            @yield('content')
        </main>
    </div>

    <nav class="mobile-nav" aria-label="{{ __('marketplace.quick_navigation') }}">
        <a class="{{ request()->routeIs('marketplace.home') ? 'active' : '' }}" href="{{ route('marketplace.home') }}"><span class="nav-icon" aria-hidden="true"><i class="fas fa-home"></i></span><span>{{ __('marketplace.nav.home_link') }}</span></a>
        <a class="{{ request()->routeIs('marketplace.search') ? 'active' : '' }}" href="{{ route('marketplace.search') }}"><span class="nav-icon" aria-hidden="true"><i class="fas fa-search"></i></span><span>{{ __('marketplace.nav.explore') }}</span></a>
        <a href="{{ route('marketplace.home') }}#catalog"><span class="nav-icon" aria-hidden="true"><i class="fas fa-boxes"></i></span><span>{{ __('marketplace.nav.wholesale') }}</span></a>
        <a class="mobile-cart-link" href="{{ route('marketplace.cart') }}"><span class="nav-icon" aria-hidden="true"><i class="fas fa-shopping-cart"></i></span><span>{{ __('marketplace.cart') }}</span>@auth @if($marketplaceNavigation['counts']['cart'])<span class="nav-count">{{ $marketplaceNavigation['counts']['cart'] }}</span>@endif @endauth</a>
        <a href="{{ auth()->check() ? route('marketplace.profile') : route('login') }}"><span class="nav-icon" aria-hidden="true"><i class="fas fa-user"></i></span><span>{{ __('marketplace.account') }}</span></a>
    </nav>

    <script src="{{ asset('custom/marketplace.js') }}" defer></script>
    <script src="{{ asset('custom/marketplace-navigation.js') }}" defer></script>
    <script>
        document.querySelectorAll('[data-country-search-for]').forEach(input => {
            const select = document.getElementById(input.dataset.countrySearchFor);
            if (!select) return;
            input.addEventListener('input', () => {
                const term = input.value.trim().toLowerCase();
                [...select.options].forEach(option => {
                    option.hidden = term !== '' && !option.dataset.countryLabel?.includes(term);
                });
            });
        });
    </script>
    @stack('scripts')
</body>
</html>