<!DOCTYPE html>
<html lang="{{ current_locale() }}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ __('auth.forgot_password') }} · {{ __('common.app_name') }}</title>
    <link rel="icon" href="{{ asset('custom/flexa-wo-seller-logo.png') }}" type="image/png">
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = { theme: { extend: { colors: { brand: { 500: '#14b8a6', 600: '#0DA487', 700: '#0f766e' } } } } };
    </script>
</head>
<body class="bg-gray-50 text-gray-900 antialiased min-h-screen flex items-center justify-center px-6 py-12">
    <main class="w-full max-w-md">
        <div class="flex flex-col items-center gap-2 mb-8">
            <img src="{{ asset('custom/flexa-wo-seller-logo.png') }}" alt="" aria-hidden="true" class="h-16 w-16 rounded-2xl object-cover shadow-md">
            <h1 class="text-3xl font-bold text-brand-600">{{ __('common.app_name') }}</h1>
        </div>

        <section class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 sm:p-8">
            <h2 class="text-2xl font-bold text-gray-900">{{ __('auth.forgot_password') }}</h2>
            <p class="mt-2 text-sm leading-6 text-gray-600">{{ __('auth.forgot_password_intro') }}</p>

            @if (session('status'))
                <div class="mt-5 rounded-lg border border-green-100 bg-green-50 p-4 text-sm text-green-800">
                    {{ session('status') }}
                </div>
            @endif

            @if (session('dev_reset_url'))
                <div class="mt-5 rounded-lg border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900">
                    <p class="font-semibold">{{ __('auth.reset_link_local_preview') }}</p>
                    <a href="{{ session('dev_reset_url') }}" class="mt-2 block break-all font-medium text-brand-700 underline">
                        {{ session('dev_reset_url') }}
                    </a>
                </div>
            @endif

            @if ($errors->any())
                <div class="mt-5 rounded-lg border border-red-100 bg-red-50 p-4 text-sm text-red-700">
                    @foreach ($errors->all() as $error)
                        <p>{{ $error }}</p>
                    @endforeach
                </div>
            @endif

            <form method="POST" action="{{ route('password.email', [], false) }}" class="mt-6 space-y-5">
                @csrf
                <div>
                    <label for="forgot-email" class="block text-sm font-medium text-gray-700 mb-1.5">{{ __('auth.email_address') }}</label>
                    <input id="forgot-email" name="email" type="email" value="{{ old('email') }}" required autocomplete="email"
                           class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-brand-500 focus:border-brand-500 bg-gray-50 focus:bg-white text-gray-900">
                </div>
                <button type="submit" class="w-full py-3 px-4 rounded-lg bg-brand-600 hover:bg-brand-700 text-white font-medium focus:outline-none focus:ring-2 focus:ring-brand-500">
                    {{ __('auth.send_reset_link') }}
                </button>
            </form>

            <a href="{{ route('auth.show', [], false) }}" class="mt-6 block text-center text-sm font-semibold text-brand-600 hover:text-brand-700">
                {{ __('auth.back_to_sign_in') }}
            </a>
        </section>
    </main>
</body>
</html>