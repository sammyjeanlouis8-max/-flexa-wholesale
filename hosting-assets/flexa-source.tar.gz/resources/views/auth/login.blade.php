<!DOCTYPE html>
<html lang="{{ current_locale() }}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ __('auth.welcome_to_marketplace') }}</title>
    <link rel="icon" href="{{ asset('custom/flexa-wo-seller-logo.png') }}" type="image/png">
    <script src="https://cdn.tailwindcss.com"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        brand: {
                            50: '#f0fdfa',
                            100: '#ccfbf1',
                            500: '#14b8a6',
                            600: '#0DA487',
                            700: '#0f766e',
                            900: '#134e4a',
                        }
                    },
                    fontFamily: {
                        sans: ['Inter', 'ui-sans-serif', 'system-ui', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'Roboto', 'Helvetica Neue', 'Arial', 'sans-serif'],
                    }
                }
            }
        }
    </script>
    <style>
        [x-cloak] { display: none !important; }
    </style>
</head>
<body class="bg-gray-50 text-gray-900 antialiased min-h-screen flex flex-col md:flex-row" x-data="{ 
    mode: '{{ (old('name') || $errors->has('name') || $errors->has('role') || $errors->has('password_confirmation') || request()->routeIs('signup')) ? 'register' : 'login' }}',
    role: '{{ in_array(old('role', request('role')), ['buyer', 'seller', 'buyer_seller']) ? old('role', request('role')) : 'buyer' }}',
    showPassword: false 
}">

    <!-- Left side - Branding -->
    <div class="hidden md:flex md:w-1/2 lg:w-3/5 bg-brand-900 relative overflow-hidden items-center justify-center">
        <div class="absolute inset-0 bg-brand-600 opacity-20 mix-blend-multiply"></div>
        <!-- Decorative pattern/blobs -->
        <div class="absolute -top-24 -left-24 w-96 h-96 rounded-full bg-brand-500 blur-3xl opacity-30"></div>
        <div class="absolute bottom-0 right-0 w-2/3 h-2/3 rounded-full bg-brand-700 blur-3xl opacity-40"></div>

        <div class="relative z-10 px-12 text-white max-w-2xl">
            <div class="flex items-center gap-3 mb-10">
                <img src="{{ asset('custom/flexa-wo-seller-logo.png') }}" alt="" aria-hidden="true" class="h-14 w-14 rounded-2xl object-cover shadow-lg">
                <span class="text-2xl font-bold tracking-tight">Flexa Wo Seller</span>
            </div>
            <h1 class="text-5xl lg:text-6xl font-bold tracking-tight mb-6">{{ __('auth.discover_sellers') }}</h1>
            <p class="text-xl text-brand-100 mb-10 leading-relaxed">{{ __('auth.marketplace_intro') }}</p>
            <div class="flex items-center space-x-4">
                <div class="flex -space-x-3">
                    <div class="w-12 h-12 rounded-full bg-brand-100 flex items-center justify-center border-2 border-brand-900 text-brand-700 font-bold">JD</div>
                    <div class="w-12 h-12 rounded-full bg-gray-200 flex items-center justify-center border-2 border-brand-900 text-gray-700 font-bold">AS</div>
                    <div class="w-12 h-12 rounded-full bg-brand-500 flex items-center justify-center border-2 border-brand-900 text-white font-bold text-sm">+1k</div>
                </div>
                <span class="text-brand-100 font-medium">{{ __('auth.join_community') }}</span>
            </div>
        </div>
    </div>

    <!-- Right side - Forms -->
    <div class="w-full md:w-1/2 lg:w-2/5 flex flex-col justify-center px-6 py-12 md:px-12 lg:px-16 lg:py-24 bg-white relative">
        <div class="max-w-md w-full mx-auto">
            <!-- Mobile Header -->
            <div class="md:hidden mb-8 flex flex-col items-center gap-2">
                <img src="{{ asset('custom/flexa-wo-seller-logo.png') }}" alt="" aria-hidden="true" class="h-16 w-16 rounded-2xl object-cover shadow-md">
                <h1 class="text-3xl font-bold text-brand-600">{{ __('common.app_name') }}</h1>
            </div>

            <!-- Segmented Control for Login/Register -->
            <div class="flex p-1 bg-gray-100 rounded-xl mb-8 relative">
                <button @click="mode = 'login'" type="button"
                        :class="mode === 'login' ? 'bg-white text-brand-600 shadow-sm' : 'text-gray-500 hover:text-gray-700'"
                        class="w-1/2 py-2.5 text-sm font-semibold rounded-lg transition-all duration-200">
                    {{ __('auth.sign_in') }}
                </button>
                <button @click="mode = 'register'" type="button"
                        :class="mode === 'register' ? 'bg-white text-brand-600 shadow-sm' : 'text-gray-500 hover:text-gray-700'"
                        class="w-1/2 py-2.5 text-sm font-semibold rounded-lg transition-all duration-200">
                    {{ __('auth.create_account') }}
                </button>
            </div>

            @if ($errors->any())
                <div class="mb-6 p-4 rounded-lg bg-red-50 border border-red-100">
                    <div class="flex">
                        <div class="flex-shrink-0">
                            <svg class="h-5 w-5 text-red-400" viewBox="0 0 20 20" fill="currentColor">
                                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd" />
                            </svg>
                        </div>
                        <div class="ml-3">
                            <h3 class="text-sm font-medium text-red-800">{{ __('validation.submission_errors') }}</h3>
                            <ul class="mt-2 text-sm text-red-700 list-disc list-inside">
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                             @if ($errors->first('email') === __('auth.email_already_registered'))
                                 <p class="mt-3 text-sm text-red-700">{{ __('auth.email_exists_hint') }}</p>
                                 <button type="button"
                                         @click="mode = 'login'; $nextTick(() => document.getElementById('login-email')?.focus())"
                                         class="mt-3 inline-flex items-center rounded-lg bg-brand-600 px-3 py-2 text-sm font-semibold text-white hover:bg-brand-700 focus:outline-none focus:ring-2 focus:ring-brand-500">
                                     {{ __('auth.sign_in') }}
                                 </button>
                             @endif
                        </div>
                    </div>
                </div>
            @endif

            @if (session('messege'))
                <div class="mb-6 p-4 rounded-lg {{ session('alert-type') === 'error' ? 'bg-red-50 border-red-100 text-red-800' : 'bg-green-50 border-green-100 text-green-800' }} border">
                    <p class="text-sm font-medium">{{ session('messege') }}</p>
                </div>
            @endif

            <!-- Login Form -->
            <form x-show="mode === 'login'" x-cloak method="POST" action="{{ route('auth.login', [], false) }}" class="space-y-5">
                @csrf
                <div>
                    <label for="login-email" class="block text-sm font-medium text-gray-700 mb-1.5">{{ __('auth.email_address') }}</label>
                    <input id="login-email" name="email" type="email" value="{{ old('email') }}" required autocomplete="email" class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-brand-500 focus:border-brand-500 transition-shadow bg-gray-50 focus:bg-white text-gray-900 placeholder-gray-400">
                </div>
                <div>
                    <div class="flex items-center justify-between mb-1.5">
                        <label for="login-password" class="block text-sm font-medium text-gray-700">{{ __('auth.password') }}</label>
                         <a href="{{ route('password.request', [], false) }}" class="text-sm font-medium text-brand-600 hover:text-brand-500">{{ __('auth.forgot_password') }}</a>
                    </div>
                    <div class="relative">
                        <input id="login-password" name="password" :type="showPassword ? 'text' : 'password'" required autocomplete="current-password" class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-brand-500 focus:border-brand-500 transition-shadow bg-gray-50 focus:bg-white text-gray-900 pr-12">
                        <button type="button" @click="showPassword = !showPassword" class="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-600 focus:outline-none">
                            <svg x-show="!showPassword" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /></svg>
                            <svg x-show="showPassword" x-cloak class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21" /></svg>
                        </button>
                    </div>
                </div>
                <button type="submit" class="w-full py-3 px-4 rounded-lg bg-brand-600 hover:bg-brand-700 text-white font-medium focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-500 transition-colors shadow-sm">
                    {{ __('auth.sign_in') }}
                </button>
            </form>

            <!-- Register Form -->
            <form x-show="mode === 'register'" x-cloak method="POST" action="{{ route('auth.register', [], false) }}" class="space-y-4">
                @csrf
                
                <!-- Role Selector -->
                <div class="mb-6">
                    <label class="block text-sm font-medium text-gray-700 mb-3">{{ __('auth.signup_intent') }}</label>
                    <div class="grid grid-cols-1 gap-4">
                        <label class="relative flex cursor-pointer rounded-lg border bg-white p-4 shadow-sm focus:outline-none transition-colors" 
                               :class="role === 'buyer' ? 'border-brand-500 ring-1 ring-brand-500' : 'border-gray-300 hover:bg-gray-50'">
                            <input type="radio" name="role" value="buyer" x-model="role" class="sr-only">
                            <span class="flex flex-1">
                                <span class="flex flex-col">
                                    <span class="block text-sm font-medium text-gray-900">{{ __('auth.buy') }}</span>
                                    <span class="mt-1 flex items-center text-xs text-gray-500">{{ __('auth.buy_description') }}</span>
                                </span>
                            </span>
                            <svg class="h-5 w-5 text-brand-600 transition-opacity" :class="role === 'buyer' ? 'opacity-100' : 'opacity-0'" viewBox="0 0 20 20" fill="currentColor">
                                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd" />
                            </svg>
                        </label>
                        <label class="relative flex cursor-pointer rounded-lg border bg-white p-4 shadow-sm focus:outline-none transition-colors"
                               :class="role === 'seller' ? 'border-brand-500 ring-1 ring-brand-500' : 'border-gray-300 hover:bg-gray-50'">
                            <input type="radio" name="role" value="seller" x-model="role" class="sr-only">
                            <span class="flex flex-1">
                                <span class="flex flex-col">
                                    <span class="block text-sm font-medium text-gray-900">{{ __('auth.sell') }}</span>
                                    <span class="mt-1 flex items-center text-xs text-gray-500">{{ __('auth.open_store') }}</span>
                                </span>
                            </span>
                            <svg class="h-5 w-5 text-brand-600 transition-opacity" :class="role === 'seller' ? 'opacity-100' : 'opacity-0'" viewBox="0 0 20 20" fill="currentColor">
                                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd" />
                            </svg>
                        </label>
                        <label class="relative flex cursor-pointer rounded-lg border bg-white p-4 shadow-sm focus:outline-none transition-colors"
                               :class="role === 'buyer_seller' ? 'border-brand-500 ring-1 ring-brand-500' : 'border-gray-300 hover:bg-gray-50'">
                            <input type="radio" name="role" value="buyer_seller" x-model="role" class="sr-only">
                            <span class="flex flex-1"><span class="flex flex-col"><span class="block text-sm font-medium text-gray-900">{{ __('auth.buy_and_sell') }}</span><span class="mt-1 flex items-center text-xs text-gray-500">{{ __('auth.buy_and_sell_description') }}</span></span></span>
                            <svg class="h-5 w-5 text-brand-600 transition-opacity" :class="role === 'buyer_seller' ? 'opacity-100' : 'opacity-0'" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd" /></svg>
                        </label>
                    </div>
                </div>

                <div>
                    <label for="reg-name" class="block text-sm font-medium text-gray-700 mb-1.5">{{ __('auth.full_name') }}</label>
                    <input id="reg-name" name="name" type="text" value="{{ old('name') }}" required class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-brand-500 focus:border-brand-500 transition-shadow bg-gray-50 focus:bg-white text-gray-900">
                </div>
                
                <div x-show="role === 'seller' || role === 'buyer_seller'" x-cloak x-transition>
                    <label for="company_name" class="block text-sm font-medium text-gray-700 mb-1.5">{{ __('auth.store_name') }}</label>
                    <input id="company_name" name="company_name" type="text" value="{{ old('company_name') }}" :required="role === 'seller' || role === 'buyer_seller'" class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-brand-500 focus:border-brand-500 transition-shadow bg-gray-50 focus:bg-white text-gray-900">
                </div>

                <div>
                    <label for="reg-email" class="block text-sm font-medium text-gray-700 mb-1.5">{{ __('auth.email_address') }}</label>
                    <input id="reg-email" name="email" type="email" value="{{ old('email') }}" required class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-brand-500 focus:border-brand-500 transition-shadow bg-gray-50 focus:bg-white text-gray-900">
                </div>

                <div>
                    <label for="phone" class="block text-sm font-medium text-gray-700 mb-1.5">{{ __('auth.phone_number') }} <span class="text-gray-400 font-normal">({{ __('auth.optional') }})</span></label>
                    <input id="phone" name="phone" type="tel" value="{{ old('phone') }}" class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-brand-500 focus:border-brand-500 transition-shadow bg-gray-50 focus:bg-white text-gray-900">
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label for="reg-country" class="block text-sm font-medium text-gray-700 mb-1.5">{{ __('marketplace.country') }} <span class="text-red-500">*</span></label>
                        <input id="reg-country-search" type="search" placeholder="{{ __('marketplace.search_country') }}" data-country-search-for="reg-country" autocomplete="off" class="w-full mb-2 px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-brand-500 focus:border-brand-500 transition-shadow bg-gray-50 focus:bg-white text-gray-900">
                        <select id="reg-country" name="country" required class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-brand-500 focus:border-brand-500 transition-shadow bg-gray-50 focus:bg-white text-gray-900">
                            <option value="">{{ __('marketplace.select_country') }}</option>
                            @foreach($countries as $code => $name)
                                <option value="{{ $code }}" data-country-label="{{ \Illuminate\Support\Str::lower($code.' '.$name) }}" @selected(old('country') === $code)>{{ $code }} · {{ $name }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div>
                        <label for="reg-city" class="block text-sm font-medium text-gray-700 mb-1.5">{{ __('marketplace.city') }} <span x-show="role === 'seller' || role === 'buyer_seller'" class="text-red-500">*</span><span x-show="role === 'buyer'" class="text-gray-400 font-normal">({{ __('auth.optional') }})</span></label>
                        <input id="reg-city" name="city" type="text" value="{{ old('city') }}" :required="role === 'seller' || role === 'buyer_seller'" class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-brand-500 focus:border-brand-500 transition-shadow bg-gray-50 focus:bg-white text-gray-900">
                    </div>
                </div>

                <div x-show="role === 'seller' || role === 'buyer_seller'" x-cloak x-transition class="space-y-4">
                    <div class="rounded-xl border border-brand-100 bg-brand-50/50 p-4">
                        <h2 class="text-sm font-semibold text-gray-900">{{ __('auth.store_location') }}</h2>
                        <p class="mt-1 text-xs text-gray-600">{{ __('auth.store_location_help') }}</p>
                        <label for="reg-address" class="mt-4 block text-sm font-medium text-gray-700 mb-1.5">{{ __('auth.store_address') }} <span class="text-red-500">*</span></label>
                        <textarea id="reg-address" name="address" rows="3" :required="role === 'seller' || role === 'buyer_seller'" class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-brand-500 focus:border-brand-500 transition-shadow bg-gray-50 focus:bg-white text-gray-900">{{ old('address') }}</textarea>
                        <div class="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label for="reg-region" class="block text-sm font-medium text-gray-700 mb-1.5">{{ __('marketplace.region') }} <span class="text-gray-400 font-normal">({{ __('auth.optional') }})</span></label>
                                <input id="reg-region" name="region" type="text" value="{{ old('region') }}" class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-brand-500 focus:border-brand-500 transition-shadow bg-gray-50 focus:bg-white text-gray-900">
                            </div>
                            <div>
                                <label for="reg-postal-code" class="block text-sm font-medium text-gray-700 mb-1.5">{{ __('marketplace.postal_code') }} <span class="text-gray-400 font-normal">({{ __('auth.optional') }})</span></label>
                                <input id="reg-postal-code" name="postal_code" type="text" value="{{ old('postal_code') }}" maxlength="32" class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-brand-500 focus:border-brand-500 transition-shadow bg-gray-50 focus:bg-white text-gray-900">
                            </div>
                        </div>
                        <label for="sales-country-codes" class="mt-4 block text-sm font-medium text-gray-700 mb-1.5">{{ __('auth.sales_countries') }} <span class="text-red-500">*</span></label>
                        <p class="mb-2 text-xs text-gray-600">{{ __('auth.sales_countries_help') }}</p>
                        <select id="sales-country-codes" name="sales_country_codes[]" multiple size="6" :required="role === 'seller' || role === 'buyer_seller'" class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-brand-500 focus:border-brand-500 transition-shadow bg-gray-50 focus:bg-white text-gray-900">
                            @foreach($countries as $code => $name)
                                <option value="{{ $code }}" @selected(in_array($code, old('sales_country_codes', []), true))>{{ $code }} · {{ $name }}</option>
                            @endforeach
                        </select>
                    </div>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label for="reg-password" class="block text-sm font-medium text-gray-700 mb-1.5">{{ __('auth.password') }}</label>
                        <input id="reg-password" name="password" type="password" required autocomplete="new-password" class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-brand-500 focus:border-brand-500 transition-shadow bg-gray-50 focus:bg-white text-gray-900">
                    </div>
                    <div>
                        <label for="password_confirmation" class="block text-sm font-medium text-gray-700 mb-1.5">{{ __('auth.confirm_password') }}</label>
                        <input id="password_confirmation" name="password_confirmation" type="password" required autocomplete="new-password" class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-brand-500 focus:border-brand-500 transition-shadow bg-gray-50 focus:bg-white text-gray-900">
                    </div>
                </div>

                <div class="pt-2">
                    <button type="submit" class="w-full py-3 px-4 rounded-lg bg-brand-600 hover:bg-brand-700 text-white font-medium focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-500 transition-colors shadow-sm">
                    {{ __('auth.create_account') }}
                    </button>
                </div>
                <p class="text-xs text-center text-gray-500 mt-4">
                    {{ __('auth.terms_notice') }}
                </p>
            </form>
        </div>
        <div class="absolute top-4 right-4">@include('partials.locale-selector')</div>
    </div>
</body>
<script>document.querySelectorAll('[data-country-search-for]').forEach(input=>{const select=document.getElementById(input.dataset.countrySearchFor);if(!select)return;input.addEventListener('input',()=>{const term=input.value.trim().toLowerCase();[...select.options].forEach(option=>{option.hidden=term!==''&&!option.dataset.countryLabel?.includes(term);});});});</script>
</html>
