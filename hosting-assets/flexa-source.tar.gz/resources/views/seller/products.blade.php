@extends('seller.layout')
@section('title', __('seller.listings'))
@section('content')
<section class="page-head split">
    <div><p class="eyebrow">{{ __('seller.catalog') }}</p><h1>{{ __('seller.your_listings') }}</h1><p>{{ __('seller.listings_private') }}</p></div>
    <a class="button" href="{{ route('seller.product-create') }}">{{ __('seller.create_listing') }}</a>
</section>
<section class="panel table-wrap">
    <table>
        <thead><tr><th>{{ __('marketplace.product') }}</th><th>{{ __('marketplace.price') }}</th><th>{{ __('marketplace.inventory') }}</th><th>{{ __('seller.lifecycle') }}</th><th></th></tr></thead>
        <tbody>
        @forelse($products as $product)
            <tr>
                <td><strong>{{ $product->product_name }}</strong><small>{{ $product->category?->display_name ?? __('ui.uncategorized') }}</small></td>
                <td>{{ number_format($product->product_price, 2) }}</td>
                <td>{{ $product->product_stock }}</td>
                <td><span class="badge {{ $product->status === 'Active' ? 'success':'' }}">{{ $product->status === 'Active' ? __('ui.published') : __('ui.unavailable') }}</span><small>{{ $product->availabilityCountries->count().' '.__('marketplace.select_countries') }}</small></td>
                <td><a class="text-link" href="{{ route('seller.product-edit', $product) }}">{{ __('common.edit') }}</a></td>
            </tr>
        @empty
            <tr><td colspan="5"><div class="empty compact"><h3>{{ __('ui.no_listings') }}</h3><p>{{ __('ui.create_draft') }}</p><a class="button" href="{{ route('seller.product-create') }}">{{ __('seller.create_listing') }}</a></div></td></tr>
        @endforelse
        </tbody>
    </table>
</section>
{{ $products->links() }}
@endsection