@extends('seller.layout')
@section('title', $product ? __('seller.edit_listing') : __('seller.create_listing'))
@section('content')
<link rel="stylesheet" href="{{ asset('custom/seller-product-form.css') }}">
<link rel="stylesheet" href="{{ asset('custom/category-search.css') }}">
<section class="page-head">
    <p class="eyebrow">{{ __('seller.catalog') }}</p>
    <h1>{{ $product ? __('seller.edit_listing') : __('seller.create_listing') }}</h1>
    <p>{{ __('seller.listing_details_pending') }}</p>
</section>
<form class="panel listing-form" action="{{ $product ? route('seller.product-update', $product) : route('seller.product-store') }}" method="post" enctype="multipart/form-data" aria-describedby="form-note">
    @csrf
    @if($product) @method('patch') @endif

    <fieldset>
        <legend>{{ __('seller.wholesale_details') }}</legend>
        <p class="help">{{ __('seller.wholesale_only_help') }}</p>
        <div class="form-grid">
            <label>{{ __('seller.product_name') }}<input name="product_name" required value="{{ old('product_name', $product->product_name ?? '') }}" placeholder="{{ __('seller.name_product') }}">@error('product_name')<small class="error">{{ $message }}</small>@enderror</label>
            <label class="category-picker">
                <span>{{ __('seller.select_category') }}</span>
                <span class="category-search-control">
                    <input id="seller-category-search" type="search" data-category-search-for="seller-category-select" placeholder="{{ __('marketplace.category_search_placeholder') }}" autocomplete="off">
                    <button type="button" class="category-search-button" data-category-search-button aria-label="{{ __('marketplace.search_category_button') }}"><i class="fas fa-search" aria-hidden="true"></i><span>{{ __('marketplace.search_category_button') }}</span></button>
                </span>
                <select id="seller-category-select" name="category_id" required><option value="">{{ __('seller.select_category') }}</option>@foreach($categories as $category)<option value="{{ $category->id }}" data-category-label="{{ \Illuminate\Support\Str::lower($category->searchable_label) }}" @selected(old('category_id', $product->category_id ?? '') == $category->id)>{{ $category->display_name }}</option>@endforeach</select>
                <small class="help category-empty-message" data-category-empty hidden>{{ __('marketplace.no_category_match') }}</small>
                @error('category_id')<small class="error">{{ $message }}</small>@enderror
            </label>
            <label>{{ __('seller.unit_id') }}<input name="unit_id" type="number" min="1" required value="{{ old('unit_id', $product->unit_id ?? '') }}">@error('unit_id')<small class="error">{{ $message }}</small>@enderror</label>
            <label>{{ __('seller.sku') }}<input name="sku" maxlength="100" value="{{ old('sku', $product->sku ?? '') }}" placeholder="{{ __('seller.sku_placeholder') }}">@error('sku')<small class="error">{{ $message }}</small>@enderror</label>
            <label>{{ __('marketplace.price') }}<input name="product_price" type="number" min="0" step="0.01" required value="{{ old('product_price', $product->product_price ?? '') }}">@error('product_price')<small class="error">{{ $message }}</small>@enderror</label>
            <label>{{ __('seller.minimum_order_quantity') }}<input name="minimum_order_quantity" type="number" min="1" required value="{{ old('minimum_order_quantity', $product->minimum_order_quantity ?? 1) }}">@error('minimum_order_quantity')<small class="error">{{ $message }}</small>@enderror</label>
            <label>{{ __('seller.wholesale_unit_type') }}<select name="wholesale_unit_type" required>@foreach(['box', 'case', 'carton', 'pallet', 'bundle', 'lot'] as $unitType)<option value="{{ $unitType }}" @selected(old('wholesale_unit_type', $product->wholesale_unit_type ?? 'box') === $unitType)>{{ __('seller.unit_'.$unitType) }}</option>@endforeach</select>@error('wholesale_unit_type')<small class="error">{{ $message }}</small>@enderror</label>
            <label>{{ __('seller.available_quantity') }}<input name="product_stock" type="number" min="0" required value="{{ old('product_stock', $product->product_stock ?? 0) }}">@error('product_stock')<small class="error">{{ $message }}</small>@enderror</label>
        </div>
        <label>{{ __('seller.description') }}<textarea name="product_short_description" rows="5">{{ old('product_short_description', $product->product_short_description ?? '') }}</textarea></label>
    </fieldset>

    <fieldset class="availability-panel">
        <legend>{{ __('marketplace.stock_location') }}</legend>
        <p class="help">{{ __('seller.profile_location_locked') }}</p>
        @php($profileCountry = \App\Support\MarketplaceCountry::details($vendor->user->country ?? ''))
        <div class="profile-location-summary">
            <strong>{{ $profileCountry['flag'] ?? '' }} {{ $vendor->user->country ?? '—' }} · {{ $profileCountry['name'] ?? ($vendor->user->country ?? '—') }}</strong>
            <span>{{ $vendor->city ?: ($vendor->user->city ?: '—') }}{{ $vendor->region ? ', '.$vendor->region : '' }}{{ $vendor->postal_code ? ' · '.$vendor->postal_code : '' }}</span>
            <small>{{ __('seller.profile_address_saved') }}</small>
        </div>
    </fieldset>

    <fieldset class="availability-panel">
        <legend>{{ __('marketplace.sales_availability') }}</legend>
        <p class="help">{{ __('seller.profile_sales_locked') }}</p>
        <div class="profile-country-chips" aria-label="{{ __('marketplace.sales_availability') }}">
            @forelse($vendor->availabilityCountries as $country)
                @php($countryDetails = \App\Support\MarketplaceCountry::details($country->code))
                <span class="chip selected">{{ $countryDetails['flag'] ?? '' }} {{ $country->code }} · {{ $countryDetails['name'] ?? $country->name }}</span>
            @empty
                <small class="error">{{ __('seller.profile_sales_missing') }}</small>
            @endforelse
        </div>
    </fieldset>

    <fieldset class="availability-panel">
        <legend>{{ __('seller.shipping_options') }}</legend>
        <p class="help">{{ __('seller.shipping_options_help') }}</p>
        <div class="form-grid">
            <label class="choice"><input type="checkbox" name="ships_internationally" value="1" @checked(old('ships_internationally', $product->ships_internationally ?? false))> {{ __('seller.ships_internationally') }}</label>
            <label class="choice"><input type="checkbox" name="offers_local_delivery" value="1" @checked(old('offers_local_delivery', $product->offers_local_delivery ?? false))> {{ __('seller.offers_local_delivery') }}</label>
            <label class="choice"><input type="checkbox" name="offers_warehouse_pickup" value="1" @checked(old('offers_warehouse_pickup', $product->offers_warehouse_pickup ?? false))> {{ __('seller.offers_warehouse_pickup') }}</label>
            <label class="choice"><input type="checkbox" name="offers_seller_delivery" value="1" @checked(old('offers_seller_delivery', $product->offers_seller_delivery ?? false))> {{ __('seller.offers_seller_delivery') }}</label>
            <label class="choice"><input type="checkbox" name="offers_marketplace_logistics" value="1" @checked(old('offers_marketplace_logistics', $product->offers_marketplace_logistics ?? true))> {{ __('seller.offers_marketplace_logistics') }}</label>
            <label>{{ __('marketplace.delivery') }}<input name="delivery_charge" type="number" min="0" step="0.01" required value="{{ old('delivery_charge', $product->delivery_charge ?? 0) }}">@error('delivery_charge')<small class="error">{{ $message }}</small>@enderror</label>
            <label>{{ __('seller.delivery_time') }}<input name="delivery_duration" type="number" min="1" required value="{{ old('delivery_duration', $product->delivery_duration ?? 1) }}">@error('delivery_duration')<small class="error">{{ $message }}</small>@enderror</label>
            <label>{{ __('seller.delivery_unit') }}<select name="delivery_duration_unit">@foreach(['Days','Weeks','Months','Year'] as $unit)<option @selected(old('delivery_duration_unit', $product->delivery_duration_unit ?? 'Days') === $unit)>{{ $unit }}</option>@endforeach</select></label>
            <label class="choice"><input type="checkbox" name="is_delivery_free" value="1" @checked(old('is_delivery_free', $product->is_delivery_free ?? false))> {{ __('seller.free_shipping') }}</label>
        </div>
    </fieldset>

    <fieldset class="availability-panel">
        <legend>{{ __('seller.quantity_price_tiers') }}</legend>
        <p class="help">{{ __('seller.quantity_price_tiers_help') }}</p>
        <div id="price-tier-list">
            @php($priceTiers = old('price_tiers', $product?->priceTiers?->map(fn($tier) => ['min_quantity' => $tier->min_quantity, 'max_quantity' => $tier->max_quantity, 'unit_price' => $tier->unit_price])->all() ?? [['min_quantity' => 1, 'max_quantity' => 10, 'unit_price' => ''], ['min_quantity' => 11, 'max_quantity' => 50, 'unit_price' => '']]))
            @foreach($priceTiers as $index => $tier)
                <div class="form-grid price-tier" data-tier-row>
                    <label>{{ __('seller.minimum_quantity') }}<input name="price_tiers[{{ $index }}][min_quantity]" type="number" min="1" value="{{ $tier['min_quantity'] ?? '' }}"></label>
                    <label>{{ __('seller.maximum_quantity') }}<input name="price_tiers[{{ $index }}][max_quantity]" type="number" min="1" value="{{ $tier['max_quantity'] ?? '' }}"></label>
                    <label>{{ __('marketplace.price') }}<input name="price_tiers[{{ $index }}][unit_price]" type="number" min="0" step="0.01" value="{{ $tier['unit_price'] ?? '' }}"></label>
                    <button class="button secondary" type="button" data-remove-tier>{{ __('common.remove') }}</button>
                </div>
            @endforeach
        </div>
        <button class="button secondary" type="button" id="add-price-tier">{{ __('seller.add_price_tier') }}</button>
        @error('price_tiers')<small class="error">{{ $message }}</small>@enderror
        @error('price_tiers.*')<small class="error">{{ $message }}</small>@enderror
    </fieldset>

    @php($existingPhotoCount = $product?->media?->where('media_type', 'image')->count() ?? 0)
    <fieldset class="media-manager">
        <legend>{{ __('seller.sell_something') }}</legend>
        <div class="photo-heading">
            <h2>{{ __('seller.photos') }} <span class="required-dot" aria-hidden="true">●</span></h2>
            <span id="photo-count" class="photo-count" data-existing-photo-count="{{ $existingPhotoCount }}">({{ $existingPhotoCount }}/5)</span>
        </div>
        <div class="photo-actions">
            <label class="photo-action photo-action-gallery">
                <input id="gallery-photo-input" name="images[]" type="file" accept="image/jpeg,image/png,image/webp" multiple data-photo-input>
                <span class="photo-action-icon" aria-hidden="true"><i class="fas fa-images"></i></span>
                <span>{{ __('seller.gallery') }}</span>
            </label>
            <label class="photo-action photo-action-camera">
                <input id="camera-photo-input" name="images[]" type="file" accept="image/jpeg,image/png,image/webp" capture="environment" data-photo-input>
                <span class="photo-action-icon" aria-hidden="true"><i class="fas fa-camera"></i></span>
                <span>{{ __('seller.camera') }}</span>
            </label>
        </div>
        <p class="photo-upload-help">{{ __('seller.photo_limit_help') }}</p>
        <p id="photo-requirement" class="photo-requirement">{{ __('seller.photo_minimum_error') }}</p>
        @error('images')<small class="error">{{ $message }}</small>@enderror
        @error('images.*')<small class="error">{{ $message }}</small>@enderror
        <div id="new-photo-preview" class="photo-preview-grid" aria-live="polite"></div>
        <div class="photo-tips">
            <h3><span aria-hidden="true">📸</span> {{ __('seller.photo_tips_title') }}</h3>
            <ul>
                <li>{{ __('seller.photo_tip_natural_light') }}</li>
                <li>{{ __('seller.photo_tip_clean_background') }}</li>
                <li>{{ __('seller.photo_tip_all_angles') }}</li>
                <li>{{ __('seller.photo_tip_cover') }}</li>
            </ul>
        </div>
        <div class="video-upload-card">
            <div class="video-upload-heading">
                <span class="video-upload-icon" aria-hidden="true"><i class="fas fa-video"></i></span>
                <div>
                    <h2>{{ __('seller.add_video_title') }} <span class="optional-badge">{{ __('auth.optional') }}</span></h2>
                    <p>{{ __('seller.add_video_help') }}</p>
                </div>
            </div>
            <label class="video-dropzone" for="video-upload-input">
                <input id="video-upload-input" name="videos[]" type="file" accept="video/mp4,video/webm,video/quicktime" data-video-input>
                <span class="video-file-button">{{ __('seller.choose_video') }}</span>
                <span id="video-file-name" class="video-file-name">{{ __('seller.no_video_selected') }}</span>
                <small>{{ __('marketplace.video_file_help') }}</small>
            </label>
            @error('videos')<small class="error">{{ $message }}</small>@enderror
            @error('videos.*')<small class="error">{{ $message }}</small>@enderror
            <div id="new-video-preview" class="video-preview" hidden aria-live="polite">
                <video id="new-video-player" controls preload="metadata" aria-label="{{ __('marketplace.product_video') }}"></video>
                <div class="video-preview-footer">
                    <span id="video-selected-label">{{ __('seller.video_selected') }}</span>
                    <button id="remove-new-video" class="button secondary video-remove-button" type="button">{{ __('seller.remove_new_video') }}</button>
                </div>
            </div>
        </div>
        @if($product && $product->media->isNotEmpty())
            <div class="media-grid">
                @foreach($product->media as $media)
                    <article class="media-item">
                        @if($media->media_type === 'video')<video src="{{ $media->url }}" controls preload="metadata" aria-label="{{ __('marketplace.product_video') }}"></video>@else<img src="{{ $media->url }}" alt="{{ $media->original_name }}">@endif
                        <label class="choice"><input type="checkbox" name="remove_media[]" value="{{ $media->id }}"> {{ __('marketplace.remove_video') }}</label>
                        <label>{{ __('seller.media_order') }}<input type="number" min="0" name="media_order[{{ $media->id }}]" value="{{ $media->display_order }}"></label>
                    </article>
                @endforeach
            </div>
        @endif
    </fieldset>
    <p id="form-note" class="help">{{ __('seller.lifecycle_pending') }}</p>
    <button class="button" type="submit">{{ $product ? __('seller.save_changes') : __('seller.submit_listing') }}</button>
</form>
<script>
document.addEventListener('DOMContentLoaded', () => {
    const picker = document.querySelector('#country-picker');

    const search = document.querySelector('#country-search');
    search?.addEventListener('input', event => {
        const term = event.target.value.toLowerCase();
        document.querySelectorAll('.country-option').forEach(option => { option.hidden = !option.dataset.country.includes(term); });
    });

    const chips = document.querySelector('#selected-country-chips');
    const renderChips = () => {
        if (!chips) return;
        chips.innerHTML = '';
        document.querySelectorAll('.country-option input:checked').forEach(input => {
            const chip = document.createElement('span');
            chip.className = 'chip selected';
            chip.textContent = `${input.dataset.countryFlag || ''} ${input.value} · ${input.dataset.countryName}`;
            chips.appendChild(chip);
        });
    };
    document.querySelectorAll('.country-option input').forEach(input => input.addEventListener('change', renderChips));
    renderChips();

    document.querySelectorAll('[data-country-search-for]').forEach(input => {
        const select = document.getElementById(input.dataset.countrySearchFor);
        if (!select) return;
        input.addEventListener('input', () => {
            const term = input.value.trim().toLowerCase();
            [...select.options].forEach(option => { option.hidden = term !== '' && !option.dataset.countryLabel?.includes(term); });
        });
    });

    const normalizeCategorySearch = value => String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
    document.querySelectorAll('[data-category-search-for]').forEach(input => {
        const select = document.getElementById(input.dataset.categorySearchFor);
        const button = input.parentElement?.querySelector('[data-category-search-button]');
        const empty = input.closest('.category-picker')?.querySelector('[data-category-empty]');
        if (!select) return;
        const filterCategories = () => {
            const term = normalizeCategorySearch(input.value.trim());
            const options = [...select.options];
            let matches = 0;
            options.forEach(option => {
                const isPlaceholder = option.value === '';
                const matchesSearch = isPlaceholder || term === '' || normalizeCategorySearch(option.dataset.categoryLabel).includes(term);
                option.hidden = !matchesSearch;
                if (!isPlaceholder && matchesSearch) matches++;
            });
            if (empty) empty.hidden = matches > 0;
        };
        input.addEventListener('input', filterCategories);
        button?.addEventListener('click', () => {
            filterCategories();
            select.focus();
        });
    });

    let tierIndex = document.querySelectorAll('[data-tier-row]').length;
    document.querySelector('#add-price-tier')?.addEventListener('click', () => {
        const row = document.createElement('div');
        row.className = 'form-grid price-tier';
        row.dataset.tierRow = '';
        row.innerHTML = `<label>{{ __('seller.minimum_quantity') }}<input name="price_tiers[${tierIndex}][min_quantity]" type="number" min="1"></label><label>{{ __('seller.maximum_quantity') }}<input name="price_tiers[${tierIndex}][max_quantity]" type="number" min="1"></label><label>{{ __('marketplace.price') }}<input name="price_tiers[${tierIndex}][unit_price]" type="number" min="0" step="0.01"></label><button class="button secondary" type="button" data-remove-tier>{{ __('common.remove') }}</button>`;
        document.querySelector('#price-tier-list').appendChild(row);
        tierIndex++;
    });
    document.querySelector('#price-tier-list')?.addEventListener('click', event => {
        if (event.target.matches('[data-remove-tier]')) event.target.closest('[data-tier-row]')?.remove();
    });

    const photoInputs = [...document.querySelectorAll('[data-photo-input]')];
    const photoPreview = document.querySelector('#new-photo-preview');
    const photoCount = document.querySelector('#photo-count');
    const photoRequirement = document.querySelector('#photo-requirement');
    const existingPhotoCount = Number(photoCount?.dataset.existingPhotoCount || 0);
    let photoPreviewUrls = [];
    const renderPhotoUpload = () => {
        if (!photoCount || !photoPreview) return;
        const files = photoInputs.flatMap(input => [...(input.files || [])]);
        const total = existingPhotoCount + files.length;
        photoCount.textContent = `(${total}/5)`;
        photoCount.classList.toggle('photo-count-over', total > 5);
        if (photoRequirement) photoRequirement.hidden = total >= 2 && total <= 5;
        photoPreviewUrls.forEach(url => URL.revokeObjectURL(url));
        photoPreviewUrls = [];
        photoPreview.innerHTML = '';
        files.forEach((file, index) => {
            const item = document.createElement('article');
            item.className = 'photo-preview-item';
            const url = URL.createObjectURL(file);
            photoPreviewUrls.push(url);
            const image = document.createElement('img');
            image.src = url;
            image.alt = '';
            const label = document.createElement('span');
            label.textContent = index === 0 && existingPhotoCount === 0 ? '{{ __('seller.photo_cover_label') }}' : file.name;
            item.append(image, label);
            photoPreview.appendChild(item);
        });
    };
    photoInputs.forEach(input => input.addEventListener('change', renderPhotoUpload));
    renderPhotoUpload();

    const videoInput = document.querySelector('#video-upload-input');
    const videoPreview = document.querySelector('#new-video-preview');
    const videoPlayer = document.querySelector('#new-video-player');
    const videoFileName = document.querySelector('#video-file-name');
    const videoSelectedLabel = document.querySelector('#video-selected-label');
    const removeNewVideo = document.querySelector('#remove-new-video');
    let videoPreviewUrl = null;
    const clearVideoPreview = () => {
        if (videoPreviewUrl) URL.revokeObjectURL(videoPreviewUrl);
        videoPreviewUrl = null;
        if (videoPlayer) {
            videoPlayer.removeAttribute('src');
            videoPlayer.load();
        }
        if (videoPreview) videoPreview.hidden = true;
        if (videoFileName) videoFileName.textContent = '{{ __('seller.no_video_selected') }}';
    };
    videoInput?.addEventListener('change', () => {
        const file = videoInput.files?.[0];
        if (!file) {
            clearVideoPreview();
            return;
        }
        if (videoPreviewUrl) URL.revokeObjectURL(videoPreviewUrl);
        videoPreviewUrl = URL.createObjectURL(file);
        videoPlayer.src = videoPreviewUrl;
        videoFileName.textContent = file.name;
        videoSelectedLabel.textContent = '{{ __('seller.video_selected') }}';
        videoPreview.hidden = false;
    });
    removeNewVideo?.addEventListener('click', () => {
        if (videoInput) videoInput.value = '';
        clearVideoPreview();
    });
});
</script>
@endsection