@extends('seller.layout')

@section('title', __('seller.plans'))

@section('content')
    <section class="page-head seller-plans-head">
        <div>
            <p class="eyebrow">{{ __('seller.membership') }}</p>
            <h1>{{ __('seller.choose_plan') }}</h1>
            <p>{{ __('seller.plans_intro') }}</p>
        </div>
    </section>

    <section class="trial-banner" aria-label="{{ __('seller.free_trial') }}">
        <div class="trial-icon" aria-hidden="true"><i class="fas fa-gift"></i></div>
        <div>
            <strong>{{ __('seller.free_trial_title', ['days' => $trialDays]) }}</strong>
            <p>{{ __('seller.free_trial_copy') }}</p>
        </div>
        <span class="trial-badge">{{ __('seller.no_charge_today') }}</span>
    </section>

    <section class="plans-grid" aria-label="{{ __('seller.plans') }}">
        @foreach($plans as $plan)
            <article class="plan-card {{ $plan['recommended'] ? 'is-recommended' : '' }}">
                @if($plan['recommended'])
                    <span class="plan-ribbon">{{ __('seller.most_popular') }}</span>
                @endif
                <div class="plan-card-head">
                    <p class="plan-kicker">{{ __('seller.plan_'.$plan['key'].'_eyebrow') }}</p>
                    <h2>{{ __('seller.plan_'.$plan['key']) }}</h2>
                    <p>{{ __('seller.plan_'.$plan['key'].'_description') }}</p>
                </div>
                <div class="plan-price"><span>$</span>{{ number_format($plan['price']) }}<small>/ {{ __('seller.month') }}</small></div>
                <p class="plan-best-for"><strong>{{ __('seller.best_for') }}:</strong> {{ __('seller.plan_'.$plan['key'].'_best_for') }}</p>
                <ul class="plan-features">
                    @foreach($plan['features'] as $feature)
                        <li><i class="fas fa-check" aria-hidden="true"></i>{{ __('seller.feature_'.$feature) }}</li>
                    @endforeach
                </ul>
                <button class="button {{ $plan['recommended'] ? '' : 'secondary' }}" type="button" disabled>{{ __('seller.billing_activation_pending') }}</button>
            </article>
        @endforeach
    </section>

    <section class="panel plan-notes">
        <h2>{{ __('seller.why_these_plans') }}</h2>
        <div class="plan-notes-grid">
            <div><i class="fas fa-store" aria-hidden="true"></i><p><strong>{{ __('seller.analysis_simplicity_title') }}</strong>{{ __('seller.analysis_simplicity') }}</p></div>
            <div><i class="fas fa-chart-line" aria-hidden="true"></i><p><strong>{{ __('seller.analysis_growth_title') }}</strong>{{ __('seller.analysis_growth') }}</p></div>
            <div><i class="fas fa-shield-alt" aria-hidden="true"></i><p><strong>{{ __('seller.analysis_trust_title') }}</strong>{{ __('seller.analysis_trust') }}</p></div>
        </div>
    </section>
@endsection