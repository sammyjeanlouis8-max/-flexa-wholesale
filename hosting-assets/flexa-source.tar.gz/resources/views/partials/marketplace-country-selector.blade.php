@php($selectorId = $selectorId ?? 'marketplace-country')
@php($searchId = $searchId ?? $selectorId.'-search')
@auth
    <div class="country-selector country-selector-locked" aria-label="{{ __('marketplace.marketplace_country') }}">
        <span class="country-selector-heading"><span aria-hidden="true">◎</span>{{ __('marketplace.market') }}</span>
        <strong>{{ marketplace_country() }} · {{ marketplace_countries()[marketplace_country()] ?? marketplace_country() }}</strong>
        <small class="market-help">{{ __('marketplace.account_country_locked') }}</small>
    </div>
@else
    <form class="country-selector" action="{{ route('marketplace.country.update', marketplace_country_selection()) }}" method="post">
        @csrf
        <label for="{{ $searchId }}">{{ __('marketplace.marketplace_country') }}</label>
        <span class="country-selector-heading"><span aria-hidden="true">◎</span>{{ __('marketplace.market') }}</span>
        <input id="{{ $searchId }}" type="search" placeholder="{{ __('marketplace.search_country') }}" data-country-search-for="{{ $selectorId }}" autocomplete="off">
        <select id="{{ $selectorId }}" name="country" onchange="this.form.action=this.form.action.replace(/[^/]+$/, this.value); this.form.submit()" aria-label="{{ __('marketplace.marketplace_country') }}">
            <option value="all" @selected(marketplace_country_selection() === 'all')>{{ __('marketplace.all_countries') }}</option>
            @foreach(marketplace_countries() as $code => $name)
                <option value="{{ $code }}" data-country-label="{{ \Illuminate\Support\Str::lower($code.' '.$name) }}" @selected(marketplace_country_selection() === $code)>{{ $code }} · {{ $name }}</option>
            @endforeach
        </select>
        <div class="market-popular" aria-label="{{ __('marketplace.popular_markets') }}">
            @foreach(['US', 'CA', 'FR', 'HT', 'DO'] as $popularCode)
                @if(isset(marketplace_countries()[$popularCode]))
                    <button type="button" data-market-option="{{ $popularCode }}">{{ marketplace_countries()[$popularCode] }}</button>
                @endif
            @endforeach
        </div>
        <small class="market-help">{{ __('marketplace.market_selector_help') }}</small>
    </form>
@endauth