<form method="POST"
      action="{{ route('locale.update', ['locale' => current_locale()]) }}"
      class="locale-selector"
      aria-label="{{ __('common.select_language') }}">
    @csrf
    <label class="sr-only" for="locale-select-{{ md5(url()->current()) }}">{{ __('common.select_language') }}</label>
    <select id="locale-select-{{ md5(url()->current()) }}"
            name="locale_choice"
            aria-label="{{ __('common.select_language') }}"
            onchange="this.form.action=this.options[this.selectedIndex].dataset.url;this.form.submit()">
        @foreach(available_locales() as $code => $name)
            <option value="{{ $code }}"
                    data-url="{{ route('locale.update', ['locale' => $code]) }}"
                    @selected(current_locale() === $code)>
                {{ strtoupper($code) }} · {{ $name }}
            </option>
        @endforeach
    </select>
</form>