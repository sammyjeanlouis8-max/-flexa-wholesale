@extends('layouts.app')

@section('content')
<div class="container-fluid my-4">
    <div class="row page-titles mx-0">
        <div class="col-sm-6 p-md-0 mt-2 mt-sm-0 d-flex">
            <a href="{{ route('product.index') }}" class="btn btn-danger">
                <i class="fa fa-arrow-left"></i>
                {{ __('Back')
                }}
            </a>
        </div>
    </div>

    <div class="row">
        <div class="col-xl-7 col-xxl-7 col-lg-7 m-auto">
            <div class="card shadow rounded-12 border-0">
                <div class="card-header py-3 bg-primary">
                    <h2 class="card-title m-0 text-white">
                        {{ __('Edit_Product') }}
                    </h2>
                </div>
                <div class="card-body">
                    <div class="text-center mb-3">
                        <img width="50%" id="preview" src="{{ $product->thumbnailPath }}" alt="">
                    </div>
                    <x-form type="Update" method="true" route="product.update" updateId="{{ $product->id }}">
                        <label class="mb-1">{{ __('Name') }}</label>
                        <input name="name" class="form-control" type='text' placeholder="Category name"
                            value="{{ old('name') ?? $product->name }}" @role('store') readonly @endrole />
                        @error('name')
                        <span class="text-danger d-block">{{ $message }}</span>
                        @enderror

                        <!-- @role('root|admin')
                            <input name="price" type='hidden' value="{{ $product->price }}" />
                            <input name="discount_price" type='hidden' value="{{ $product->discount_price }}" />
                        @endrole -->

                        @role('store')

                            <label class="mb-1">{{ __('Price') }}</label>
                            <input name="price" type='text' class="form-control" placeholder="Product price"
                                value="{{ old('price') ?? $pivotData[0]->price }}" onkeypress="onlyNumber(event)" />
                            @error('price')
                            <span class="text-danger d-block">{{ $message }}</span>
                            @enderror

                            <label class="mb-1 mt-3">{{ __('Discount_Price') }}</label>
                            <input name="discount_price" type='text' class="form-control" placeholder="Discount Price"
                                value="{{ old('discount_price') ?? $pivotData[0]->discount_price }}"
                                onkeypress="onlyNumber(event)" />
                            @error('discount_price')
                            <span class="text-danger d-block">{{ $message }}</span>
                            @enderror

                            <label class="mb-1 mt-3">{{ __('Description') }}</label>
                            <textarea name="description" class="form-control mb-3"
                                placeholder="Product Description">{{$pivotData[0]->description}}</textarea>
                            @error('description')
                            <span class="text-danger d-block">{{ $message }}</span>
                            @enderror

                        @endrole

                        <input type="hidden" id="slug" name="slug" class="form-control input-default"
                            value="{{ old('slug') ?? $product->slug }}">


                        @role('root|admin')
                            <div class="d-none">
                                <label class="mb-1">Shop/Store</label>
                                <x-select name="store_id">
                                    @foreach ($stores as $store)
                                    <option value="{{ $store->id }}" <?php if($product->store_id == $store->id){echo
                                        "selected";} ?>>{{ $store->name }}</option>
                                    @endforeach
                                </x-select>
                            </div>

                        @endrole

                        @error('store_id')
                        <span class="text-danger d-block">{{ $message }}</span>
                        @enderror

                        <label class="mb-1">{{ __('Service') }}</label>
                        <select name="service_id" id="service_id" class="form-control mb-3" @role('store') disabled
                            @endrole>
                            @foreach ($services as $service)
                            <option value="{{ $service->id }}" {{ $product->service_id == $service->id ? 'selected' : ''
                                }}>
                                {{ $service->name }}</option>
                            @endforeach
                        </select>

                        <input type="hidden" id="service_id" name="service_id" class="form-control input-default"
                            value="{{ old('service_id') ?? $product->service_id }}">
                        <input type="hidden" id="variant_id" name="variant_id" class="form-control input-default"
                            value="{{ old('variant_id') ?? $product->variant_id }}">
                        @error('service_id')
                        <span class="text-danger d-block">{{ $message }}</span>
                        @enderror

                        <label class="mb-1">{{ __('Variant') }}</label>
                        <select name="variant_id" id="variant_id" class="form-control mb-3" @role('store') disabled
                            @endrole>
                            @foreach ($variants as $variant)
                            <option {{ $product->variant_id == $variant->id ? 'selected' : '' }}
                                value="{{ $variant->id }}">{{ $variant->name }}</option>
                            @endforeach
                        </select>
                        @error('variant_id')
                        <span class="text-danger d-block">{{ $message }}</span>
                        @enderror

                        @role('root|admin')
                            <label class="mb-1">{{ __('Price') }}</label>
                            <input name="price" type='text' class="form-control" placeholder="Product price"
                                value="{{ old('price') ?? $product->price }}" onkeypress="onlyNumber(event)" />
                            @error('price')
                            <span class="text-danger d-block">{{ $message }}</span>
                            @enderror

                            <label class="mb-1 mt-3">{{ __('Discount_Price') }}</label>
                            <input name="discount_price" type='text' class="form-control" placeholder="Discount Price"
                                value="{{ old('discount_price') ?? $product->discount_price }}"
                                onkeypress="onlyNumber(event)" />
                            @error('discount_price')
                            <span class="text-danger d-block">{{ $message }}</span>
                            @enderror

                            <label class="mb-1 mt-3">{{ __('Description') }}</label>
                            <textarea name="description" class="form-control mb-3"
                                placeholder="Product Description">{{$product->description}}</textarea>
                            @error('description')
                            <span class="text-danger d-block">{{ $message }}</span>
                            @enderror

                            <label class="mb-1">{{ __('Thumbnail') }}</label>
                            <x-input-file name="image" id="image" type="file" />
                            @error('image')
                            <span class="text-danger d-block">{{ $message }}</span>
                            @enderror

                            <div class="form-group">
                                <label for="active" class="mr-2">
                                    <input type="radio" id="active" name="active" {{ $product->is_active ? 'checked' : '' }}
                                    value="1"> {{ __('Active') }}
                                </label>
                                <label for="in_active">
                                    <input type="radio" id="in_active" name="active" {{ !$product->is_active ? 'checked' :
                                    '' }} value="0">
                                    {{ __('Inactive') }}
                                </label>
                            </div>
                        @endrole

                    </x-form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
    function onlyNumber(evt) {
        var chars = String.fromCharCode(evt.which);
        if (!(/[0-9.]/.test(chars))) {
            evt.preventDefault();
        }
    };

    $('#name').keyup(function () {
        $('#slug').val($(this).val().toLowerCase().split(',').join('').replace(/\s/g, "-"));
    });

    $('select[name="service_id"]').on('change', function () {
        var serviceId = $(this).val();
        if (serviceId) {
            $.ajax({
                url: "{{url('/services/variants')}}/" + serviceId,
                type: "GET",
                dataType: "json",
                success: function (data) {
                    //console.log(data);
                    $('select[name="variant_id"]').empty();
                    $.each(data, function (key, value) {
                        $('select[name="variant_id"]').append('<option value="' + value.id +
                            '">' + value.name + '</option>');
                    });
                }
            });
        } else {
            $('select[name="variant_id"]').empty();
        }
    });
</script>
@endpush