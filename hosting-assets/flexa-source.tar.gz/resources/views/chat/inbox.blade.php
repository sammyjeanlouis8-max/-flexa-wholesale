<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat Interface</title>
    <link rel="stylesheet" href="{{asset('custom/chat/bootstrap.min.css')}}" />
    <link rel="stylesheet" href="{{asset('custom/chat.css')}}">
    <link rel="stylesheet" href="{{asset('back/plugins/fontawesome-free/css/all.min.css')}}">    <link rel="stylesheet" href="{{asset('custom/toastr.css')}}">

</head>

<body>

    <div class="offcanvas offcanvas-start chat-list" tabindex="-1" id="chatListOffcanvas">
        <div class="offcanvas-header">
            <h5 class="offcanvas-title">Contacts</h5>
            <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body">
        </div>
    </div>

    <div class="container-fluid">
        <div class="row chat-container">
            <div class="col-md-3 col-6 chat-list p-0">
                <!-- Chat items will be populated here -->
            </div>

            <div class="col-md-9 col-6 chat-main" id="chatBox">
                <div class="chat-header">
                    <div class="d-flex">
                        <img id="chatHeaderPic" src="{{asset('uploads/users/user.png')}}" alt="Profile Picture"
                            class="profile-pic">
                        <div id="chatHeaderName" class="contact-name">Select a Contact</div>
                    </div>
                    <div>
                        <button class="btn d-md-none list" type="button" data-bs-toggle="offcanvas"
                            data-bs-target="#chatListOffcanvas" aria-controls="chatListOffcanvas">
                            Chat lists
                        </button>
                    </div>
                </div>
                <div id="chatMessages" class="messages">
                    <!-- Messages will be appended here -->
                </div>

                <form id="messageForm">
                    <input type="hidden" id="contactPhone" name="contactPhone">

                    <div class="message-input">
                        <input type="text" id="messageInput" placeholder="Type a message">
                        <button id="sendMessage">
                            <i class="fas fa-paper-plane"></i>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="{{asset('custom/chat/jquery.js')}}"></script>
    <script src="{{asset('custom/chat/poper.min.js')}}"></script>
    <script src="{{asset('custom/chat/bootstrap.min.js')}}"></script>
    <script src="{{asset('custom/toastr.js')}}"></script>

    <script type="module" src="{{asset('custom/chat.js')}}"></script>
</body>

</html>