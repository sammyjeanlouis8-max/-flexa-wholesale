<?php

return [
    'active' => 'Activo',
    'inactive' => 'Inactivo',
    'pending' => 'Pendiente',
    'processing' => 'En proceso',
    'accepted' => 'Aceptado',
    'shipped' => 'Enviado',
    'delivered' => 'Entregado',
    'cancelled' => 'Cancelado',
    'completed' => 'Completado',
    'paid' => 'Pagado',
    'unpaid' => 'No pagado',
    'refunded' => 'Reembolsado',
    'failed' => 'Fallido',
    'out_of_stock' => 'Agotado',
];