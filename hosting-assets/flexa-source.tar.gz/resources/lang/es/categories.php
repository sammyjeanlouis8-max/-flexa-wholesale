<?php

return [
    'food-beverages' => 'Alimentos y Bebidas',
    'beauty-perfume-personal-care' => 'Belleza, Perfumes y Cuidado Personal',
    'fashion-clothing' => 'Moda y Ropa',
    'electronics-phones' => 'Electrónica y Teléfonos',
    'home-kitchen' => 'Hogar y Cocina',
    'home-appliances' => 'Electrodomésticos',
    'automotive-parts' => 'Automóviles y Repuestos',
    'construction-hardware' => 'Construcción y Ferretería',
    'agriculture-livestock' => 'Agricultura y Ganadería',
    'baby-children' => 'Bebés y Niños',
    'health-wellness' => 'Salud y Bienestar',
    'jewelry-accessories' => 'Joyas y Accesorios',
    'sports-leisure' => 'Deporte y Ocio',
    'professional-industrial-supplies' => 'Suministros Profesionales e Industriales',
    'used-products' => 'Productos Usados',
    'other-products' => 'Otros Productos',
];