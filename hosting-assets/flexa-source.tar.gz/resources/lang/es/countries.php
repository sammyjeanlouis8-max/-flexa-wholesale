<?php

return [
    'united_states' => 'Estados Unidos', 'canada' => 'Canadá', 'haiti' => 'Haití', 'france' => 'Francia',
    'dominican_republic' => 'República Dominicana', 'mexico' => 'México', 'united_kingdom' => 'Reino Unido',
    'germany' => 'Alemania', 'spain' => 'España', 'italy' => 'Italia', 'brazil' => 'Brasil',
    'colombia' => 'Colombia', 'argentina' => 'Argentina', 'chile' => 'Chile', 'jamaica' => 'Jamaica',
    'puerto_rico' => 'Puerto Rico', 'nigeria' => 'Nigeria', 'ghana' => 'Ghana', 'south_africa' => 'Sudáfrica',
    'india' => 'India', 'japan' => 'Japón', 'china' => 'China', 'australia' => 'Australia',
];