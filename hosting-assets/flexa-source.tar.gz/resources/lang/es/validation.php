<?php

return [
    'required' => 'El campo :attribute es obligatorio.',
    'email' => 'El campo :attribute debe ser una dirección de correo válida.',
    'min' => 'El campo :attribute debe tener al menos :min caracteres.',
    'confirmed' => 'La confirmación de :attribute no coincide.',
    'unique' => 'El campo :attribute ya está en uso.',
    'numeric' => 'El campo :attribute debe ser un número.',
    'in' => 'El valor seleccionado para :attribute no es válido.',
    'submission_errors' => 'Se produjeron errores al enviar el formulario.',
    'custom' => [
        'price_tier_values' => 'Cada nivel necesita una cantidad mínima y un precio unitario no negativo.',
        'price_tier_range' => 'La cantidad máxima debe ser mayor o igual que la cantidad mínima.',
        'price_tier_overlap' => 'Los rangos de precios no pueden solaparse.',
    ],
    'attributes' => [
        'email' => 'correo electrónico',
        'password' => 'contraseña',
        'product_name' => 'nombre del producto',
        'quantity' => 'cantidad',
        'delivery_address' => 'dirección de entrega',
    ],
];