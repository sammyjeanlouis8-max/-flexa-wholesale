<?php

return [
    'all_set' => '¡Todo está listo!',
    'active_description' => 'Tu panel está activo. Los informes y las herramientas aparecerán a medida que crezca la actividad de tu cuenta.',
    'explore_marketplace' => 'Explorar el marketplace',
];