<?php

return [
    'active' => 'Aktif',
    'inactive' => 'Inaktif',
    'pending' => 'An atant',
    'processing' => 'Ap trete',
    'accepted' => 'Aksepte',
    'shipped' => 'Voye',
    'delivered' => 'Livre',
    'cancelled' => 'Anile',
    'completed' => 'Konplete',
    'paid' => 'Peye',
    'unpaid' => 'Poko peye',
    'refunded' => 'Ranbouse',
    'failed' => 'Echwe',
    'out_of_stock' => 'Pa gen nan stòk',
];