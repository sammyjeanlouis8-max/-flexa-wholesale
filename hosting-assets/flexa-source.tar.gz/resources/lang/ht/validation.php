<?php

return [
    'required' => 'Chan :attribute la obligatwa.',
    'email' => ':attribute dwe yon adrès imèl ki valab.',
    'min' => ':attribute dwe gen omwen :min karaktè.',
    'confirmed' => 'Konfimasyon :attribute a pa menm.',
    'unique' => ':attribute sa a deja itilize.',
    'numeric' => ':attribute dwe yon nimewo.',
    'in' => ':attribute ou chwazi a pa valab.',
    'submission_errors' => 'Te gen erè nan enfòmasyon ou voye yo.',
    'custom' => [
        'price_tier_values' => 'Chak nivo pri dwe gen yon kantite minimòm ak yon pri inite ki pa negatif.',
        'price_tier_range' => 'Kantite maksimòm nan dwe pi gran oswa egal ak kantite minimòm nan.',
        'price_tier_overlap' => 'Zòn nivo pri yo pa dwe sipèpoze.',
    ],
    'attributes' => [
        'email' => 'adrès imèl',
        'password' => 'modpas',
        'product_name' => 'non pwodwi',
        'quantity' => 'kantite',
        'delivery_address' => 'adrès livrezon',
    ],
];