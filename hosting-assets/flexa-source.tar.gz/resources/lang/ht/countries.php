<?php

return [
    'united_states' => 'Etazini', 'canada' => 'Kanada', 'haiti' => 'Ayiti', 'france' => 'Lafrans',
    'dominican_republic' => 'Repiblik Dominikèn', 'mexico' => 'Meksik', 'united_kingdom' => 'Wayòm Ini',
    'germany' => 'Almay', 'spain' => 'Espay', 'italy' => 'Itali', 'brazil' => 'Brezil',
    'colombia' => 'Kolonbi', 'argentina' => 'Ajantin', 'chile' => 'Chili', 'jamaica' => 'Jamayik',
    'puerto_rico' => 'Pòtoriko', 'nigeria' => 'Nijerya', 'ghana' => 'Gana', 'south_africa' => 'Afrik di Sid',
    'india' => 'End', 'japan' => 'Japon', 'china' => 'Lachin', 'australia' => 'Ostrali',
];