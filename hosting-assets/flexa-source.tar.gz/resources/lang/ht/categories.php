<?php

return [
    'food-beverages' => 'Manje ak Bwason',
    'beauty-perfume-personal-care' => 'Bote, Pafen ak Swen Pèsonèl',
    'fashion-clothing' => 'Mòd ak Rad',
    'electronics-phones' => 'Elektwonik ak Telefòn',
    'home-kitchen' => 'Kay ak Kwizin',
    'home-appliances' => 'Aparèy Elektwomennaj',
    'automotive-parts' => 'Machin ak Pyès Detache',
    'construction-hardware' => 'Konstriksyon ak Brikolaj',
    'agriculture-livestock' => 'Agrikilti ak Elvaj',
    'baby-children' => 'Tibebe ak Timoun',
    'health-wellness' => 'Sante ak Byennèt',
    'jewelry-accessories' => 'Bijou ak Akseswa',
    'sports-leisure' => 'Espò ak Lwazi',
    'professional-industrial-supplies' => 'Founiti Pwofesyonèl ak Endistriyèl',
    'used-products' => 'Pwodwi Dezyèm Men',
    'other-products' => 'Lòt Pwodwi',
];