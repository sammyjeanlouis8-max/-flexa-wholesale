<?php

return [
    'active' => 'Active',
    'inactive' => 'Inactive',
    'pending' => 'Pending',
    'processing' => 'Processing',
    'accepted' => 'Accepted',
    'shipped' => 'Shipped',
    'delivered' => 'Delivered',
    'cancelled' => 'Cancelled',
    'completed' => 'Completed',
    'paid' => 'Paid',
    'unpaid' => 'Unpaid',
    'refunded' => 'Refunded',
    'failed' => 'Failed',
    'out_of_stock' => 'Out of stock',
];