<?php

return [
    'food-beverages' => 'Food & Beverages',
    'beauty-perfume-personal-care' => 'Beauty, Perfume & Personal Care',
    'fashion-clothing' => 'Fashion & Clothing',
    'electronics-phones' => 'Electronics & Phones',
    'home-kitchen' => 'Home & Kitchen',
    'home-appliances' => 'Home Appliances',
    'automotive-parts' => 'Automotive & Parts',
    'construction-hardware' => 'Construction & Hardware',
    'agriculture-livestock' => 'Agriculture & Livestock',
    'baby-children' => 'Baby & Children',
    'health-wellness' => 'Health & Wellness',
    'jewelry-accessories' => 'Jewelry & Accessories',
    'sports-leisure' => 'Sports & Leisure',
    'professional-industrial-supplies' => 'Professional & Industrial Supplies',
    'used-products' => 'Used Products',
    'other-products' => 'Other Products',
];