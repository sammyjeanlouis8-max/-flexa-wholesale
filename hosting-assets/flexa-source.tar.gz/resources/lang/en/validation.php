<?php

return [
    'required' => 'The :attribute field is required.',
    'email' => 'The :attribute must be a valid email address.',
    'min' => 'The :attribute must be at least :min characters.',
    'confirmed' => 'The :attribute confirmation does not match.',
    'unique' => 'The :attribute has already been taken.',
    'numeric' => 'The :attribute must be a number.',
    'in' => 'The selected :attribute is invalid.',
    'submission_errors' => 'There were errors with your submission.',
    'custom' => [
        'price_tier_values' => 'Each price tier needs a minimum quantity and a non-negative unit price.',
        'price_tier_range' => 'The maximum quantity must be greater than or equal to the minimum quantity.',
        'price_tier_overlap' => 'Price tier ranges cannot overlap.',
    ],
    'attributes' => [
        'email' => 'email address',
        'password' => 'password',
        'product_name' => 'product name',
        'quantity' => 'quantity',
        'delivery_address' => 'delivery address',
    ],
];