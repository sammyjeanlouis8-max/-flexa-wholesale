<?php

return [
    'food-beverages' => 'Alimentation & Boissons',
    'beauty-perfume-personal-care' => 'Beauté, Parfums & Soins personnels',
    'fashion-clothing' => 'Mode & Vêtements',
    'electronics-phones' => 'Électronique & Téléphones',
    'home-kitchen' => 'Maison & Cuisine',
    'home-appliances' => 'Appareils électroménagers',
    'automotive-parts' => 'Automobile & Pièces détachées',
    'construction-hardware' => 'Construction & Bricolage',
    'agriculture-livestock' => 'Agriculture & Élevage',
    'baby-children' => 'Bébé & Enfants',
    'health-wellness' => 'Santé & Bien-être',
    'jewelry-accessories' => 'Bijoux & Accessoires',
    'sports-leisure' => 'Sport & Loisirs',
    'professional-industrial-supplies' => 'Fournitures professionnelles & Industrielles',
    'used-products' => 'Produits d’occasion',
    'other-products' => 'Autres produits',
];