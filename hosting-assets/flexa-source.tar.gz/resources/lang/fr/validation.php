<?php

return [
    'required' => 'Le champ :attribute est obligatoire.',
    'email' => 'Le champ :attribute doit être une adresse e-mail valide.',
    'min' => 'Le champ :attribute doit contenir au moins :min caractères.',
    'confirmed' => 'La confirmation du champ :attribute ne correspond pas.',
    'unique' => 'La valeur du champ :attribute est déjà utilisée.',
    'numeric' => 'Le champ :attribute doit être un nombre.',
    'in' => 'La valeur sélectionnée pour :attribute est invalide.',
    'submission_errors' => 'Des erreurs se sont produites dans votre envoi.',
    'custom' => [
        'price_tier_values' => 'Chaque palier doit avoir une quantité minimale et un prix unitaire positif ou nul.',
        'price_tier_range' => 'La quantité maximale doit être supérieure ou égale à la quantité minimale.',
        'price_tier_overlap' => 'Les plages de tarifs ne peuvent pas se chevaucher.',
    ],
    'attributes' => [
        'email' => 'adresse e-mail',
        'password' => 'mot de passe',
        'product_name' => 'nom du produit',
        'quantity' => 'quantité',
        'delivery_address' => 'adresse de livraison',
    ],
];