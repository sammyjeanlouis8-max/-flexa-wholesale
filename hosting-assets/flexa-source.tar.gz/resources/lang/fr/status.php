<?php

return [
    'active' => 'Actif',
    'inactive' => 'Inactif',
    'pending' => 'En attente',
    'processing' => 'En traitement',
    'accepted' => 'Acceptée',
    'shipped' => 'Expédiée',
    'delivered' => 'Livrée',
    'cancelled' => 'Annulée',
    'completed' => 'Terminée',
    'paid' => 'Payée',
    'unpaid' => 'Non payée',
    'refunded' => 'Remboursée',
    'failed' => 'Échouée',
    'out_of_stock' => 'Rupture de stock',
];