<?php

return [
    'united_states' => 'États-Unis', 'canada' => 'Canada', 'haiti' => 'Haïti', 'france' => 'France',
    'dominican_republic' => 'République dominicaine', 'mexico' => 'Mexique', 'united_kingdom' => 'Royaume-Uni',
    'germany' => 'Allemagne', 'spain' => 'Espagne', 'italy' => 'Italie', 'brazil' => 'Brésil',
    'colombia' => 'Colombie', 'argentina' => 'Argentine', 'chile' => 'Chili', 'jamaica' => 'Jamaïque',
    'puerto_rico' => 'Porto Rico', 'nigeria' => 'Nigéria', 'ghana' => 'Ghana', 'south_africa' => 'Afrique du Sud',
    'india' => 'Inde', 'japan' => 'Japon', 'china' => 'Chine', 'australia' => 'Australie',
];