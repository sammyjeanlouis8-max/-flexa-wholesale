<?php

namespace Tests\Unit;

use App\Support\Locale;
use Tests\TestCase;

class LocalizationCatalogTest extends TestCase
{
    private const GROUPS = ['common', 'auth', 'marketplace', 'seller', 'admin', 'dashboard', 'status', 'validation', 'ui', 'categories'];
    private const REQUIRED_KEYS = [
        'common.language',
        'auth.buyer',
        'auth.seller',
        'auth.store_name',
        'marketplace.product',
        'marketplace.store',
        'marketplace.order',
        'marketplace.cart',
        'marketplace.checkout',
        'marketplace.payment',
        'marketplace.refund',
        'marketplace.inventory',
        'marketplace.delivery',
        'categories.beauty-perfume-personal-care',
        'categories.used-products',
        'seller.store_management',
        'admin.admin_management',
        'status.pending',
        'validation.required',
    ];

    public function test_every_supported_locale_has_the_complete_catalog_key_set(): void
    {
        $english = $this->catalogKeys('en');

        foreach (array_keys(Locale::supported()) as $locale) {
            $keys = $this->catalogKeys($locale);
            $this->assertSame($english, $keys, "{$locale} catalog keys differ from en.");
            $this->assertSame([], array_values(array_diff(self::REQUIRED_KEYS, $keys)), "{$locale} is missing required localization keys.");
        }
    }

    public function test_locale_normalization_is_allowlisted(): void
    {
        $this->assertSame('fr', Locale::normalize('fr-CA'));
        $this->assertSame('ht', Locale::normalize('HT_ht'));
        $this->assertSame('es', Locale::normalize('es-MX'));
        $this->assertNull(Locale::normalize('de'));
        $this->assertNull(Locale::normalize('../../en'));
    }

    public function test_public_signup_and_locale_selector_are_wired_for_localization(): void
    {
        $login = file_get_contents(resource_path('views/auth/login.blade.php'));
        $selector = file_get_contents(resource_path('views/partials/locale-selector.blade.php'));

        $this->assertStringContainsString('value="buyer_seller"', $login);
        $this->assertStringContainsString("route('locale.update'", $selector);
        $this->assertStringContainsString('@csrf', $selector);
    }

    public function test_core_localized_views_do_not_keep_old_hardcoded_labels(): void
    {
        foreach ([
            resource_path('views/auth/login.blade.php'),
            resource_path('views/marketplace/layout.blade.php'),
            resource_path('views/seller/layout.blade.php'),
        ] as $view) {
            $contents = file_get_contents($view);
            $this->assertStringNotContainsString('>Sign In<', $contents);
            $this->assertStringNotContainsString('>Create Account<', $contents);
            $this->assertStringNotContainsString('>Marketplace<', $contents);
        }
    }

    private function catalogKeys(string $locale): array
    {
        $keys = [];

        foreach (self::GROUPS as $group) {
            $messages = require resource_path("lang/{$locale}/{$group}.php");
            $this->flatten($messages, $group, $keys);
        }

        sort($keys);

        return $keys;
    }

    private function flatten(array $messages, string $prefix, array &$keys): void
    {
        foreach ($messages as $key => $value) {
            $path = "{$prefix}.{$key}";

            if (is_array($value)) {
                $this->flatten($value, $path, $keys);
                continue;
            }

            $keys[] = $path;
        }
    }
}