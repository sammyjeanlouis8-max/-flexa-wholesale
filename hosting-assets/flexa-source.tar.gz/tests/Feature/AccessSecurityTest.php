<?php

namespace Tests\Feature;

use App\Models\Permission;
use App\Models\Orderdetail;
use App\Models\Product;
use App\Models\CardDetail;
use App\Models\Order;
use App\Models\Rating;
use App\Models\Setting;
use App\Models\User;
use App\Models\Vendor;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Notification;
use Illuminate\Auth\Notifications\ResetPassword;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

class AccessSecurityTest extends TestCase
{
    use RefreshDatabase;

    public function test_public_registration_rejects_privileged_roles(): void
    {
        $this->postJson('/api/register', ['name' => 'Nope', 'email' => 'nope@example.test', 'password' => 'password', 'role' => 'owner'])
            ->assertStatus(422)->assertJsonPath('status', false);
        $this->assertDatabaseMissing('users', ['email' => 'nope@example.test']);
    }

    public function test_public_reset_never_changes_password(): void
    {
        $user = User::factory()->create(['password' => Hash::make('old-password')]);
        $this->postJson('/api/reset-password', ['email' => $user->email, 'new_password' => 'new-password', 'confirm_password' => 'new-password'])
            ->assertStatus(503)->assertJsonPath('status', false);
        $this->assertTrue(Hash::check('old-password', $user->fresh()->password));
    }

    public function test_inactive_user_cannot_login(): void
    {
        $user = User::factory()->create(['account_status' => 'inactive', 'password' => Hash::make('password')]);
        $this->postJson('/api/user-login', ['email' => $user->email, 'password' => 'password', 'use_for' => 'user'])->assertStatus(401);
    }

    public function test_unknown_legacy_role_is_denied_protected_access(): void
    {
        $unknown = User::factory()->create(['role_id' => 99, 'role' => null]);
        $this->actingAs($unknown)->get('/buyer/dashboard')->assertStatus(403);
    }

    public function test_role_and_permission_routes_are_denied(): void
    {
        $buyer = User::factory()->create();
        $this->actingAs($buyer)->get('/admin/dashboard')->assertStatus(403);
        $admin = User::factory()->create(['role' => 'admin']);
        $this->actingAs($admin)->get('/categories')->assertStatus(403);
    }

    public function test_owner_can_open_admin_management(): void
    {
        Setting::forceCreate(['app_name' => 'Flexa Wo Seller']);
        $owner = User::factory()->create(['role' => 'owner', 'is_primary_admin' => true]);
        $this->actingAs($owner)->get('/admin-management')->assertOk();
    }

    public function test_buyer_cannot_read_another_profile(): void
    {
        $buyer = User::factory()->create();
        $other = User::factory()->create();
        Sanctum::actingAs($buyer);
        $this->getJson('/api/user-profile/'.$other->id)->assertStatus(403);
    }

    public function test_buyer_cannot_read_another_order(): void
    {
        $buyer = User::factory()->create();
        $other = User::factory()->create();
        $order = Orderdetail::create(['user_id' => $other->id, 'payment_method' => 'cod', 'order_no' => 'ORDER-1',
            'delivery_address' => 'Address', 'sub_total' => '1', 'total_cost' => '1', 'date' => today(), 'time' => '10:00',
            'month' => 'January', 'year' => '2026']);
        Sanctum::actingAs($buyer);
        $this->getJson('/api/user-order-details/'.$order->id)->assertStatus(403);
    }

    public function test_seller_cannot_read_another_vendor_balance_or_cards(): void
    {
        $seller = User::factory()->create(['role' => 'seller']);
        Vendor::create(['user_id' => $seller->id]);
        $other = User::factory()->create(['role' => 'seller']);
        $otherVendor = Vendor::create(['user_id' => $other->id]);
        Sanctum::actingAs($seller);
        $this->getJson('/api/vendor-details/'.$otherVendor->id)->assertStatus(403);
        $this->getJson('/api/get-vendor-balance/'.$otherVendor->id)->assertStatus(403);
        $this->getJson('/api/card-details/vendor/'.$otherVendor->id)->assertStatus(403);
        $this->getJson('/api/get-vendor-tnx-statement/'.$otherVendor->id)->assertStatus(403);
        $card = CardDetail::forceCreate(['vendor_id' => $otherVendor->id, 'holder_name' => 'Other',
            'bank_name' => 'Bank', 'account_no' => '1234', 'cvc' => '123', 'expiry_month' => 1, 'expiry_year' => 2030]);
        $this->postJson('/api/withdraw-request', ['vendor_id' => $otherVendor->id, 'card_id' => $card->id,
            'amount' => 1, 'status' => 'Approved'])->assertStatus(403);
        $product = Product::forceCreate(['vendor_id' => $otherVendor->id, 'category_id' => 1, 'unit_id' => 1,
            'product_name' => 'Other Product', 'product_price' => 1, 'delivery_duration_unit' => 'Days', 'status' => 'Active']);
        $this->postJson('/api/delete-product/'.$product->id)->assertStatus(403);
    }

    public function test_seller_only_receives_its_lines_from_a_multi_vendor_order(): void
    {
        $sellerA = User::factory()->create(['role' => 'seller']);
        $vendorA = Vendor::create(['user_id' => $sellerA->id]);
        $sellerB = User::factory()->create(['role' => 'seller']);
        $vendorB = Vendor::create(['user_id' => $sellerB->id]);
        $buyer = User::factory()->create();
        $detail = Orderdetail::create(['user_id' => $buyer->id, 'payment_method' => 'cod', 'order_no' => 'MULTI-1',
            'delivery_address' => 'Address', 'sub_total' => '2', 'total_cost' => '2', 'date' => today(), 'time' => '10:00', 'month' => 'January', 'year' => '2026']);
        Order::create(['orderdetail_id' => $detail->id, 'vendor_id' => $vendorA->id, 'product_id' => 1, 'product_price' => 1, 'product_quantity' => 1, 'unit_total_price' => 1, 'status' => 'Pending']);
        $otherLine = Order::create(['orderdetail_id' => $detail->id, 'vendor_id' => $vendorB->id, 'product_id' => 2, 'product_price' => 1, 'product_quantity' => 1, 'unit_total_price' => 1, 'status' => 'Pending']);
        Sanctum::actingAs($sellerA);
        $this->getJson('/api/user-order-details/'.$detail->id)->assertOk()
            ->assertJsonCount(1, 'data')->assertJsonMissing(['id' => $otherLine->id]);
        $this->postJson('/api/order-lists')->assertOk()->assertJsonCount(1, 'data.0.orders')
            ->assertJsonMissing(['id' => $otherLine->id]);
    }

    public function test_rating_author_is_authenticated_buyer_not_input_user(): void
    {
        $buyer = User::factory()->create();
        $other = User::factory()->create();
        $product = Product::forceCreate(['vendor_id' => 1, 'category_id' => 1, 'unit_id' => 1, 'product_name' => 'Rated Product',
            'product_price' => 1, 'delivery_duration_unit' => 'Days', 'status' => 'Active']);
        Sanctum::actingAs($buyer);
        $this->postJson('/api/store-ratings', ['user_id' => $other->id, 'product_id' => $product->id, 'rating' => 5])->assertOk();
        $this->assertDatabaseHas('ratings', ['user_id' => $buyer->id, 'rateable_id' => $product->id]);
        $this->assertDatabaseMissing('ratings', ['user_id' => $other->id, 'rateable_id' => $product->id]);
    }

    public function test_web_registration_persists_seller_details_and_rejects_role_tampering(): void
    {
        $this->post('/register', [
            'name' => 'Incomplete Seller', 'email' => 'incomplete-seller@example.test',
            'password' => 'password', 'password_confirmation' => 'password',
            'role' => 'seller', 'country' => 'US',
        ])->assertSessionHasErrors(['city', 'address', 'sales_country_codes']);

        $this->post('/register', ['name' => 'Web Seller', 'email' => 'web-seller@example.test', 'phone' => '555',
            'company_name' => 'Web Shop', 'password' => 'password', 'password_confirmation' => 'password', 'role' => 'seller',
            'country' => 'US', 'city' => 'New York', 'address' => '1 Seller Street', 'sales_country_codes' => ['US', 'HT']])
            ->assertRedirect('/dashboard');
        $this->assertDatabaseHas('users', ['email' => 'web-seller@example.test', 'role' => 'seller', 'company_name' => 'Web Shop', 'phone' => '555']);
        $this->assertEqualsCanonicalizing(
            ['US', 'HT'],
            User::where('email', 'web-seller@example.test')->firstOrFail()->vendor->availabilityCountries()->pluck('code')->all()
        );
        $this->post('/register', ['name' => 'Bad', 'email' => 'bad-web@example.test', 'password' => 'password',
            'password_confirmation' => 'password', 'role' => 'admin'])->assertSessionHasErrors('role');
    }

    public function test_web_registration_explains_when_email_is_already_registered(): void
    {
        User::factory()->create(['email' => 'existing@example.test']);

        $this->from('/signup')
            ->post('/register', [
                'name' => 'Existing Email',
                'email' => 'existing@example.test',
                'password' => 'password',
                'password_confirmation' => 'password',
                'role' => 'buyer',
                'country' => 'US',
            ])
            ->assertRedirect('/signup')
            ->assertSessionHasErrors([
                'email' => __('auth.email_already_registered'),
            ]);
    }

    public function test_signup_url_opens_registration_form(): void
    {
        $this->get('/signup')
            ->assertOk()
            ->assertSee('name="password_confirmation"', false);
    }

    public function test_web_password_reset_uses_expiring_token_and_updates_password(): void
    {
        Notification::fake();
        $user = User::factory()->create(['email' => 'reset@example.test', 'password' => Hash::make('old-password')]);
        $token = null;

        $this->from('/password/forgot')
            ->post('/password/email', ['email' => $user->email])
            ->assertRedirect('/password/forgot')
            ->assertSessionHas('status', __('auth.reset_link_sent'));

        Notification::assertSentTo($user, ResetPassword::class, function (ResetPassword $notification) use (&$token): bool {
            $token = $notification->token;
            return true;
        });
        $this->assertNotEmpty($token);
        $this->assertDatabaseHas('password_resets', ['email' => $user->email]);

        $this->get(route('password.reset', ['token' => $token, 'email' => $user->email]))
            ->assertOk()
            ->assertSee('name="password"', false);

        $this->post('/password/reset', [
            'token' => $token,
            'email' => $user->email,
            'password' => 'new-password',
            'password_confirmation' => 'new-password',
        ])->assertRedirect('/auth');

        $this->assertTrue(Hash::check('new-password', $user->fresh()->password));
        $this->assertDatabaseMissing('password_resets', ['email' => $user->email]);
    }

    public function test_payment_response_has_no_stripe_secret_and_buyer_registration_succeeds(): void
    {
        $this->getJson('/api/payment-methods')
            ->assertOk()
            ->assertJsonPath('payment_methods.direct_seller.online', false)
            ->assertJsonMissingPath('payment_methods.stripe');
        $this->getJson('/api/gateways')
            ->assertOk()
            ->assertJsonPath('gateways.0', 'direct_seller');
        $this->postJson('/api/register', ['name' => 'Buyer', 'email' => 'buyer@example.test', 'password' => 'password', 'confirm_password' => 'password', 'role' => 'buyer', 'country' => 'US'])
            ->assertOk()->assertJsonPath('status', true);
        $this->assertDatabaseHas('users', ['email' => 'buyer@example.test', 'role' => 'buyer']);
    }

    public function test_seller_registration_creates_a_vendor(): void
    {
        $this->postJson('/api/register', [
            'name' => 'Seller', 'email' => 'seller@example.test', 'company_name' => 'Seller Shop',
            'password' => 'password', 'confirm_password' => 'password', 'role' => 'seller', 'country' => 'US',
            'city' => 'New York', 'address' => '1 Seller Street', 'sales_country_codes' => ['US', 'HT'],
        ])->assertOk()->assertJsonPath('status', true);
        $user = User::where('email', 'seller@example.test')->firstOrFail();
        $this->assertSame('seller', $user->role);
        $this->assertDatabaseHas('vendors', ['user_id' => $user->id]);
    }

    public function test_ajax_mutations_require_role_method_and_exact_permission(): void
    {
        $routes = [
            '/active-category/999' => 'manage_categories', '/decline-category/999' => 'manage_categories',
            '/active-subcategory/999' => 'manage_categories', '/decline-subcategory/999' => 'manage_categories',
            '/active-unit/999' => 'manage_marketplace', '/decline-unit/999' => 'manage_marketplace',
            '/active-product/999' => 'manage_products', '/decline-product/999' => 'manage_products',
            '/active-vendor/999' => 'manage_sellers', '/decline-vendor/999' => 'manage_sellers',
            '/active-slider/999' => 'manage_promotions', '/decline-slider/999' => 'manage_promotions',
        ];
        $buyer = User::factory()->create();
        $seller = User::factory()->create(['role' => 'seller']);
        $admin = User::factory()->create(['role' => 'admin']);

        foreach ($routes as $uri => $permissionKey) {
            $this->get($uri)->assertStatus(405);
            $this->patchJson($uri)->assertUnauthorized();
            Sanctum::actingAs($buyer);
            $this->patchJson($uri)->assertStatus(403);
            Sanctum::actingAs($seller);
            $this->patchJson($uri)->assertStatus(403);
            Sanctum::actingAs($admin);
            $admin->permissions()->detach();
            $this->patchJson($uri)->assertStatus(403);
            $admin->permissions()->attach(Permission::where('key', $permissionKey)->firstOrFail());
            $this->patchJson($uri)->assertOk();
            auth()->forgetGuards();
        }
    }

    public function test_seller_can_use_buyer_login_and_purchase_routes(): void
    {
        $seller = User::factory()->create(['role' => 'seller', 'password' => Hash::make('password')]);
        $this->postJson('/api/user-login', ['email' => $seller->email, 'password' => 'password', 'use_for' => 'user'])
            ->assertOk()->assertJsonPath('data.role', 'seller');
        Sanctum::actingAs($seller);
        $product = Product::forceCreate(['vendor_id' => 999, 'category_id' => 1, 'unit_id' => 1, 'product_name' => 'Seller Purchase',
            'product_price' => 1, 'delivery_duration_unit' => 'Days', 'status' => 'Active']);
        $detail = Orderdetail::create(['user_id' => $seller->id, 'payment_method' => 'cod', 'order_no' => 'SELLER-BUY',
            'delivery_address' => 'Address', 'sub_total' => '1', 'total_cost' => '1', 'date' => today(), 'time' => '10:00', 'month' => 'January', 'year' => '2026']);
        $line = Order::create(['orderdetail_id' => $detail->id, 'vendor_id' => 999, 'product_id' => $product->id,
            'product_price' => 1, 'product_quantity' => 1, 'unit_total_price' => 1, 'status' => 'Accepted', 'to_review' => 1]);
        foreach ([
            ['post', '/api/save-order', []],
            ['post', '/api/order-transaction', []],
            ['post', '/api/store-ratings', []],
            ['post', '/api/user-order-reviews', []],
            ['post', '/api/store-review', ['order_id' => $line->id, 'product_id' => $product->id, 'rating' => 5, 'msg' => 'Good']],
            ['post', '/api/order-lists', []],
        ] as [$method, $uri, $data]) {
            $response = $this->json(strtoupper($method), $uri, $data);
            $this->assertNotSame(403, $response->status(), $uri.' should allow a seller acting as a buyer');
        }
    }

    public function test_admin_and_owner_cannot_use_public_buyer_login(): void
    {
        foreach (['admin', 'owner'] as $role) {
            $user = User::factory()->create(['role' => $role, 'is_primary_admin' => $role === 'owner', 'password' => Hash::make('password')]);
            $this->postJson('/api/user-login', ['email' => $user->email, 'password' => 'password', 'use_for' => 'user'])
                ->assertStatus(401);
        }
    }

    public function test_promoted_seller_admin_cannot_use_public_buyer_login(): void
    {
        $admin = User::factory()->create(['role' => 'seller', 'password' => Hash::make('password')]);
        Vendor::create(['user_id' => $admin->id, 'balance' => 0]);
        $admin->assignCapabilities(['buyer', 'seller']);
        $admin->forceFill(['role' => 'admin'])->save();

        $this->postJson('/api/user-login', [
            'email' => $admin->email,
            'password' => 'password',
            'use_for' => 'user',
        ])->assertStatus(401);
    }

    public function test_api_save_order_derives_money_vendor_and_stock(): void
    {
        $buyer = User::factory()->create(['role' => 'buyer']);
        $seller = User::factory()->create(['role' => 'seller']);
        $vendor = Vendor::create(['user_id' => $seller->id, 'balance' => 0]);
        $category = DB::table('categories')->insertGetId([
            'user_id' => $seller->id, 'category_name' => 'API Category ' . uniqid(),
            'status' => 'Active', 'image' => '', 'created_at' => now(), 'updated_at' => now(),
        ]);
        $unit = DB::table('units')->insertGetId([
            'user_id' => $seller->id, 'unit_name' => 'API Unit ' . uniqid(),
            'status' => 'Active', 'created_at' => now(), 'updated_at' => now(),
        ]);
        $product = Product::forceCreate([
            'vendor_id' => $vendor->id, 'category_id' => $category, 'unit_id' => $unit,
            'product_name' => 'API Product ' . uniqid(), 'product_price' => 17.25,
            'product_stock' => 4, 'delivery_duration' => 2, 'delivery_duration_unit' => 'Days',
             'delivery_charge' => 2.5, 'is_delivery_free' => 0, 'status' => 'Active', 'country' => 'US',
             'availability_type' => 'selected',
        ]);
         $product->availabilityCountries()->sync([
             DB::table('countries')->where('code', 'US')->value('id'),
         ]);

        Sanctum::actingAs($buyer);
        $this->postJson('/api/save-order', [
            'delivery_address' => 'Server verified address',
            'payment_method' => 'Cash on Delivery',
            'sub_total' => 0, 'shipping_cost' => 0, 'total_cost' => 0, 'status' => 'Completed',
            'products' => [[
                'product_id' => $product->id, 'product_quantity' => 2,
                'vendor_id' => 999999, 'product_price' => 0, 'unit_total_price' => 0,
            ]],
        ])->assertOk()->assertJsonPath('success', true);

        $order = Orderdetail::firstOrFail();
        $this->assertSame($buyer->id, $order->user_id);
        $this->assertEquals(37, (float) $order->total_cost);
        $this->assertSame('Pending', $order->status);
        $this->assertSame(2, $product->fresh()->product_stock);
        $this->assertDatabaseHas('orders', [
            'orderdetail_id' => $order->id, 'vendor_id' => $vendor->id,
            'product_id' => $product->id, 'product_price' => 17.25, 'product_quantity' => 2,
        ]);
    }
}