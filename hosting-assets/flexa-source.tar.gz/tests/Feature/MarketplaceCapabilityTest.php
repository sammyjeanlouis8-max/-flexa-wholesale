<?php

namespace Tests\Feature;

use App\Models\AdminActivityLog;
use App\Models\Cart;
use App\Models\Favorite;
use App\Models\Product;
use App\Models\User;
use App\Models\Vendor;
use App\Http\Controllers\AdminController;
use App\Services\AdminActivityLogger;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class MarketplaceCapabilityTest extends TestCase
{
    use RefreshDatabase;

    public function test_seller_has_buyer_and_seller_capabilities_and_can_purchase(): void
    {
        $seller = User::factory()->create(['role' => 'seller']);
        Vendor::create(['user_id' => $seller->id]);

        $this->assertTrue($seller->fresh()->hasCapability('buyer'));
        $this->assertTrue($seller->fresh()->hasCapability('seller'));
        $this->assertTrue($seller->fresh()->canBuy());
        $this->assertTrue($seller->fresh()->canSell());
    }

    public function test_legacy_buyer_mapping_remains_available_without_a_pivot_row(): void
    {
        $buyer = User::factory()->create(['role' => 'buyer']);
        $buyer->capabilities()->detach();

        $this->assertTrue($buyer->fresh()->hasCapability('buyer'));
        $this->assertFalse($buyer->fresh()->hasCapability('seller'));
    }

    public function test_owner_action_is_written_without_sensitive_metadata(): void
    {
        $owner = User::factory()->create(['role' => 'owner', 'is_primary_admin' => true]);
        $admin = User::factory()->create(['role' => 'admin']);
        app(AdminActivityLogger::class)->record($owner, 'admin.promoted', $admin, [
            'permission_ids' => [1],
            'password' => 'must-not-be-stored',
            'payment' => ['stripe_secret_key' => 'must-not-be-stored'],
        ]);

        $log = AdminActivityLog::firstOrFail();
        $this->assertSame($owner->id, $log->actor_id);
        $this->assertSame('admin.promoted', $log->action);
        $this->assertArrayNotHasKey('password', $log->metadata);
        $this->assertArrayNotHasKey('stripe_secret_key', $log->metadata['payment']);
    }

    public function test_remove_admin_preserves_account_and_restores_seller_customer_access(): void
    {
        $owner = User::factory()->create(['role' => 'owner', 'is_primary_admin' => true]);
        $admin = User::factory()->create(['role' => 'buyer']);
        Vendor::create(['user_id' => $admin->id]);
        $admin->assignCapabilities(['buyer', 'seller']);
        $admin->role = 'admin';
        $admin->save();

        $this->actingAs($owner);
        app(AdminController::class)->destroy($admin);

        $admin->refresh();
        $this->assertDatabaseHas('users', ['id' => $admin->id]);
        $this->assertSame('seller', $admin->role);
        $this->assertTrue($admin->hasCapability('buyer'));
        $this->assertTrue($admin->hasCapability('seller'));
        $this->assertDatabaseHas('admin_activity_logs', ['action' => 'admin.removed', 'target_id' => $admin->id]);
    }

    public function test_remove_admin_refuses_non_admin_target(): void
    {
        $owner = User::factory()->create(['role' => 'owner', 'is_primary_admin' => true]);
        $buyer = User::factory()->create(['role' => 'buyer']);

        $this->actingAs($owner);
        app(AdminController::class)->destroy($buyer);

        $this->assertSame('buyer', $buyer->fresh()->role);
        $this->assertDatabaseMissing('admin_activity_logs', ['action' => 'admin.removed', 'target_id' => $buyer->id]);
    }

    public function test_customer_relationships_are_available(): void
    {
        $user = User::factory()->create();
        $product = Product::forceCreate([
            'vendor_id' => 1, 'category_id' => 1, 'unit_id' => 1,
            'product_name' => 'Relationship product', 'product_price' => 1,
            'delivery_duration_unit' => 'Days', 'status' => 'Active',
        ]);
        Favorite::create(['user_id' => $user->id, 'product_id' => $product->id]);
        $cart = Cart::create(['user_id' => $user->id]);
        $cart->items()->create(['product_id' => $product->id, 'quantity' => 2]);

        $this->assertTrue($user->favorites()->where('product_id', $product->id)->exists());
        $this->assertSame($cart->id, $user->cart->id);
        $this->assertCount(1, $product->cartItems);
    }
}