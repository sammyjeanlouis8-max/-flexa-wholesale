<?php

namespace Tests\Feature;

use App\Models\Cart;
use App\Models\Favorite;
use App\Models\Order;
use App\Models\Orderdetail;
use App\Models\Product;
use App\Models\User;
use App\Models\Vendor;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;
use Tests\TestCase;

class MarketplaceFlowTest extends TestCase
{
    use RefreshDatabase;

    private function buyer(array $attributes = []): User
    {
        return User::factory()->create(array_merge(['role' => 'buyer'], $attributes));
    }

    private function seller(): array
    {
        $user = User::factory()->create(['role' => 'seller']);
        $user->update(['country' => 'US', 'city' => 'New York', 'address' => '1 Seller Street', 'company_name' => 'Seller Shop ' . uniqid()]);
        $vendor = Vendor::create([
            'user_id' => $user->id,
            'city' => 'New York',
            'region' => 'New York',
            'postal_code' => '10001',
            'address' => '1 Seller Street',
            'balance' => 0,
        ]);
        $vendor->availabilityCountries()->sync([DB::table('countries')->where('code', 'US')->value('id')]);
        return [$user, $vendor];
    }

    private function catalog(User $owner, Vendor $vendor): array
    {
        $category = DB::table('categories')->where('slug', 'food-beverages')->value('id');
        $unit = DB::table('units')->insertGetId([
            'user_id' => $owner->id, 'unit_name' => 'Unit ' . uniqid(), 'status' => 'Active',
            'created_at' => now(), 'updated_at' => now(),
        ]);
        return [$category, $unit];
    }

    private function product(Vendor $vendor, int $category, int $unit, array $attributes = []): Product
    {
        $product = Product::forceCreate(array_merge([
            'vendor_id' => $vendor->id, 'category_id' => $category, 'unit_id' => $unit,
            'product_name' => 'Product ' . uniqid(), 'product_price' => 19.75, 'product_stock' => 8,
            'delivery_duration' => 2, 'delivery_duration_unit' => 'Days', 'delivery_charge' => 3.50,
              'is_delivery_free' => 0, 'status' => 'Active', 'country' => 'US',
              'availability_type' => 'selected',
        ], $attributes));

        $countryId = DB::table('countries')->where('code', $product->country)->value('id');
        if ($countryId) {
            $product->availabilityCountries()->sync([$countryId]);
        }

        return $product;
    }

    public function test_anonymous_users_are_blocked_from_marketplace_mutations(): void
    {
        [$seller, $vendor] = $this->seller();
        [$category, $unit] = $this->catalog($seller, $vendor);
        $product = $this->product($vendor, $category, $unit);

        $this->post(route('marketplace.favorite.add', $product))->assertRedirect(route('auth.show'));
        $this->post(route('marketplace.cart.add', $product), ['quantity' => 1])->assertRedirect(route('auth.show'));
        $this->post(route('marketplace.checkout.place'), ['payment_method' => 'Cash on Delivery', 'delivery_address' => 'Address'])->assertRedirect(route('auth.show'));
    }

    public function test_buyer_can_manage_only_own_favorite_and_cart_items(): void
    {
        [$seller, $vendor] = $this->seller();
        [$category, $unit] = $this->catalog($seller, $vendor);
        $product = $this->product($vendor, $category, $unit);
        $buyer = $this->buyer();
        $other = $this->buyer();

        $this->actingAs($buyer)->post(route('marketplace.favorite.add', $product))->assertSessionHasNoErrors();
        $favorite = Favorite::firstOrFail();
        $this->actingAs($other)->delete(route('marketplace.favorite.remove', $favorite))->assertForbidden();
        $this->actingAs($buyer)->delete(route('marketplace.favorite.remove', $favorite))->assertSessionHasNoErrors();
        $this->assertDatabaseMissing('favorites', ['id' => $favorite->id]);

        $this->actingAs($buyer)->post(route('marketplace.cart.add', $product), ['quantity' => 2])->assertSessionHasNoErrors();
        $item = Cart::where('user_id', $buyer->id)->firstOrFail()->items()->firstOrFail();
        $this->actingAs($other)->patch(route('marketplace.cart.update', $item), ['quantity' => 1])->assertForbidden();
        $this->actingAs($other)->delete(route('marketplace.cart.remove', $item))->assertForbidden();
        $this->actingAs($buyer)->patch(route('marketplace.cart.update', $item), ['quantity' => 3])->assertSessionHasNoErrors();
        $this->assertDatabaseHas('cart_items', ['id' => $item->id, 'quantity' => 3]);
        $this->actingAs($buyer)->delete(route('marketplace.cart.remove', $item))->assertSessionHasNoErrors();
        $this->assertDatabaseMissing('cart_items', ['id' => $item->id]);
    }

    public function test_purchase_request_does_not_collect_payment_and_uses_server_values(): void
    {
        [$seller, $vendor] = $this->seller();
        [$category, $unit] = $this->catalog($seller, $vendor);
        $product = $this->product($vendor, $category, $unit, ['product_price' => 12.50, 'product_stock' => 5, 'delivery_charge' => 4]);
        $buyer = $this->buyer();
        $cart = Cart::create(['user_id' => $buyer->id]);
        $cart->items()->create(['product_id' => $product->id, 'quantity' => 2]);

        $this->actingAs($buyer)->post(route('marketplace.checkout.place'), [
            'payment_method' => 'Card', 'delivery_address' => '42 Market Street',
            'total_cost' => 0, 'vendor_id' => 9999, 'user_id' => 9999, 'product_price' => 0,
        ])->assertRedirect(route('marketplace.orders'));

        $order = Orderdetail::firstOrFail();
        $this->assertSame($buyer->id, $order->user_id);
        $this->assertSame('Direct with seller', $order->payment_method);
        $this->assertEquals(29, (float) $order->total_cost);
        $line = Order::firstOrFail();
        $this->assertSame($vendor->id, (int) $line->vendor_id);
        $this->assertSame($product->id, (int) $line->product_id);
        $this->assertEquals(12.5, (float) $line->product_price);
        $this->assertEquals(25, (float) $line->unit_total_price);
        $this->assertSame(3, $product->fresh()->product_stock);
        $this->assertCount(0, $cart->fresh()->items);
    }

    public function test_seller_can_buy_and_product_creation_uses_own_vendor_with_inactive_default(): void
    {
        [$seller, $vendor] = $this->seller();
        [$category, $unit] = $this->catalog($seller, $vendor);
        $available = $this->product($vendor, $category, $unit);
        $this->actingAs($seller)->post(route('marketplace.cart.add', $available), ['quantity' => 1])->assertSessionHasNoErrors();

        $this->actingAs($seller)->post(route('seller.product-store'), [
            'product_name' => 'Seller listing ' . uniqid(), 'category_id' => $category, 'unit_id' => $unit,
            'product_price' => 8, 'product_stock' => 2, 'delivery_duration' => 1, 'delivery_duration_unit' => 'Days',
            'delivery_charge' => 0, 'vendor_id' => 99999, 'user_id' => 99999,
            'country' => 'US', 'city' => 'New York',
            'availability_type' => 'selected', 'country_codes' => ['US'],
            'images' => [
                UploadedFile::fake()->image('seller-one.jpg', 400, 400),
                UploadedFile::fake()->image('seller-two.jpg', 400, 400),
            ],
        ])->assertRedirect(route('seller.products'));
        $listing = Product::where('product_name', 'like', 'Seller listing%')->firstOrFail();
        $this->assertSame($vendor->id, (int) $listing->vendor_id);
        $this->assertSame('Inactive', $listing->status);

        [$otherSeller] = $this->seller();
        $this->actingAs($otherSeller)->get(route('seller.products'))->assertDontSee($listing->product_name);
    }

    public function test_profile_update_uses_allowlist_only(): void
    {
        $buyer = $this->buyer(['account_status' => 'active']);
        $this->actingAs($buyer)->patch(route('marketplace.profile.update'), [
            'name' => 'Updated Name', 'phone' => '555', 'address' => 'Safe address',
            'role' => 'seller', 'account_status' => 'inactive', 'vendor_id' => 99,
        ])->assertSessionHasNoErrors();

        $buyer->refresh();
        $this->assertSame('Updated Name', $buyer->name);
        $this->assertSame('buyer', $buyer->role);
        $this->assertSame('active', $buyer->account_status);
        $this->assertFalse($buyer->vendor()->exists());
    }
}