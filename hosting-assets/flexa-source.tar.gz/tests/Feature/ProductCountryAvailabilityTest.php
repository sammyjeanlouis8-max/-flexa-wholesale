<?php

namespace Tests\Feature;

use App\Models\Cart;
use App\Models\Orderdetail;
use App\Models\Product;
use App\Models\User;
use App\Models\Vendor;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

class ProductCountryAvailabilityTest extends TestCase
{
    use RefreshDatabase;

    private function catalog(User $owner): array
    {
        $category = DB::table('categories')->where('slug', 'food-beverages')->value('id');
        $unit = DB::table('units')->insertGetId([
            'user_id' => $owner->id, 'unit_name' => 'Country unit ' . uniqid(),
            'status' => 'Active', 'created_at' => now(), 'updated_at' => now(),
        ]);
        return [$category, $unit];
    }

    private function product(Vendor $vendor, int $category, int $unit, array $attributes = []): Product
    {
        $product = Product::forceCreate(array_merge([
            'vendor_id' => $vendor->id, 'category_id' => $category, 'unit_id' => $unit,
            'product_name' => 'Country product ' . uniqid(), 'product_price' => 25,
            'product_stock' => 5, 'delivery_duration' => 2, 'delivery_duration_unit' => 'Days',
            'delivery_charge' => 0, 'is_delivery_free' => 1, 'status' => 'Active',
             'availability_type' => 'selected', 'country' => 'US',
        ], $attributes));

        if ($product->availability_type === 'selected' && $product->country) {
            $countryId = DB::table('countries')->where('code', $product->country)->value('id');
            if ($countryId) {
                $product->availabilityCountries()->sync([$countryId]);
            }
        }

        return $product;
    }

    private function sellerProfile(Vendor $vendor, string $locationCountry = 'US', array $salesCountries = ['US']): void
    {
        $vendor->user->update([
            'country' => $locationCountry,
            'city' => 'New York',
            'address' => '1 Seller Street',
            'company_name' => $vendor->user->company_name ?: 'Seller Shop ' . uniqid(),
        ]);
        $vendor->update([
            'city' => 'New York',
            'region' => 'New York',
            'postal_code' => '10001',
            'address' => '1 Seller Street',
        ]);
        $vendor->availabilityCountries()->sync(
            DB::table('countries')->whereIn('code', $salesCountries)->pluck('id')->all()
        );
    }

    public function test_seller_can_save_and_modify_selected_country_availability(): void
    {
        $seller = User::factory()->create(['role' => 'seller']);
        $vendor = Vendor::create(['user_id' => $seller->id, 'balance' => 0]);
        $this->sellerProfile($vendor, 'US', ['US', 'HT']);
        [$category, $unit] = $this->catalog($seller);

        $this->actingAs($seller)->post(route('seller.product-store'), [
            'product_name' => 'Selected listing ' . uniqid(), 'category_id' => $category, 'unit_id' => $unit,
            'product_price' => 10, 'product_stock' => 2, 'delivery_duration' => 1,
            'delivery_duration_unit' => 'Days', 'delivery_charge' => 0,
            'country' => 'US', 'city' => 'New York',
            'availability_type' => 'selected', 'country_codes' => ['US', 'HT'],
            'images' => [
                UploadedFile::fake()->image('selected-one.jpg', 400, 400),
                UploadedFile::fake()->image('selected-two.jpg', 400, 400),
            ],
        ])->assertRedirect(route('seller.products'));

        $product = Product::where('vendor_id', $vendor->id)->latest('id')->firstOrFail();
        $product->update(['status' => 'Active']);
        $this->assertSame('selected', $product->availability_type);
        $this->assertEqualsCanonicalizing(['US', 'HT'], $product->availabilityCountries()->pluck('code')->all());

        $this->actingAs($seller)->patch(route('seller.product-update', $product), [
            'product_name' => $product->product_name, 'category_id' => $category, 'unit_id' => $unit,
            'product_price' => 10, 'product_stock' => 2, 'delivery_duration' => 1,
            'delivery_duration_unit' => 'Days', 'delivery_charge' => 0,
            'country' => 'US', 'city' => 'New York',
            'availability_type' => 'selected', 'country_codes' => ['FR'],
        ])->assertRedirect(route('seller.products'));

        $this->assertEqualsCanonicalizing(['US', 'HT'], $product->fresh()->availabilityCountries()->pluck('code')->all());
    }

    public function test_api_listing_uses_seller_profile_location_and_availability(): void
    {
        $seller = User::factory()->create(['role' => 'seller']);
        $vendor = Vendor::create(['user_id' => $seller->id, 'balance' => 0]);
        $this->sellerProfile($vendor, 'US', ['HT']);
        [$category, $unit] = $this->catalog($seller);
        $subcategory = DB::table('subcategories')->insertGetId([
            'user_id' => $seller->id,
            'category_id' => $category,
            'subcategory_name' => 'API subcategory ' . uniqid(),
            'status' => 'Active',
            'image' => '',
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        Sanctum::actingAs($seller);
        $this->postJson('/api/store-product', [
            'vendor_id' => $vendor->id,
            'category_id' => $category,
            'subcategory_id' => $subcategory,
            'unit_id' => $unit,
            'product_name' => 'API profile listing ' . uniqid(),
            'product_price' => 20,
            'product_stock' => 10,
            'is_featured' => 0,
            'top_picks' => 0,
            'status' => 'Active',
            'country' => 'FR',
            'city' => 'Paris',
            'postal_code' => '75001',
            'country_codes' => ['FR'],
        ])->assertOk();

        $product = Product::where('vendor_id', $vendor->id)->latest('id')->firstOrFail();
        $this->assertSame('US', $product->country);
        $this->assertSame('New York', $product->city);
        $this->assertSame('10001', $product->postal_code);
        $this->assertEquals(['HT'], $product->availabilityCountries()->pluck('code')->all());
    }

    public function test_seller_must_complete_profile_availability_before_submitting_a_listing(): void
    {
        $seller = User::factory()->create(['role' => 'seller']);
        $vendor = Vendor::create(['user_id' => $seller->id, 'balance' => 0]);
        [$category, $unit] = $this->catalog($seller);
        $payload = [
            'product_name' => 'Country requirement ' . uniqid(),
            'category_id' => $category,
            'unit_id' => $unit,
            'product_price' => 10,
            'product_stock' => 2,
            'delivery_duration' => 1,
            'delivery_duration_unit' => 'Days',
            'delivery_charge' => 0,
            'country' => 'US',
            'city' => 'New York',
        ];

        $payload['images'] = [
            UploadedFile::fake()->image('profile-one.jpg', 400, 400),
            UploadedFile::fake()->image('profile-two.jpg', 400, 400),
        ];
        $this->actingAs($seller)->post(route('seller.product-store'), $payload)
            ->assertSessionHasErrors(['profile_location', 'sales_country_codes']);

        $this->assertDatabaseMissing('products', ['vendor_id' => $vendor->id, 'product_name' => $payload['product_name']]);
    }

    public function test_listing_form_only_exposes_specific_country_availability(): void
    {
        $seller = User::factory()->create(['role' => 'seller']);
        Vendor::create(['user_id' => $seller->id, 'balance' => 0]);

        $this->actingAs($seller)
            ->get(route('seller.product-create'))
            ->assertOk()
            ->assertDontSee('value="worldwide"', false)
            ->assertDontSee('available_worldwide')
            ->assertSee('data-photo-input', false)
            ->assertSee('capture="environment"', false)
            ->assertSee(__('seller.gallery'))
            ->assertSee(__('seller.camera'))
            ->assertSee('data-video-input', false)
            ->assertSee(__('seller.add_video_title'))
            ->assertSee(__('auth.optional'))
            ->assertSee('accept="video/mp4,video/webm,video/quicktime"', false)
            ->assertDontSee('name="country_codes[]"', false)
            ->assertDontSee('name="warehouse_country"', false);
    }

    public function test_seller_must_add_at_least_two_product_photos(): void
    {
        $seller = User::factory()->create(['role' => 'seller']);
        $vendor = Vendor::create(['user_id' => $seller->id, 'balance' => 0]);
        $this->sellerProfile($vendor);
        [$category, $unit] = $this->catalog($seller);

        $this->actingAs($seller)->post(route('seller.product-store'), [
            'product_name' => 'One photo listing ' . uniqid(),
            'category_id' => $category,
            'unit_id' => $unit,
            'product_price' => 10,
            'product_stock' => 2,
            'delivery_duration' => 1,
            'delivery_duration_unit' => 'Days',
            'delivery_charge' => 0,
            'country' => 'US',
            'city' => 'New York',
            'availability_type' => 'selected',
            'country_codes' => ['US'],
            'images' => [UploadedFile::fake()->image('only-photo.jpg', 400, 400)],
        ])->assertSessionHasErrors('images');
    }

    public function test_buyer_country_filters_feed_and_direct_product_access_explains_restriction(): void
    {
        $owner = User::factory()->create(['role' => 'seller']);
        $vendor = Vendor::create(['user_id' => $owner->id, 'balance' => 0]);
        [$category, $unit] = $this->catalog($owner);
        $product = $this->product($vendor, $category, $unit, ['availability_type' => 'selected']);
        $product->availabilityCountries()->sync([DB::table('countries')->where('code', 'HT')->value('id')]);

        $this->withSession(['marketplace_country' => 'FR'])
            ->get(route('marketplace.home'))
            ->assertDontSee($product->product_name);
        $this->withSession(['marketplace_country' => 'FR'])
            ->get(route('marketplace.product', $product))
            ->assertSee(__('marketplace.not_available_country'));
    }

    public function test_cart_and_web_checkout_reject_a_product_unavailable_in_destination_country(): void
    {
        $owner = User::factory()->create(['role' => 'seller']);
        $vendor = Vendor::create(['user_id' => $owner->id, 'balance' => 0]);
        [$category, $unit] = $this->catalog($owner);
        $product = $this->product($vendor, $category, $unit, ['availability_type' => 'selected']);
        $product->availabilityCountries()->sync([DB::table('countries')->where('code', 'HT')->value('id')]);
        $buyer = User::factory()->create(['role' => 'buyer']);

        $this->actingAs($buyer)->withSession(['marketplace_country' => 'US'])
            ->post(route('marketplace.cart.add', $product), ['quantity' => 1])
            ->assertStatus(422);

        $cart = Cart::create(['user_id' => $buyer->id]);
        $cart->items()->create(['product_id' => $product->id, 'quantity' => 1]);
        $this->actingAs($buyer)->post(route('marketplace.checkout.place'), [
            'delivery_address' => 'Address', 'delivery_country' => 'US',
            'payment_method' => 'Card',
        ])->assertStatus(422);
        $this->assertDatabaseCount('orderdetails', 0);
    }

    public function test_seller_media_uploads_are_validated_and_stored_with_ordered_metadata(): void
    {
        $seller = User::factory()->create(['role' => 'seller']);
        $vendor = Vendor::create(['user_id' => $seller->id, 'balance' => 0]);
        $this->sellerProfile($vendor, 'HT', ['HT']);
        [$category, $unit] = $this->catalog($seller);

        $this->actingAs($seller)->post(route('seller.product-store'), [
            'product_name' => 'Media listing ' . uniqid(), 'category_id' => $category, 'unit_id' => $unit,
            'product_price' => 10, 'product_stock' => 2, 'delivery_duration' => 1,
            'delivery_duration_unit' => 'Days', 'delivery_charge' => 0,
            'country' => 'HT', 'city' => 'Port-au-Prince',
            'availability_type' => 'selected',
            'country_codes' => ['HT'],
            'images' => [
                UploadedFile::fake()->image('square.png', 400, 400),
                UploadedFile::fake()->image('detail.png', 400, 400),
            ],
            'videos' => [UploadedFile::fake()->create('demo.mp4', 100, 'video/mp4')],
        ])->assertRedirect(route('seller.products'));

        $product = Product::where('vendor_id', $vendor->id)->latest('id')->firstOrFail();
        $this->assertDatabaseHas('product_media', ['product_id' => $product->id, 'media_type' => 'image', 'display_order' => 0]);
        $this->assertDatabaseHas('product_media', ['product_id' => $product->id, 'media_type' => 'video', 'display_order' => 2]);
    }

    public function test_wholesale_listing_stores_logistics_tiers_and_redacts_private_warehouse_address(): void
    {
        $seller = User::factory()->create(['role' => 'seller', 'country' => 'US']);
        $vendor = Vendor::create(['user_id' => $seller->id, 'balance' => 0]);
        $this->sellerProfile($vendor, 'HT', ['HT']);
        [$category, $unit] = $this->catalog($seller);

        $this->actingAs($seller)->post(route('seller.product-store'), [
            'product_name' => 'Wholesale logistics listing ' . uniqid(),
            'category_id' => $category,
            'unit_id' => $unit,
            'product_price' => 25,
            'product_stock' => 100,
            'minimum_order_quantity' => 5,
            'wholesale_unit_type' => 'case',
            'sku' => 'WHOLESALE-' . uniqid(),
            'delivery_duration' => 3,
            'delivery_duration_unit' => 'Days',
            'delivery_charge' => 12,
            'is_delivery_free' => 0,
            'country' => 'HT',
            'city' => 'Port-au-Prince',
            'region' => 'Ouest',
            'postal_code' => 'HT6110',
            'warehouse_name' => 'Private Port Depot',
            'warehouse_address' => '42 Rue du Port, Warehouse 7',
            'warehouse_city' => 'Port-au-Prince',
            'warehouse_region' => 'Ouest',
            'warehouse_postal_code' => 'HT6110',
            'warehouse_country' => 'HT',
            'ships_internationally' => 1,
            'offers_warehouse_pickup' => 1,
            'availability_type' => 'selected',
            'country_codes' => ['HT'],
            'images' => [
                UploadedFile::fake()->image('warehouse-one.jpg', 400, 400),
                UploadedFile::fake()->image('warehouse-two.jpg', 400, 400),
            ],
            'price_tiers' => [
                ['min_quantity' => 5, 'max_quantity' => 9, 'unit_price' => 24],
                ['min_quantity' => 10, 'max_quantity' => '', 'unit_price' => 21],
            ],
        ])->assertRedirect(route('seller.products'));

        $product = Product::where('vendor_id', $vendor->id)->latest('id')->firstOrFail();
        $product->update(['status' => 'Active']);
        $this->assertSame(5, $product->minimum_order_quantity);
        $this->assertSame('case', $product->wholesale_unit_type);
        $this->assertSame('10001', $product->postal_code);
        $this->assertTrue($product->ships_internationally);
        $this->assertTrue($product->offers_warehouse_pickup);
        $this->assertDatabaseHas('products', ['id' => $product->id, 'postal_code' => '10001']);
        $this->assertDatabaseHas('product_price_tiers', [
            'product_id' => $product->id,
            'min_quantity' => 5,
            'max_quantity' => 9,
            'unit_price' => 24,
        ]);
        $this->assertDatabaseHas('product_price_tiers', [
            'product_id' => $product->id,
            'min_quantity' => 10,
            'max_quantity' => null,
            'unit_price' => 21,
        ]);

        $buyer = User::factory()->create(['role' => 'buyer', 'country' => 'HT']);
        $this->actingAs($buyer)->withSession(['marketplace_country' => 'HT'])
            ->get(route('marketplace.product', $product))
            ->assertSee('New York')
            ->assertDontSee('42 Rue du Port');

        $this->getJson('/api/product-details/' . $product->id)
            ->assertOk()
            ->assertJsonPath('data.minimum_order_quantity', 5)
            ->assertJsonPath('data.wholesale_unit_type', 'case')
            ->assertJsonPath('data.price_tiers.0.unit_price', 24)
            ->assertJsonMissingPath('data.warehouse_address');
    }

    public function test_moq_and_quantity_tier_price_are_enforced_at_api_checkout(): void
    {
        $seller = User::factory()->create(['role' => 'seller']);
        $vendor = Vendor::create(['user_id' => $seller->id, 'balance' => 0]);
        [$category, $unit] = $this->catalog($seller);
        $product = $this->product($vendor, $category, $unit, [
            'product_price' => 25,
            'product_stock' => 20,
            'country' => 'US',
            'minimum_order_quantity' => 5,
            'wholesale_unit_type' => 'box',
        ]);
        $product->priceTiers()->create([
            'min_quantity' => 5,
            'max_quantity' => null,
            'unit_price' => 20,
        ]);
        $buyer = User::factory()->create(['role' => 'buyer', 'country' => 'US']);
        Sanctum::actingAs($buyer);

        $this->postJson('/api/save-order', [
            'delivery_address' => 'Buyer address',
            'delivery_country' => 'US',
            'payment_method' => 'Cash on Delivery',
            'products' => [['product_id' => $product->id, 'product_quantity' => 4]],
        ])->assertStatus(422);
        $this->assertDatabaseCount('orderdetails', 0);

        $this->postJson('/api/save-order', [
            'delivery_address' => 'Buyer address',
            'delivery_country' => 'US',
            'payment_method' => 'Cash on Delivery',
            'products' => [['product_id' => $product->id, 'product_quantity' => 5]],
        ])->assertOk();

        $this->assertDatabaseHas('orders', [
            'product_id' => $product->id,
            'product_quantity' => 5,
            'product_price' => 20,
            'unit_total_price' => 100,
        ]);
    }

    public function test_api_rejects_overlapping_quantity_price_tiers(): void
    {
        $seller = User::factory()->create(['role' => 'seller']);
        $vendor = Vendor::create(['user_id' => $seller->id, 'balance' => 0]);
        [$category, $unit] = $this->catalog($seller);
        $subcategory = DB::table('subcategories')->insertGetId([
            'user_id' => $seller->id,
            'category_id' => $category,
            'subcategory_name' => 'Wholesale subcategory ' . uniqid(),
            'status' => 'Active',
            'image' => '',
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        Sanctum::actingAs($seller);

        $name = 'Overlapping tiers ' . uniqid();
        $this->postJson('/api/store-product', [
            'vendor_id' => $vendor->id,
            'category_id' => $category,
            'subcategory_id' => $subcategory,
            'unit_id' => $unit,
            'product_name' => $name,
            'product_price' => 25,
            'product_stock' => 20,
            'is_featured' => 0,
            'top_picks' => 0,
            'status' => 'Active',
            'country' => 'US',
            'city' => 'New York',
            'price_tiers' => [
                ['min_quantity' => 5, 'max_quantity' => 10, 'unit_price' => 24],
                ['min_quantity' => 10, 'max_quantity' => 20, 'unit_price' => 20],
            ],
        ])->assertStatus(422)
            ->assertJsonPath('status', false);

        $this->assertDatabaseMissing('products', ['product_name' => $name]);
    }

    public function test_api_checkout_cannot_bypass_country_restriction(): void
    {
        $owner = User::factory()->create(['role' => 'seller']);
        $vendor = Vendor::create(['user_id' => $owner->id, 'balance' => 0]);
        [$category, $unit] = $this->catalog($owner);
        $product = $this->product($vendor, $category, $unit, ['availability_type' => 'selected']);
        $product->availabilityCountries()->sync([DB::table('countries')->where('code', 'HT')->value('id')]);
        $buyer = User::factory()->create(['role' => 'buyer']);
        Sanctum::actingAs($buyer);

        $this->postJson('/api/save-order', [
            'delivery_address' => 'Address', 'delivery_country' => 'US',
            'payment_method' => 'Cash on Delivery',
            'products' => [['product_id' => $product->id, 'product_quantity' => 1]],
        ])->assertStatus(422);
        $this->assertDatabaseCount('orderdetails', 0);
    }
}