<?php

namespace Tests\Feature;

use App\Models\User;
use App\Models\Vendor;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class SellerPlansTest extends TestCase
{
    use RefreshDatabase;

    public function test_seller_can_view_trial_and_all_membership_plans(): void
    {
        $seller = User::factory()->create(['role' => 'seller']);
        Vendor::create(['user_id' => $seller->id, 'balance' => 0]);

        $this->actingAs($seller)
            ->get(route('seller.plans'))
            ->assertOk()
            ->assertSee('30 days free')
            ->assertSee('Essentials')
            ->assertSee('$15')
            ->assertSee('Growth')
            ->assertSee('$25')
            ->assertSee('Pro')
            ->assertSee('$50')
            ->assertSee('Most popular')
            ->assertSee('Billing activation coming soon');
    }

    public function test_non_sellers_cannot_view_seller_membership_plans(): void
    {
        $buyer = User::factory()->create(['role' => 'buyer']);

        $this->actingAs($buyer)
            ->get(route('seller.plans'))
            ->assertForbidden();
    }
}