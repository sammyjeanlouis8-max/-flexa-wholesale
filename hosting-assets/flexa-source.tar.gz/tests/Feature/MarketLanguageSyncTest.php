<?php

namespace Tests\Feature;

use Tests\TestCase;

class MarketLanguageSyncTest extends TestCase
{
    public function test_lang_query_from_flexa_market_sets_wholesale_locale(): void
    {
        $response = $this->get('/?lang=ht');

        $response->assertOk();
        $response->assertSessionHas(config('localization.session_key', 'locale'), 'ht');
        $this->assertSame('ht', app()->getLocale());
    }

    public function test_flexamarket_lang_cookie_sets_wholesale_locale(): void
    {
        $response = $this->withCookie('flexamarket_lang', 'es')->get('/');

        $response->assertOk();
        $response->assertSessionHas(config('localization.session_key', 'locale'), 'es');
        $this->assertSame('es', app()->getLocale());
    }

    public function test_unsupported_lang_falls_back_to_english(): void
    {
        $response = $this->get('/?lang=xx');

        $response->assertOk();
        $this->assertSame('en', app()->getLocale());
    }
}
