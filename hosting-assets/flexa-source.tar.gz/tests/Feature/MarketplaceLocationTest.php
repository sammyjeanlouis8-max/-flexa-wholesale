<?php

namespace Tests\Feature;

use App\Models\Product;
use App\Models\User;
use App\Models\Vendor;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

class MarketplaceLocationTest extends TestCase
{
    use RefreshDatabase;

    private function catalog(User $owner): array
    {
        $category = DB::table('categories')->where('slug', 'food-beverages')->value('id');
        $unit = DB::table('units')->insertGetId([
            'user_id' => $owner->id,
            'unit_name' => 'Location unit ' . uniqid(),
            'status' => 'Active',
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        return [$category, $unit];
    }

    private function product(Vendor $vendor, int $category, int $unit, string $name, ?string $country, ?string $city): Product
    {
        $product = Product::forceCreate([
            'vendor_id' => $vendor->id,
            'category_id' => $category,
            'unit_id' => $unit,
            'product_name' => $name,
            'product_price' => 10,
            'product_stock' => 4,
            'delivery_duration' => 2,
            'delivery_duration_unit' => 'Days',
            'delivery_charge' => 0,
            'is_delivery_free' => 1,
            'availability_type' => 'selected',
            'country' => $country,
            'city' => $city,
            'status' => 'Active',
        ]);

        if ($country) {
            $countryId = DB::table('countries')->where('code', $country)->value('id');
            if ($countryId) {
                $product->availabilityCountries()->sync([$countryId]);
            }
        }

        return $product;
    }

    public function test_web_signup_requires_and_persists_account_country(): void
    {
        $this->post('/register', [
            'name' => 'Missing Country',
            'email' => 'missing-country@example.test',
            'password' => 'password',
            'password_confirmation' => 'password',
            'role' => 'buyer',
        ])->assertSessionHasErrors('country');

        $this->post('/register', [
            'name' => 'Haitian Buyer',
            'email' => 'haitian-buyer@example.test',
            'password' => 'password',
            'password_confirmation' => 'password',
            'role' => 'buyer',
            'country' => 'HT',
            'city' => 'Port-au-Prince',
        ])->assertRedirect('/dashboard');

        $this->assertDatabaseHas('users', [
            'email' => 'haitian-buyer@example.test',
            'country' => 'HT',
            'city' => 'Port-au-Prince',
        ]);
    }

    public function test_seller_can_list_product_in_a_different_country_than_account(): void
    {
        $seller = User::factory()->create(['role' => 'seller', 'country' => 'US']);
        $vendor = Vendor::create(['user_id' => $seller->id, 'balance' => 0]);
        $seller->update(['city' => 'New York', 'address' => '1 Seller Street']);
        $vendor->update(['city' => 'New York', 'region' => 'New York', 'postal_code' => '10001', 'address' => '1 Seller Street']);
        $vendor->availabilityCountries()->sync([DB::table('countries')->where('code', 'HT')->value('id')]);
        [$category, $unit] = $this->catalog($seller);

        $this->actingAs($seller)->post(route('seller.product-store'), [
            'product_name' => 'Cross-border listing',
            'category_id' => $category,
            'unit_id' => $unit,
            'product_price' => 10,
            'product_stock' => 2,
            'delivery_duration' => 1,
            'delivery_duration_unit' => 'Days',
            'delivery_charge' => 0,
            'country' => 'HT',
            'city' => 'Cap-Haitien',
            'region' => 'Nord',
            'availability_type' => 'selected',
            'country_codes' => ['HT'],
            'images' => [
                UploadedFile::fake()->image('cross-border-one.jpg', 400, 400),
                UploadedFile::fake()->image('cross-border-two.jpg', 400, 400),
            ],
        ])->assertRedirect(route('seller.products'));

        $this->assertDatabaseHas('products', [
            'vendor_id' => $vendor->id,
            'country' => 'US',
            'city' => 'New York',
            'region' => 'New York',
        ]);
    }

    public function test_country_city_and_all_country_filters_handle_legacy_products(): void
    {
        $seller = User::factory()->create(['role' => 'seller']);
        $vendor = Vendor::create(['user_id' => $seller->id, 'balance' => 0]);
        [$category, $unit] = $this->catalog($seller);
        $haiti = $this->product($vendor, $category, $unit, 'Haiti marketplace item', 'HT', 'Port-au-Prince');
        $haiti->update(['availability_type' => 'selected']);
        $haiti->availabilityCountries()->sync([DB::table('countries')->where('code', 'HT')->value('id')]);
        $us = $this->product($vendor, $category, $unit, 'US marketplace item', 'US', 'New York');
        $us->update(['availability_type' => 'selected']);
        $us->availabilityCountries()->sync([DB::table('countries')->where('code', 'US')->value('id')]);
        $legacy = $this->product($vendor, $category, $unit, 'Legacy marketplace item', null, null);
        $legacy->update(['availability_type' => 'selected']);

        $this->get(route('marketplace.search', ['country' => 'HT', 'city' => 'Port-au-Prince']))
            ->assertSee($haiti->product_name)
            ->assertDontSee('US marketplace item')
            ->assertDontSee('Legacy marketplace item');

        $this->get(route('marketplace.search', ['country' => 'all']))
         ->assertSee('Haiti marketplace item')
         ->assertSee('US marketplace item')
         ->assertDontSee('Legacy marketplace item');
    }

    public function test_account_country_stays_locked_while_profile_location_can_be_updated(): void
    {
        $buyer = User::factory()->create([
            'role' => 'buyer',
            'country' => 'US',
            'city' => 'New York',
            'marketplace_country' => 'HT',
        ]);

        $this->actingAs($buyer)->patch(route('marketplace.profile.update'), [
            'name' => $buyer->name,
            'country' => 'CA',
            'city' => 'Montreal',
        ])->assertSessionHasNoErrors();

        $buyer->refresh();
        $this->assertSame('US', $buyer->country);
        $this->assertSame('Montreal', $buyer->city);
        $this->assertSame('HT', $buyer->marketplace_country);

        $this->actingAs($buyer)->patch(route('marketplace.settings.update'), [
            'country' => 'ES',
            'city' => 'Madrid',
        ])->assertSessionHasNoErrors();

        $buyer->refresh();
        $this->assertSame('US', $buyer->country);
        $this->assertSame('Madrid', $buyer->city);
        $this->assertSame('HT', $buyer->marketplace_country);

        Sanctum::actingAs($buyer);
        $this->postJson('/api/update-user/' . $buyer->id, [
            'country' => 'CA',
            'city' => 'Toronto',
        ])->assertOk();

        $buyer->refresh();
        $this->assertSame('US', $buyer->country);
        $this->assertSame('Toronto', $buyer->city);
    }

    public function test_authenticated_buyer_cannot_change_account_country_with_query_session_or_api_input(): void
    {
        $seller = User::factory()->create(['role' => 'seller']);
        $vendor = Vendor::create(['user_id' => $seller->id, 'balance' => 0]);
        [$category, $unit] = $this->catalog($seller);
        $haiti = $this->product($vendor, $category, $unit, 'Account country item', 'HT', 'Port-au-Prince');
        $unitedStates = $this->product($vendor, $category, $unit, 'Other country item', 'US', 'New York');
        $haiti->update(['availability_type' => 'selected']);
        $haiti->availabilityCountries()->sync([DB::table('countries')->where('code', 'HT')->value('id')]);
        $unitedStates->update(['availability_type' => 'selected']);
        $unitedStates->availabilityCountries()->sync([DB::table('countries')->where('code', 'US')->value('id')]);
        $buyer = User::factory()->create(['role' => 'buyer', 'country' => 'HT', 'marketplace_country' => 'US']);

        $this->actingAs($buyer)->withSession(['marketplace_country' => 'US'])
            ->get(route('marketplace.search', ['country' => 'US']))
            ->assertSee($haiti->product_name)
            ->assertDontSee($unitedStates->product_name);

        $this->actingAs($buyer)->get(route('marketplace.search', ['country' => 'all']))
            ->assertSee($haiti->product_name)
            ->assertDontSee($unitedStates->product_name);

        $this->actingAs($buyer)->get(route('marketplace.product', $unitedStates))
            ->assertNotFound();

        $this->actingAs($buyer)->post(route('marketplace.country.update', 'US'))
            ->assertSessionHas('marketplace_country', 'HT')
            ->assertSessionHas('messege', __('marketplace.account_country_locked'));
        $this->assertSame('HT', session('marketplace_country'));
        $buyer->refresh();
        $this->assertSame('HT', $buyer->marketplace_country);

        $this->actingAs($buyer)->post(route('marketplace.cart.add', $unitedStates), [
            'quantity' => 1,
        ])->assertStatus(422);

        Sanctum::actingAs($buyer);
        $this->getJson('/api/all-products?country=US')
            ->assertOk()
            ->assertJsonMissing(['product_name' => $unitedStates->product_name])
            ->assertJsonFragment(['product_name' => $haiti->product_name]);
    }

    public function test_country_catalog_contains_complete_metadata_for_all_iso_records(): void
    {
        $countries = config('countries.supported');

        $this->assertCount(250, $countries);
        $this->assertSame(250, DB::table('countries')->count());
        foreach ($countries as $code => $metadata) {
            $this->assertMatchesRegularExpression('/^[A-Z]{2}$/', $code);
            $this->assertCount(4, $metadata);
            $this->assertNotEmpty($metadata[0]);
            $this->assertNotEmpty($metadata[1]);
            $this->assertMatchesRegularExpression('/^[A-Z]{3}$/', $metadata[2]);
            $this->assertMatchesRegularExpression('/^\+?[0-9 ()-]+$/', $metadata[3]);
            $this->assertDatabaseHas('countries', [
                'code' => $code,
                'name' => $metadata[0],
                'flag' => $metadata[1],
                'currency_code' => $metadata[2],
                'phone_code' => $metadata[3],
            ]);
        }
    }
}