<?php

return [
    /*
     * Only these normalized ISO 639-1 locales may be selected. Keep this
     * allowlist small so values from sessions, user records, and headers
     * cannot set an arbitrary application locale.
     */
    'supported' => [
        'en' => 'English',
        'fr' => 'Français',
        'ht' => 'Kreyòl Ayisyen',
        'es' => 'Español',
    ],

    'fallback' => 'en',
    'session_key' => 'locale',
];