<?php

return [
    'trial_days' => 30,
    'plans' => [
        [
            'key' => 'essentials',
            'price' => 15,
            'recommended' => false,
            'features' => [
                'listings',
                'messages',
                'orders',
                'basic_analytics',
            ],
        ],
        [
            'key' => 'growth',
            'price' => 25,
            'recommended' => true,
            'features' => [
                'listings',
                'messages',
                'orders',
                'international_sales',
                'price_tiers',
                'sales_analytics',
            ],
        ],
        [
            'key' => 'pro',
            'price' => 50,
            'recommended' => false,
            'features' => [
                'listings',
                'messages',
                'orders',
                'international_sales',
                'price_tiers',
                'sales_analytics',
                'priority_visibility',
                'priority_support',
            ],
        ],
    ],
];