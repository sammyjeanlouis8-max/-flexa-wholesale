(function () {
    function closeSuggestions(except) {
        document.querySelectorAll('[data-search-suggestions]').forEach(function (panel) {
            if (panel !== except) panel.hidden = true;
        });
        document.querySelectorAll('[data-global-search] input').forEach(function (input) {
            if (!except || !except.closest('[data-global-search]')?.contains(input)) input.setAttribute('aria-expanded', 'false');
        });
    }

    function renderSuggestions(panel, input, groups) {
        panel.innerHTML = '';
        if (!groups.length) {
            panel.innerHTML = '<div class="search-empty">' + (window.marketplaceLabels?.noResults || 'No results found.') + '</div>';
            panel.hidden = false;
            input.setAttribute('aria-expanded', 'true');
            return;
        }
        groups.forEach(function (group) {
            var section = document.createElement('section');
            section.className = 'suggestion-group';
            var label = document.createElement('span');
            label.className = 'suggestion-group-label';
            label.textContent = group.label;
            section.appendChild(label);
            group.items.forEach(function (item) {
                var link = document.createElement('a');
                link.className = 'suggestion-item';
                link.href = item.url;
                link.setAttribute('role', 'option');
                var copy = document.createElement('span');
                copy.className = 'suggestion-item-copy';
                var title = document.createElement('span');
                title.className = 'suggestion-item-title';
                title.textContent = item.title;
                var subtitle = document.createElement('span');
                subtitle.className = 'suggestion-item-subtitle';
                subtitle.textContent = item.subtitle || '';
                copy.appendChild(title);
                copy.appendChild(subtitle);
                var arrow = document.createElement('span');
                arrow.className = 'suggestion-arrow';
                arrow.textContent = '→';
                link.appendChild(copy);
                link.appendChild(arrow);
                section.appendChild(link);
            });
            panel.appendChild(section);
        });
        panel.hidden = false;
        input.setAttribute('aria-expanded', 'true');
    }

    function setupSearch(form) {
        var input = form.querySelector('input[name="q"]');
        var panel = form.querySelector('[data-search-suggestions]');
        if (!input || !panel) return;
        var timer;
        var requestId = 0;
        input.addEventListener('input', function () {
            window.clearTimeout(timer);
            var term = input.value.trim();
            if (term.length < 2) {
                panel.hidden = true;
                input.setAttribute('aria-expanded', 'false');
                return;
            }
            timer = window.setTimeout(function () {
                var currentRequest = ++requestId;
                var endpoint = new URL(form.action, document.baseURI);
                endpoint.pathname = endpoint.pathname.replace(/\/search\/?$/, '/search/suggestions');
                endpoint.search = 'q=' + encodeURIComponent(term);
                fetch(endpoint.toString(), {
                    headers: { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest' }
                })
                    .then(function (response) {
                        if (!response.ok) throw new Error('Search suggestions failed');
                        return response.json();
                    })
                    .then(function (data) {
                        if (currentRequest === requestId) renderSuggestions(panel, input, data.groups || []);
                    })
                    .catch(function () {
                        if (currentRequest === requestId) panel.hidden = true;
                    });
            }, 260);
        });
        input.addEventListener('focus', function () {
            if (panel.innerHTML && input.value.trim().length >= 2) panel.hidden = false;
        });
    }

    function setupDrawer() {
        var drawer = document.getElementById('marketplace-drawer');
        var scrim = document.querySelector('[data-menu-close]');
        if (!drawer || !scrim) return;
        var lastFocused;
        function open() {
            lastFocused = document.activeElement;
            drawer.classList.add('is-open');
            scrim.hidden = false;
            requestAnimationFrame(function () { scrim.classList.add('is-open'); });
            drawer.setAttribute('aria-hidden', 'false');
            document.body.classList.add('nav-open');
            document.querySelectorAll('[data-menu-open]').forEach(function (button) { button.setAttribute('aria-expanded', 'true'); });
            var closeButton = drawer.querySelector('[data-menu-close]');
            if (closeButton) closeButton.focus();
        }
        function close() {
            drawer.classList.remove('is-open');
            scrim.classList.remove('is-open');
            drawer.setAttribute('aria-hidden', 'true');
            document.body.classList.remove('nav-open');
            document.querySelectorAll('[data-menu-open]').forEach(function (button) { button.setAttribute('aria-expanded', 'false'); });
            window.setTimeout(function () { if (!drawer.classList.contains('is-open')) scrim.hidden = true; }, 240);
            if (lastFocused && typeof lastFocused.focus === 'function') lastFocused.focus();
        }
        document.querySelectorAll('[data-menu-open]').forEach(function (button) { button.addEventListener('click', open); });
        document.querySelectorAll('[data-menu-close]').forEach(function (button) { button.addEventListener('click', close); });
        document.addEventListener('keydown', function (event) { if (event.key === 'Escape' && drawer.classList.contains('is-open')) close(); });
    }

    document.addEventListener('DOMContentLoaded', function () {
        document.querySelectorAll('[data-global-search]').forEach(setupSearch);
        setupDrawer();
        document.querySelectorAll('[data-market-option]').forEach(function (button) {
            button.addEventListener('click', function () {
                var form = button.closest('form');
                var select = form && form.querySelector('select[name="country"]');
                if (!form || !select) return;
                select.value = button.dataset.marketOption;
                select.dispatchEvent(new Event('change', { bubbles: true }));
            });
        });
        document.querySelectorAll('[data-quick-actions]').forEach(function (trigger) {
            var menu = document.getElementById(trigger.getAttribute('aria-controls'));
            if (!menu) return;
            trigger.addEventListener('click', function () {
                var isOpen = trigger.getAttribute('aria-expanded') === 'true';
                trigger.setAttribute('aria-expanded', String(!isOpen));
                menu.hidden = isOpen;
            });
            document.addEventListener('click', function (event) {
                if (!event.target.closest('.seller-quick-actions')) {
                    trigger.setAttribute('aria-expanded', 'false');
                    menu.hidden = true;
                }
            });
        });
        document.addEventListener('click', function (event) {
            if (!event.target.closest('[data-global-search]')) closeSuggestions();
        });
        document.querySelectorAll('[data-coming-soon]').forEach(function (element) {
            element.addEventListener('click', function (event) { event.preventDefault(); });
        });
    });
}());