import { initializeApp } from "https://www.gstatic.com/firebasejs/9.0.0/firebase-app.js";
import {
    getFirestore,
    collection,
    query,
    orderBy,
    onSnapshot,
    addDoc,
    serverTimestamp,
    setDoc,
    doc,
    getDoc,
    updateDoc,
    arrayUnion,
} from "https://www.gstatic.com/firebasejs/9.0.0/firebase-firestore.js";

// Your web app's Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyCixCv4qzi8KC9mp-Ie-FqDEr_DjnFQ1Kc",
    authDomain: "explore-d42ae.firebaseapp.com",
    databaseURL: "https://explore-d42ae-default-rtdb.firebaseio.com",
    projectId: "explore-d42ae",
    storageBucket: "explore-d42ae.appspot.com",
    messagingSenderId: "379842532935",
    appId: "1:379842532935:web:04dc899fb1028dd3ed0362",
    measurementId: "G-F1X9RD4FPH",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

// Cache selectors
const $chatHeaderPic = $("#chatHeaderPic");
const $chatHeaderName = $("#chatHeaderName");
const $chatMessages = $("#chatMessages");
const $chatListContainer = $(".chat-list");

// Function to create Firebase user
function createFirebaseUser(user) {
    const firebaseUserCollection = "Users";
    setDoc(doc(db, firebaseUserCollection, "admin"), user)
        .then(() => {
            console.log("User created successfully");
        })
        .catch((error) => {
            console.error("Error while creating firebase user", error);
        });
}

// Function to check if the Firebase user exists
function checkFirebaseUserExists() {
    const firebaseUserCollection = "Users"; // Replace with your actual collection name
    const docRef = doc(db, firebaseUserCollection, "admin");

    return getDoc(docRef)
        .then((docSnapshot) => {
            return docSnapshot.exists();
        })
        .catch((error) => {
            console.error("Error checking firebase user existence:", error);
            return null;
        });
}

// Check if the user exists, and create it if it doesn't exist
checkFirebaseUserExists().then((exists) => {
    if (exists) {
        console.log("User already exists.");
    } else {
        console.log("User does not exist. Creating user...");
        createFirebaseUser({ contacts: [] });
    }
});

// Function to fetch and display contacts
function getFirebaseUserData() {
    const firebaseUserCollection = "Users";
    const docRef = doc(db, firebaseUserCollection, "admin");

    return getDoc(docRef)
        .then((docSnapshot) => {
            if (docSnapshot.exists()) {
                const data = docSnapshot.data();
                console.log("Full document data:", data);

                const contacts = data.contacts || [];
                const contactsInfo = contacts.map((contact) => {
                    const timestamp = contact.last_message_timestamp
                        ? new Date(contact.last_message_timestamp)
                        : null;

                    let formattedTimestamp = "No timestamp";
                    if (timestamp) {
                        const dateFormatter = new Intl.DateTimeFormat("en-US", {
                            day: "2-digit",
                            month: "2-digit",
                            year: "2-digit",
                        });
                        const timeFormatter = new Intl.DateTimeFormat("en-US", {
                            hour: "numeric",
                            minute: "numeric",
                            hour12: true,
                        });

                        const date = dateFormatter.format(timestamp);
                        const time = timeFormatter.format(timestamp);

                        formattedTimestamp = `${time}\n${date}`;
                    }
                    return {
                        contact_name: contact.contact_name,
                        last_message: contact.last_message,
                        last_message_timestamp: formattedTimestamp,
                        profile_pic: contact.profile_pic,
                        contact_phone: contact.contact_phone,
                    };
                });

                console.log("Contacts info:", contactsInfo);
                populateChatList(contactsInfo);
            } else {
                console.log("No such document!");
                return null;
            }
        })
        .catch((error) => {
            console.error("Error getting document:", error);
            return null;
        });
}

// Function to populate the chat list in HTML
function populateChatList(contactsInfo) {
    $chatListContainer.empty();

    contactsInfo.forEach((contact) => {
        const $chatItem = $(`
            <div class="chat-item" data-id="${contact.contact_phone}">
                <div class="profile">
                    <img src="${contact.profile_pic}" alt="Profile Picture" class="profile-pic">
                </div>
                <div class="chat-info">
                    <div class="contact-name">${contact.contact_name}</div>
                    <div class="last-message">${contact.last_message}</div>
                </div>
                <div class="timestamp">${contact.last_message_timestamp}</div>
            </div>
        `);

        $chatItem.on("click", function () {
            const docId = contact.contact_phone;
            setupRealTimeListener(docId);
            getDocumentData("AdminMessages", docId).then((data) => {
                if (data) {
                    console.log("Fetched document data:", data);
                    displayChat(
                        data,
                        contact.contact_name,
                        contact.profile_pic,
                        docId
                    );
                }
            });
        });

        $chatListContainer.append($chatItem);
    });
}

// Function to get data from a specific document by its ID
async function getDocumentData(collectionName, docId) {
    const docRef = doc(db, collectionName, docId);
    console.log("Fetching document with ID:", docId);
    try {
        const docSnap = await getDoc(docRef);

        if (docSnap.exists()) {
            console.log("Document data:", docSnap.data());
            return docSnap.data();
        } else {
            console.log("No such document!");
            return null;
        }
    } catch (error) {
        console.error("Error getting document:", error);
        return null;
    }
}

// Function to display chat data
function displayChat(data, name, profile, phone) {
    $("#chatBox").removeClass("d-none");
    $("#primaryBox").addClass("d-none");

    var offcanvasElement = document.getElementById("chatListOffcanvas");
    var offcanvas = bootstrap.Offcanvas.getInstance(offcanvasElement);
    if (offcanvas) {
        offcanvas.hide();
    }
    const { messages } = data;
    const contact_name = name;
    const profile_pic = profile;
    const contact_phone = phone;

    $chatHeaderPic.attr("src", profile_pic);
    $chatHeaderName.text(contact_name);
    $chatMessages.empty();

    if (!Array.isArray(messages)) {
        console.error("Invalid messages format");
        return;
    }

    messages.forEach((message) => {
        const $messageDiv = $(`
            <div class="message ${
                message.sender_phone === "admin" ? "sent" : "received"
            }">
                <div class="message-text">${message.message}</div>
               
            </div>
        `);

        $chatMessages.append($messageDiv);
    });

    $("#contactPhone").val(contact_phone);

    // Scroll to the bottom to show the latest message
    $chatMessages.scrollTop($chatMessages[0].scrollHeight);
}

// Set up real-time listener for all documents in AdminMessages collection
function setupAdminMessagesListener() {
    const messagesCollection = collection(db, "AdminMessages");

    const unsubscribe = onSnapshot(
        messagesCollection,
        (snapshot) => {
            snapshot.docChanges().forEach((change) => {
                if (change.type === "added") {
                    console.log("New message: ", change.doc.data());
                }
                if (change.type === "modified") {
                    console.log("Modified message: ", change.doc.data());
                    checkDocumentFields(change.doc);
                }
                if (change.type === "removed") {
                    console.log("Removed message: ", change.doc.data());
                }
            });
        },
        (error) => {
            console.error("Error listening to snapshot: ", error);
        }
    );

    return unsubscribe;
}

// Function to check fields inside a document
async function checkDocumentFields(docSnap) {
    const data = docSnap.data();
    console.log("Checking fields in document ID: ", docSnap.id);

    if (data.messages) {
        console.log("Messages field updated: ", data.messages);

        // Fetch the admin user document
        const userDocRef = doc(db, "Users", "admin");
        const userDocSnapshot = await getDoc(userDocRef);

        if (userDocSnapshot.exists()) {
            const userData = userDocSnapshot.data();
            const contacts = userData.contacts || [];
            const contactIndex = contacts.findIndex(
                (contact) => contact.contact_phone === docSnap.id
            );

            if (contactIndex !== -1) {
                const contact = contacts[contactIndex];
                contact.last_message =
                    data.messages[data.messages.length - 1].message;
                contact.last_message_timestamp =
                    data.messages[data.messages.length - 1].timestamp;

                // Remove the contact from its current position and insert it at the beginning
                contacts.splice(contactIndex, 1);
                contacts.unshift(contact);

                // Update the admin user document with the modified contacts array
                await updateDoc(userDocRef, { contacts });

                console.log("Updated contacts in Users/admin document.");
            } else {
                console.log(
                    "No matching contact found in Users/admin document."
                );
            }
        } else {
            console.log("No Users/admin document found.");
        }
    }
}

// Function to set up real-time listener for a specific chat document
function setupRealTimeListener(contactPhone) {
    const docRef = doc(db, "AdminMessages", contactPhone);

    const unsubscribe = onSnapshot(docRef, (docSnap) => {
        const data = docSnap.data();
        if (data) {
            displayChat(
                data,
                $("#chatHeaderName").text(),
                $("#chatHeaderPic").attr("src"),
                contactPhone
            );
        }
    });

    return unsubscribe;
}

// Function to set up real-time listener for the contact list
function setupContactListListener() {
    const docRef = doc(db, "Users", "admin");

    const unsubscribe = onSnapshot(docRef, (docSnap) => {
        const data = docSnap.data();
        if (data) {
            const contacts = data.contacts || [];
            const contactsInfo = contacts.map((contact) => {
                const timestamp = contact.last_message_timestamp
                    ? new Date(contact.last_message_timestamp)
                    : null;

                let formattedTimestamp = "No timestamp";
                if (timestamp) {
                    const dateFormatter = new Intl.DateTimeFormat("en-US", {
                        day: "2-digit",
                        month: "2-digit",
                        year: "2-digit",
                    });
                    const timeFormatter = new Intl.DateTimeFormat("en-US", {
                        hour: "numeric",
                        minute: "numeric",
                        hour12: true,
                    });

                    const date = dateFormatter.format(timestamp);
                    const time = timeFormatter.format(timestamp);

                    formattedTimestamp = `${time}\n${date}`;
                }
                return {
                    contact_name: contact.contact_name,
                    last_message: contact.last_message,
                    last_message_timestamp: formattedTimestamp,
                    profile_pic: contact.profile_pic,
                    contact_phone: contact.contact_phone,
                };
            });

            populateChatList(contactsInfo);
        }
    });

    return unsubscribe;
}

// Fetch and display contacts on page load
document.addEventListener("DOMContentLoaded", () => {
    setupContactListListener(); // Set up real-time listener for contact list
    getFirebaseUserData();
    setupAdminMessagesListener();
});

// Send a new message
document.addEventListener("DOMContentLoaded", () => {
    document
        .getElementById("messageForm")
        .addEventListener("submit", async (e) => {
            e.preventDefault();
            const messageInput = document.getElementById("messageInput");
            const message = messageInput.value;
            const contactPhone = document.getElementById("contactPhone").value;

            if (!contactPhone) {
                toastr.error("No contact phone number specified.");
                return;
            }

            try {
                const docRef = doc(db, "AdminMessages", contactPhone);
                const docSnap = await getDoc(docRef);

                if (docSnap.exists()) {
                    await updateDoc(docRef, {
                        messages: arrayUnion({
                            sender_phone: "admin",
                            receiver_phone: contactPhone,
                            message: message,
                            timestamp: new Date().toISOString(),
                        }),
                    });
                } else {
                    await setDoc(docRef, {
                        messages: [
                            {
                                sender_phone: "admin",
                                receiver_phone: contactPhone,
                                message: message,
                                timestamp: new Date().toISOString(),
                            },
                        ],
                    });
                }

                messageInput.value = "";
                console.log("Message sent");
            } catch (error) {
                console.error("Error adding message: ", error);
            }
        });
});
