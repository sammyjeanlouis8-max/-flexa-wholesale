$(document).ready(function () {
    $.ajaxSetup({
        headers: {
            "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content"),
        },
    });

    $(".select2").select2();

    $(".js-example-basic-single").select2({
        theme: "classic",
        tags: true,
    });

    //Initialize Select2 Elements
    $(".select2bs4").select2({
        theme: "bootstrap4",
    });

    $(".dropify").dropify();

    $("#description").summernote({
        height: 300,
        focus: false,
    });

    var base_url = localStorage.getItem("base_url");

    var ajax_url = "";

    var type = "";

    var categoryTable = $("#category-table").DataTable({
        searching: true,
        processing: true,
        serverSide: true,
        ordering: false,
        responsive: true,
        stateSave: true,
        ajax: {
            url: base_url+"/categories",
        },

        columns: [
            { data: "image", name: "image" },
            { data: "category_name", name: "category_name" },
            { data: "status", name: "status" },
            {
                data: "action",
                name: "action",
                orderable: false,
                searchable: false,
            },
        ],
    });
    $(document).ready(function() {
    console.log('Product:', window.product); // This should log the product object or null
});
$(document).ready(function() {
    var product = null;
    // Check if the 'product' variable exists and is not null
    if (typeof window.product !== 'undefined' && window.product) {
        product = window.product;
        console.log('Product:', product);
        loadEditVariants(window.product,window.productVariants);
    } else {
         product = null;
        console.log('No product data available.');
    }

    // Check if a category is already selected (for edit page)
    var selectedCategoryId = $('#category_id').val();
    if (selectedCategoryId) {
        fetchVariantsForCategory(selectedCategoryId);
    }

    // Trigger fetching variants when the category changes
    $('.product-category').change(function() {
        var categoryId = $(this).val();
        if (categoryId) {
            fetchVariantsForCategory(categoryId);
        }
    });

    // Function to fetch variants for a selected category
    function fetchVariantsForCategory(categoryId) {
        $.ajax({
            url: '/get-variants/' + categoryId,
            type: 'GET',
            dataType: 'json',
            success: function(response) {
                console.log(response);
                if (response.data.length > 0) {
                    var variantsHtml = '';
                    $.each(response.data, function(index, variant) {
                        var selectedValues = (typeof product !== 'undefined' && product) 
                            ? getSelectedValuesForVariant(variant.id) 
                            : [];
                        variantsHtml += `
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="${variant.id}">${variant.variant_name}</label>
                                    <select class="form-control select2bs4" name="variants[${variant.id}][values][]" multiple="">
                                        ${getVariantOptions(variant.variant_value, selectedValues)}
                                    </select>
                                    <input type="hidden" name="variants[${variant.id}][name]" value="${variant.variant_name}">
                                </div>
                            </div>
                        `;
                    });
                    $('#variantBody .row').html(variantsHtml);

                    // Reinitialize select2bs4 for dynamically added elements
                    $('.select2bs4').select2({
                        theme: 'bootstrap4'
                    });
                } else {
                    $('#variantBody .row').html('<p>No variants available for this category.</p>');
                }
            },
            error: function(xhr, status, error) {
                console.error('Error fetching variants:', error);
            }
        });
    }

    function loadEditVariants(product,productVariants) {
        console.log(product)
        if (!product || !productVariants) {
            console.error('Product or productVariants is undefined');
            return;
        }

        $.each(productVariants, function(index, variant) {
            var selectedValues = variant.pivot.variant_value ? variant.pivot.variant_value.split(',').map(val => val.trim()) : [];
            var variantsHtml = `
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="${variant.id}">${variant.pivot.variant_name}</label>
                        <select class="form-control select2bs4" name="variants[${variant.id}][values][]" multiple="">
                            ${getVariantOptions(variant.pivot.variant_value, selectedValues)}
                        </select>
                        <input type="hidden" name="variants[${variant.id}][name]" value="${variant.pivot.variant_name}">
                    </div>
                </div>
            `;
            $('#variantBody .row').append(variantsHtml);
        });

        // Reinitialize select2bs4 for dynamically added elements
        $('.select2bs4').select2({
            theme: 'bootstrap4'
        });
    }

    function getSelectedValuesForVariant(variantId) {
        console.log(product,11111)

        if (!product || !productVariants) {
            console.error('Product or productVariants is undefined');
            return [];
        }
        var selectedVariant = productVariants.find(v => v.id == variantId);
        return selectedVariant ? (selectedVariant.pivot.variant_value ? selectedVariant.pivot.variant_value.split(',').map(val => val.trim()) : []) : [];
    }

    function getVariantOptions(values, selectedValues) {
        var options = '';
        var valuesArray = typeof values === 'string' ? values.split(',').map(val => val.trim()) : values;

        $.each(valuesArray, function(index, value) {
            var isSelected = selectedValues.includes(value) ? 'selected' : '';
            options += `<option value="${value}" ${isSelected}>${value}</option>`;
        });
        return options;
    }
});


    var unitTable = $("#unit-table").DataTable({
        searching: true,
        processing: true,
        serverSide: true,
        ordering: false,
        responsive: true,
        stateSave: true,
        ajax: {
            url: base_url+"/units",
        },

        columns: [
            { data: "unit_name", name: "unit_name" },
            { data: "status", name: "status" },
            {
                data: "action",
                name: "action",
                orderable: false,
                searchable: false,
            },
        ],
    });

    var variantTable = $("#variant-table").DataTable({
        searching: true,
        processing: true,
        serverSide: true,
        ordering: false,
        responsive: true,
        stateSave: true,
        ajax: {
            url: base_url+"/variants",
        },

        columns: [
            { data: "category", name: "category" },
            { data: "variant_name", name: "variant_name" },
            {
                data: "action",
                name: "action",
                orderable: false,
                searchable: false,
            },
        ],
    });
    var vendorTable = $("#vendor-table").DataTable({
        searching: true,
        processing: true,
        serverSide: true,
        ordering: false,
        responsive: true,
        stateSave: true,
        ajax: {
            url: base_url+"/vendors",
            data: function (d) {
                d.status = $("#filter-status").val();
            },
        },
        columns: [
            { data: "user.name", name: "user.name" },
            { data: "user.email", name: "user.email" },
            { data: "user.phone", name: "user.phone" },
            { data: "user.company_name", name: "user.company_name" },
            { data: "user.status", name: "user.status" },
            { data: "action", name: "action", orderable: false, searchable: false },
        ],
    });
     var sliderTable = $("#slider-table").DataTable({
        searching: true,
        processing: true,
        serverSide: true,
        ordering: false,
        responsive: true,
        stateSave: true,
        ajax: {
            url: base_url+"/sliders",
        },

        columns: [
            { data: "title", name: "title" },
            { data: "src", name: "src" },
            { data: "status", name: "status" },
            {
                data: "action",
                name: "action",
                orderable: false,
                searchable: false,
            },
        ],
    });
    $(document).on("click", ".active-slider", function (e) {
        e.preventDefault();
        if (confirm("Do you want to active this?")) {
            var get_slider_id = $(this).data("id");
            $.ajax({
                url: base_url+"/active-slider/"+get_slider_id,
                type: "PATCH",
                dataType: "json",
                success: function (data) {
                    $(".data-table").DataTable().ajax.reload(null, false);
                    toastr.success(data.message);
                },error: function (error) {
               $(".data-table").DataTable().ajax.reload(null, false);
                    toastr.error(error.responseJSON.message); }
            });
        }
    });

    $(document).on("click", ".decline-slider", function (e) {
        e.preventDefault();
        var get_slider_id = $(this).data("id");
        if (confirm("Do you want to inactive this?")) {
            $.ajax({
                url: base_url+"/decline-slider/"+get_slider_id,
                type: "PATCH",
                dataType: "json",
                success: function (data) {
                    $(".data-table").DataTable().ajax.reload(null, false);
                    toastr.success(data.message);
                },error: function (error) {
               $(".data-table").DataTable().ajax.reload(null, false);
                    toastr.error(error.responseJSON.message); }
            });
        }
    }); $(document).on("click", ".delete-slider", function (e) {
        e.preventDefault();
        var int_slider_id = $(this).data("id");
        if (confirm("Do you want to delete this?")) {
            ajax_url = base_url+"/sliders/"+int_slider_id;
            $.ajax({
                url: ajax_url,
                type: "DELETE",
                dataType: "json",
                success: function (data) {
                    $(".data-table").DataTable().ajax.reload(null, false);
                    toastr.success(data.message);
                },error: function (error) {
               $(".data-table").DataTable().ajax.reload(null, false);
                    toastr.error(error.responseJSON.message); }
            });
        }
    });
    var subcategoryTable = $("#subcategory-table").DataTable({
        searching: true,
        processing: true,
        serverSide: true,
        ordering: false,
        responsive: true,
        stateSave: true,
        ajax: {
            url: base_url+"/subcategories",
            data: function (d) {
                (d.status = $("#filter-status").val()),
                    (d.category_id = $("#selected_category_id").val()),
                    (d.search = $(".dataTables_filter input").val());
            },
        },

        columns: [
            { data: "image", name: "image" },
            { data: "subcategory_name", name: "subcategory_name" },
            { data: "category", name: "category" },
            { data: "status", name: "status" },
            {
                data: "action",
                name: "action",
                orderable: false,
                searchable: false,
            },
        ],
    }); 
    var withdrawTable = $("#withdraw-table").DataTable({
        searching: true,
        processing: true,
        serverSide: true,
        ordering: false,
        responsive: true,
        stateSave: true,
        ajax: {
            url: base_url+"/withdraw-requests",
            data: function (d) {
                d.status = $("#filter-status").val();
                d.toDate = $("#toDate").val();
                d.fromDate = $("#fromDate").val();
                d.vendorId = $("#vendorId").val();
            },
        },
        columns: [
            { data: "DT_RowIndex", name: "DT_RowIndex", orderable: false, searchable: false },
            { data: "vendor", name: "vendor" },
            { data: "amount", name: "amount" },
            { data: "date", name: "date" },{
                data: "tnx_id",
                name: "tnx_id",
                render: function(data, type, row) {
                    return `<input type="text" class="form-control transaction-id" data-id="${row.id}" value="${data || ''}" placeholder="Enter Transaction ID">`;
                },
                orderable: false,
                searchable: false,
            },
            { data: "status", name: "status" },
            
            {
                data: "action",
                name: "action",
                orderable: false,
                searchable: false,
            },
        ],
        drawCallback: function () {
            $(".status-dropdown").change(function () {
                var orderId = $(this).data("id");
                var newStatus = $(this).val();
                var transactionId = $(`input.transaction-id[data-id='${orderId}']`).val();
                if (newStatus == "Approved" && !transactionId) {
                    toastr.error("Please enter a transaction ID to approve this request.")
                    $(this).val($(this).data("original-status")); // Revert to original status
                    return;
                }
                if (confirm("Are you sure you want to change the status to " + newStatus + "?")) {
                    $.ajax({
                        url: base_url + "/withdraw/" + orderId + "/status",
                        method: "PUT",
                        data: { status: newStatus, transaction_id: transactionId },
                        success: function (response) {
                            toastr.success("Status updated successfully.")
                            withdrawTable.ajax.reload(null, false); 
                        },
                        error: function (xhr) {
                            console.log(xhr);
                            toastr.error(xhr.responseJson.message)

                        },
                    });
                }
            });
        },
    });
    
     var refundTable = $("#refund-table").DataTable({
        searching: true,
        processing: true,
        serverSide: true,
        ordering: false,
        responsive: true,
        stateSave: true,
        ajax: {
            url: base_url+"/refunds",
            data: function (d) {
                d.status = $("#filter-status").val();
                d.toDate = $("#toDate").val();
                d.fromDate = $("#fromDate").val();
                d.vendorId = $("#vendorId").val();
            },
        },
        columns: [
            { data: "DT_RowIndex", name: "DT_RowIndex", orderable: false, searchable: false },
            { data: "order_no", name: "order_no" },
            { data: "user_name", name: "user_name" },  
            { data: "payment_method", name: "payment_method" },
            { data: "total_amount", name: "total_amount" },
            { data: "created_at", name: "created_at" },
            {
                data: "action",
                name: "action",
                orderable: false,
                searchable: false,
            },
        ],
       
    });
    $(document).on('click', '.show-refund-details', function () {
    var refundId = $(this).data('id');

    $.ajax({
        url: base_url + '/refund-details/' + refundId,
        method: 'GET',
        success: function (response) {
            if (response.error) {
                $('#card-content').html('<p>' + response.error + '</p>');
            } else {
                console.log(response);

                // Assuming `response` contains an array of refund details
                var cardDetails = `
                    <div class="card">
                        <div class="card-body"> 
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Vendor Name</th>
                                        <th>Product Name</th>
                                        <th>Product Total Price</th>
                                        <th>Tax</th>
                                        <th>Shipping Cost</th>
                                        <th>Total Amount</th>
                                    </tr>
                                </thead>
                                <tbody id="table-body">
                                </tbody>
                            </table>
                        </div>
                    </div>
                `;

                $('#card-content').html(cardDetails);

                // Assuming `response.refundDetails` contains the data array
                response.forEach(function (item) {
                    var row = `
                        <tr>
                            <td>${item.vendor.user.name}</td>
                            <td>${item.product.product_name}</td>
                            <td>${parseFloat(item.refund.product_total_price)}</td>
                            <td>${(item.unit_total_price * item.orderdetail.tax_percentage) / 100}</td>
                            <td>${parseFloat(item.shipping_cost)}</td>
                            <td>${item.refund.total_amount}</td>
                        </tr>
                    `;
                    $('#table-body').append(row);
                });
            }
        },
        error: function (error) {
            console.log(error);
            $('#card-content').html('<p>Failed to load card details.</p>');
        }
    });
});

    var orderTable = $("#x-table").DataTable({
        searching: true,
        processing: true,
        serverSide: true,
        ordering: false,
        responsive: true,
        stateSave: true,
        ajax: {
            url: base_url+"/orders",
            data: function (d) {
                d.fromDate = $("#fromDate").val();
                d.toDate = $("#toDate").val();
                d.status = $("#filter-status").val();
                d.search = $(".dataTables_filter input").val();
            },
        },
        columns: [
            {
                data: "DT_RowIndex",
                name: "DT_RowIndex",
                orderable: false,
                searchable: false,
            },
            { data: "order_no", name: "order_no" },
            { data: "user_name", name: "user_name" },
            { data: "date", name: "date" },
            { data: "total_cost", name: "total_cost" },
            { data: "payment_method", name: "payment_method" },
            { data: "status", name: "status" },
            {
                data: "action",
                name: "action",
                orderable: false,
                searchable: false,
            },
        ],
        drawCallback: function () {
            $(".order-status-dropdown").change(function () {
                var orderId = $(this).data("id");
                var newStatus = $(this).val();
                if (confirm("Are you sure you want to change the status to "+newStatus+"?")) {
                    $.ajax({
                        url: base_url+"/orders/"+orderId+"/status",
                        method: "PUT",
                        data: { status: newStatus },
                        success: function (response) {
                            toastr.success('Status Updated Successfully');
                            orderTable.ajax.reload(null, false); // Reload DataTable without resetting pagination
                        },
                        error: function (xhr) {
                            toastr.error(xhr.responseJSON.error);
                            orderTable.ajax.reload(null, false);
                        },
                    });
                }
            });
        },
    });
    
    $('.filter-order').on('click', function () {
        orderTable.draw();
    });
      // Handle the eye button click to open the modal and load order details
      $(document).on('click', '.show-details', function () {
        var orderId = $(this).data('id');
        $('#orderDetailsModal').modal('show');
        $.ajax({
            url: base_url+'/orders/'+orderId,
            method: 'GET',
            success: function (data) {
                $('#order-details-content').html(data);
            },
            error: function (error) {
                console.error('Error fetching order details:', error);
                $('#order-details-content').html('<p>Error loading order details.</p>');
            }
        });
    });
    $(".filter-subcategory").click(function (e) {
        e.preventDefault();
        subcategoryTable.draw();
    });

    var productTable = $("#product-table").DataTable({
        searching: true,
        processing: true,
        serverSide: true,
        ordering: false,
        responsive: true,
        stateSave: true,
        ajax: {
            url: base_url + "/products",
            data: function (d) {
                d.category_id = $("#category_id").val();
                d.subcategory_id = $("#subcategory_id").val();
                d.search = $(".dataTables_filter input").val();
            },
        },
        columns: [
            { data: "DT_RowIndex", name: "DT_RowIndex", orderable: false, searchable: false },
            { data: "product_name", name: "product_name" },
            { data: "image", name: "image" },
            { data: "category", name: "category" },
            { data: "unit", name: "unit" },
            { data: "product_price", name: "product_price" },
            { data: "product_stock", name: "product_stock" },
            { data: "status", name: "status" },
            { data: "action", name: "action", orderable: false, searchable: false }
        ]
    });
    

    $(document).on("click", ".delete-category", function (e) {
        e.preventDefault();
        var int_category_id = $(this).data("id");
        if (confirm("Do you want to delete this?")) {
            ajax_url = base_url+"/categories/"+int_category_id;
            $.ajax({
                url: ajax_url,
                type: "DELETE",
                dataType: "json",
                success: function (data) {
                    $(".data-table").DataTable().ajax.reload(null, false);
                    toastr.success(data.message);
                },error: function (error) {
               $(".data-table").DataTable().ajax.reload(null, false);
                    toastr.error(error.responseJSON.message); }
            });
        }
    });
    $(document).on("click", ".delete-product", function (e) {
        e.preventDefault();
        var int_product_id = $(this).data("id");
        if (confirm("Do you want to delete this?")) {
            ajax_url = base_url+"/products/"+int_product_id;
            $.ajax({
                url: ajax_url,
                type: "DELETE",
                dataType: "json",
                success: function (data) {
                    $(".data-table").DataTable().ajax.reload(null, false);
                    toastr.success(data.message);
                },error: function (error) {
                    console.log(error);
               $(".data-table").DataTable().ajax.reload(null, false);
                    toastr.error(error.responseJSON.message); }
            });
        }
    });
    $(document).on("click", ".delete-variant", function (e) {
        e.preventDefault();
        var int_variant_id = $(this).data("id");
        if (confirm("Do you want to delete this?")) {
            ajax_url = base_url+"/variants/"+int_variant_id;
            $.ajax({
                url: ajax_url,
                type: "DELETE",
                dataType: "json",
                success: function (data) {
                    $(".data-table").DataTable().ajax.reload(null, false);
                    toastr.success(data.message);
                },error: function (error) {
               $(".data-table").DataTable().ajax.reload(null, false);
                    toastr.error(error.responseJSON.message); }
            });
        }
    });

    $(document).on("click", ".delete-unit", function (e) {
        e.preventDefault();
        var int_unit_id = $(this).data("id");
        if (confirm("Do you want to delete this?")) {
            ajax_url = base_url+"/units/"+int_unit_id;
            $.ajax({
                url: ajax_url,
                type: "DELETE",
                dataType: "json",
                success: function (data) {
                    $(".data-table").DataTable().ajax.reload(null, false);
                    toastr.success(data.message);
                },error: function (error) {
               $(".data-table").DataTable().ajax.reload(null, false);
                    toastr.error(error.responseJSON.message); }
            });
        }
    });
    $(document).on('click', '.show-card-details', function () {
        var withdrawRequestId = $(this).data('id');

        $.ajax({
            url: base_url+'/withdraw-requests/'+withdrawRequestId+'/card-details',
            method: 'GET',
            success: function (response) {
                if (response.error) {
                    $('#card-content').html('<p>'+response.error+'</p>');
                } else {
                    console.log(response)
                  var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                    var expiryMonth = monthNames[response.expiry_month - 1]; // Subtract 1 because months are zero-indexed in the array
                   
                    var cardDetails = `
                        <div class="card">
                            <div class="card-body"> 
                                <p class="card-text">Bank Name: ${response.bank_name}</p>
                                <p class="card-text">Account No: ${response.account_no}</p>
                                <p class="card-text">CVC: ${response.cvc}</p>
                                <p class="card-text">Expiry Date: ${expiryMonth} ${response.expiry_year}</p>
                            </div>
                        </div>
                    `;
                    $('#card-content').html(cardDetails);
                }
            },
            error: function (error) {
                console.log(error);
                $('#card-content').html('<p>Failed to load card details.</p>');
            }
        });
    });
  


    $(document).on("click", ".delete-subcategory", function (e) {
        e.preventDefault();
        var int_subcategory_id = $(this).data("id");
        if (confirm("Do you want to delete this?")) {
            ajax_url = base_url+"/subcategories/"+int_subcategory_id;
            $.ajax({
                url: ajax_url,
                type: "DELETE",
                dataType: "json",
                success: function (data) {
                    $(".data-table").DataTable().ajax.reload(null, false);
                    toastr.success(data.message);
                },error: function (error) {
               $(".data-table").DataTable().ajax.reload(null, false);
                    toastr.error(error.responseJSON.message); }
            });
        }
    });
    
    $(document).on("click", ".active-category", function (e) {
        e.preventDefault();
        if (confirm("Do you want to active this?")) {
            var get_category_id = $(this).data("id");
            $.ajax({
                url: base_url+"/active-category/"+get_category_id,
                type: "PATCH",
                dataType: "json",
                success: function (data) {
                    $(".data-table").DataTable().ajax.reload(null, false);
                    toastr.success(data.message);
                },error: function (error) {
               $(".data-table").DataTable().ajax.reload(null, false);
                    toastr.error(error.responseJSON.message); }
            });
        }
    });

    $(document).on("click", ".decline-category", function (e) {
        e.preventDefault();
        var get_category_id = $(this).data("id");
        if (confirm("Do you want to inactive this?")) {
            $.ajax({
                url: base_url+"/decline-category/"+get_category_id,
                type: "PATCH",
                dataType: "json",
                success: function (data) {
                    $(".data-table").DataTable().ajax.reload(null, false);
                    toastr.success(data.message);
                },error: function (error) {
               $(".data-table").DataTable().ajax.reload(null, false);
                    toastr.error(error.responseJSON.message); }
            });
        }
    });

    $(document).on("click", ".active-vendor", function (e) {
        e.preventDefault();
        if (confirm("Do you want to active this?")) {
            var get_vendor_id = $(this).data("id");
            $.ajax({
                url: base_url+"/active-vendor/"+get_vendor_id,
                type: "PATCH",
                dataType: "json",
                success: function (data) {
                    $(".data-table").DataTable().ajax.reload(null, false);
                    toastr.success(data.message);
                },error: function (error) {
               $(".data-table").DataTable().ajax.reload(null, false);
                    toastr.error(error.responseJSON.message); }
            });
        }
    });

    $(document).on("click", ".decline-vendor", function (e) {
        e.preventDefault();
        var get_vendor_id = $(this).data("id");
        if (confirm("Do you want to inactive this?")) {
            $.ajax({
                url: base_url+"/decline-vendor/"+get_vendor_id,
                type: "PATCH",
                dataType: "json",
                success: function (data) {
                    $(".data-table").DataTable().ajax.reload(null, false);
                    toastr.success(data.message);
                },error: function (error) {
               $(".data-table").DataTable().ajax.reload(null, false);
                    toastr.error(error.responseJSON.message); }
            });
        }
    });

    $(document).on("click", ".active-subcategory", function (e) {
        e.preventDefault();
        if (confirm("Do you want to active this?")) {
            var get_subcategory_id = $(this).data("id");
            $.ajax({
                url: base_url+"/active-subcategory/"+get_subcategory_id,
                type: "PATCH",
                dataType: "json",
                success: function (data) {
                    $(".data-table").DataTable().ajax.reload(null, false);
                    toastr.success(data.message);
                },error: function (error) {
               $(".data-table").DataTable().ajax.reload(null, false);
                    toastr.error(error.responseJSON.message); }
            });
        }
    });

    $(document).on("click", ".decline-subcategory", function (e) {
        e.preventDefault();
        var get_subcategory_id = $(this).data("id");
        if (confirm("Do you want to inactive this?")) {
            $.ajax({
                url: base_url+"/decline-subcategory/"+get_subcategory_id,
                type: "PATCH",
                dataType: "json",
                success: function (data) {
                    $(".data-table").DataTable().ajax.reload(null, false);
                    toastr.success(data.message);
                },error: function (error) {
               $(".data-table").DataTable().ajax.reload(null, false);
                    toastr.error(error.responseJSON.message); }
            });
        }
    });

    $(document).on("click", ".active-unit", function (e) {
        e.preventDefault();
        if (confirm("Do you want to active this?")) {
            var get_unit_id = $(this).data("id");
            $.ajax({
                url: base_url+"/active-unit/"+get_unit_id,
                type: "PATCH",
                dataType: "json",
                success: function (data) {
                    $(".data-table").DataTable().ajax.reload(null, false);
                    toastr.success(data.message);
                },error: function (error) {
               $(".data-table").DataTable().ajax.reload(null, false);
                    toastr.error(error.responseJSON.message); }
            });
        }
    });

    $(document).on("click", ".decline-unit", function (e) {
        e.preventDefault();
        var get_unit_id = $(this).data("id");
        if (confirm("Do you want to inactive this?")) {
            $.ajax({
                url: base_url+"/decline-unit/"+get_unit_id,
                type: "PATCH",
                dataType: "json",
                success: function (data) {
                    $(".data-table").DataTable().ajax.reload(null, false);
                    toastr.success(data.message);
                },error: function (error) {
               $(".data-table").DataTable().ajax.reload(null, false);
                    toastr.error(error.responseJSON.message); }
            });
        }
    });
    $(document).on("click", ".active-product", function (e) {
        e.preventDefault();
        if (confirm("Do you want to active this?")) {
            var get_product_id = $(this).data("id");
            $.ajax({
                url: base_url+"/active-product/"+get_product_id,
                type: "PATCH",
                dataType: "json",
                success: function (data) {
                    $(".data-table").DataTable().ajax.reload(null, false);
                    toastr.success(data.message);
                },error: function (error) {
               $(".data-table").DataTable().ajax.reload(null, false);
                    toastr.error(error.responseJSON.message); }
            });
        }
    });

    $(document).on("click", ".decline-product", function (e) {
        e.preventDefault();
        var get_product_id = $(this).data("id");
        if (confirm("Do you want to inactive this?")) {
            $.ajax({
                url: base_url+"/decline-product/"+get_product_id,
                type: "PATCH",
                dataType: "json",
                success: function (data) {
                    $(".data-table").DataTable().ajax.reload(null, false);
                    toastr.success(data.message);
                },error: function (error) {
               $(".data-table").DataTable().ajax.reload(null, false);
                    toastr.error(error.responseJSON.message); }
            });
        }
    });

    $(document).on("input", ".numericInput", function () {
        // Get the entered value
        var enteredValue = $(this).val();

        // Check if the entered value is a valid number (float or integer)
        if (!isValidNumber(enteredValue)) {
            // If not valid, remove the last character
            $(this).val($(this).val().slice(0, -1));
        }
    });

    // Function to populate subcategories
    function populateSubcategories(categoryId) {
        $.ajax({
            url: base_url+"/get-subcategories/"+categoryId,
            type: "GET",
            dataType: "json",
            success: function (response) {
                // Clear the existing options
                $("#subcategory_id").empty();
                // Check if the response contains subcategories
                if (response.data.length > 0) {
                    // Append a default option
                    $("#subcategory_id").append(
                        '<option value="">Select Subcategory</option>'
                    );

                    // Loop through the response and append each subcategory as an option
                    $.each(response.data, function (key, value) {
                        $("#subcategory_id").append(
                            '<option value="' +
                                value.id +
                                '">' +
                                value.subcategory_name +
                                "</option>"
                        );
                    });
                    // Check if there is a pre-selected subcategory
                    var selectedSubcategoryId =
                        $("#subcategory_id").data("selected");
                    if (selectedSubcategoryId) {
                        $("#subcategory_id")
                            .val(selectedSubcategoryId)
                            .trigger("change");
                    }
                } else {
                    // If no subcategories are returned, append a message
                    $("#subcategory_id").append(
                        '<option value="">No Subcategories Available</option>'
                    );
                }

                // Optional: Log the response for debugging
                console.log(response);
            },
            error: function (xhr, status, error) {
                // Optional: Handle any errors
                console.error("An error occurred:", error);
            },
        });
    }

    // Event listener for category change
    $(document).on("change", "#category_id", function () {
        var getting_category_id = $(this).val();

        if (getting_category_id) {
            populateSubcategories(getting_category_id);
        } else {
            $("#subcategory_id").empty();
            $("#subcategory_id").append(
                '<option value="">No Subcategories Available</option>'
            );
        }
    });

    // Check if category field has a value on page load and populate subcategories
    var initialCategoryId = $("#category_id").val();
    if (initialCategoryId) {
        populateSubcategories(initialCategoryId);
    }

    const $imageInput = $("#images");
    const $previewContainer = $("#image-preview");

    $imageInput.on("change", function () {
        $previewContainer.empty(); // Clear any existing previews
        const files = this.files;

        if (files.length === 0) {
            $previewContainer.html(
                '<div class="col-md-12">No Images Selected</div>'
            );
            return;
        }

        $.each(files, function (index, file) {
            const reader = new FileReader();
            reader.onload = function (e) {
                const $colDiv = $("<div>", {
                    class: "col-md-2 image-preview-container",
                });
                const $img = $("<img>", {
                    src: e.target.result,
                    class: "img-thumbnail image-preview",
                });

                const $removeButton = $("<button>", {
                    class: "remove-image",
                    html: "Remove",
                    click: function () {
                        $colDiv.remove();
                        // Remove the file from the input
                        const dt = new DataTransfer();
                        $.each(files, function (i, f) {
                            if (i !== index) {
                                dt.items.add(f);
                            }
                        });
                        $imageInput[0].files = dt.files;
                    },
                });

                $colDiv.append($img).append($removeButton);
                $previewContainer.append($colDiv);
            };
            reader.readAsDataURL(file);
        });
    });

    // Handle removal of existing images
    $(document).on("click", ".remove-image[data-image-id]", function () {
        const $colDiv = $(this).closest(".image-preview-container");
        const imageId = $(this).data("image-id");
        $colDiv.remove();

        // Add the image ID to a hidden input to delete it on the server side
        $("<input>")
            .attr({
                type: "hidden",
                name: "remove_image_ids[]",
                value: imageId,
            })
            .appendTo("form");
    });
});

function isValidNumber(value) {
    // Use a regular expression to check if the value is a valid number
    // This regex allows both integers and floating-point numbers
    var regex = /^-?\d*\.?\d*$/;
    return regex.test(value);
}
