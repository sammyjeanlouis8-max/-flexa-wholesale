# Localization

The `locale` middleware alias resolves the current locale in this order:

1. the `locale` session value;
2. the authenticated user's `locale` column when that column exists;
3. the request `Accept-Language` header;
4. English (`en`).

Only `en`, `fr`, and `ht` are accepted. The resolved value is persisted in
the session. Views can use `current_locale()` and `available_locales()`, and
translation strings use Laravel's standard `__('group.key')` syntax.

When language selection routes are introduced, place them in the `web`
middleware group and apply the existing alias, for example:

```php
Route::post('/locale/{locale}', [LocaleController::class, 'update'])
    ->middleware('locale');
```

The controller should normalize the route value with
`App\Support\Locale::normalize()`, reject `null`, then store the result under
`config('localization.session_key')`. Apply `locale` to the web routes or a
route group so Blade rendering uses the resolved locale. No locale-changing
route is included by this foundation.